#######################################################################
#  KeyReader       Ranjith Gopalankutty             1-December-218    #
#  This program is written to read any keyed file from 4690           #                                                    
#  controller in windows. There are vaious ways to use the program    #
#                                                                     #
#######################################################################

import sys 
import time
import datetime
import os
import glob 
from pathlib import Path 
import re
import binascii
import binhex
import decimal
import threading
import struct

class PureRead:

    def ProcessRecord(record,recordlength):        
        StartingPosition = 4
        Iterator = int(508 / recordlength)
        i = 0
        while i < Iterator:
            EachRecord = record[(i*recordlength):recordlength] 
            len(EachRecord)
            if EachRecord[0:4] == "0000" or EachRecord == "" or len(EachRecord) == 0:
                i = Iterator
                break
            i = i + 1          
            POGDB = str(struct.unpack("<i",EachRecord[0:4]))
            print((POGDB[1:7]))
           
    # Below function will help to read the keyed file in sector by sector
    # then each sector can be processed further   
    def KeyRead():
        count = 0
        f = open("C:/temp/srpog.dat","rb") 
        NumberOfSectors = ((os.stat("c:/temp/srpog.dat").st_size) / 512 ) - 1
        while count <= NumberOfSectors:
            byte = f.read(512)[4:508]               
            NewByte = repr(byte).replace('\\x', '') 
            count = count + 1
            if count > 1:
                ValueTest = NewByte[2:6]
                if ValueTest != "0000":
                   if  NewByte[1:5] !="" :
                        PureRead.ProcessRecord(byte,101)
                  
#MainLine code starts from here 
start = time.time()
PureRead.KeyRead()
end = time.time()
print("I have taken total" ,(end - start) , "to execute")