#ifndef UTIL
#define UTIL

//Useful macro to prevent unused arguments from generating compiler warnings.
//Also generates no code!
#define touch(a) if(a)

#endif

