#if !defined DEBUG_H
#define DEBUG_H 1

#include "file.h"

// Debug
#define DBG_LOCAL       0
#define DBG_FILE        1

//extern WORD oput;
//extern FILE_CTRL dbg;

#endif /* DEBUG_H not defined */


