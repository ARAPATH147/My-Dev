/*************************************************************************
 * 
 * 
 * File: sockserv.h
 *
 * Author:  Prashant Kotak
 *
 * Created: 18/08/97
 *
 * Purpose: 
 *
 * History: 
 *
 * V1.1       Brian Greenfield        08/01/2008
 * Replaced size of RFHHTUnion with fixed zie buffer value.
 *
 * V1.2       Brian Greenfield        01/08/2008
 * Inreased MAX_Sockets from 40 to 200 to accomodate West Hallam warehouse useage.
 * 
 *************************************************************************/

#ifndef SOCKSERV_H
#define SOCKSERV_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "flexsock.h"
#include "rf.h"

#define  HHTCOMMS_PORT  800
#define  MAX_SOCKETS    200                      //BMG 1.2 01-08-2008
/*#define BUFFER_SIZE     sizeof (RFHHTUnion) */ //BMG 1.1 08-01-2008
#define BUFFER_SIZE 2100                         //BMG 1.1 08-01-2008
#define MAX_TIMEOUT     1

enum group_status {
         STATUS_READ,            
         STATUS_WRITE,
         STATUS_EXCPT
        };

enum sock_state { 
         ERROR_STATE = -1,
         UNCONNECTED = 0, 
         AWAITING_INPUT,
         AWAITING_OUTPUT,
         AWAITING_DISCONNECT
      };


enum appmsg_type {
         MSG_TYPE_RBS,
         MSG_TYPE_BOOTS
       };

typedef int sock_handle;

typedef struct sockaddr sock_addr;

typedef struct
{
   char     TID [RF_MESSAGE_TID_LENGTH] ;
   unsigned Command ;
   unsigned FileAttributes ;
   unsigned PacketSize ;
   char     FileName [RF_HHT_MAX_FILENAME_LENGTH];
   long     FileSize;
   long      FilePointer;
   int       Done;
}
FILEINFO ;


typedef struct  {
    int InUse;
    int HhtId;
    int SignedOn;
    time_t LastMsgDateTime;
    sock_addr SocketAddress;
    int SocketAddrLen;
    sock_handle SocketHandle;
    int SocketState;
    char *Buffer;
    int BufferSize;
    int MessageLen;
    FILEINFO *FileInfo;
} 
CLIENT;


/* main prototypes */
void main ( int argc, char *argv[] ) ; 
void ParseControlFile ( void ) ;
void ParseCommandLineArgs( int argc, char *argv[] ) ;

/* sockserv prototypes */
int  TcpLoaded ( void ) ;
void InitialiseSocketServer ( void ) ;
void SocketServerLoop ( void ) ;
void ProcessPendingConnects ( sock_handle * ) ;
void ProcessPendingReceives ( void ) ;
void ProcessPendingSends ( void ) ;
void ProcessPendingDisconnects ( void ) ; 
int GetFreeClientSlot ( void ) ;
int ClearOldClientConnection ( int ) ;                                      //SDH 16-05-2005
void ReleaseClientSlot ( int ) ;
void ShutDownAllSockets ( void ) ;

/* sockfunc prototypes */
int IsTcpLoaded ( void ) ;
int AllocateSocket ( sock_handle * ) ;
int BindSocket ( sock_handle *, int iPortNum ) ;                            //SDH 19-05-2005
int ListenOnSocket ( sock_handle * ) ;
int AcceptOnSocket ( sock_handle *, CLIENT * ) ;
int SocketGroupStatus ( int *, int, int ) ;
int ReadSocket ( CLIENT * ) ;
int WriteSocket ( CLIENT * ) ;
void CloseSocket ( sock_handle * ) ;
int SetBlockingMode ( sock_handle *, int ) ;

/* app_proc prototypes */
void ProcessMessage ( CLIENT * ) ;
void IssueCmdOffToBootsApp ( int ) ;
void SetupRbsNakCmd ( CLIENT *, char *, char *, char * ) ;
void DummyCallToProcess ( void ) ;

/* osfunc prototypes */
long GetFileDetails ( CLIENT * ) ;
void AssignFileInfo  ( CLIENT * ) ;
void ReadNextFilePacket ( CLIENT * ) ;
void ProcessFileRxAck ( CLIENT * ) ; 
void WriteNextFilePacket ( CLIENT * ) ;
void * AllocateBuffer ( long ) ;
void FreeBuffer ( void * ) ;
void ExitApplication ( void ) ;
void CtlBrkHandler ( void );
long TermEvent ( void ) ;
void ProcessGetTime ( CLIENT * ) ;
void DelayProcess ( long ) ;
int DateHasChanged ( void ) ;
void CycleHhtLogs ( void ) ;

/* globally used variables */
//extern int BreakLoop;

#endif

