// 2.1 - SW - 04/11/1998
//       Phase II enhancements
//       Add extra details into ENQUIRY structure
// 3.0 - SW - 28/08/2003
//       2003 Trial updates
//       Amend General_Enquiry struct to hold an active deal flag instead of
//       containing the deal number. Actual new deals info not required.
//
//4.02 - PAB 18/02/2004
//       2004 RF Trial Phase2 development
//       Changes to SNR and PRT transaction layouts for proximity printing
//
// 5.00 - PAB 5/5/04
//       Changes to include Pre-Scan transactions
//
// 6.00 - PAB 7-7-2004
//       Changes for MyStoreNet to include new transaction types
//
// 7.00 - PAB 22-5-2007 
//       Changes to include transaction types for recalls A7C
// -------------------------------------------------------------------------------

#include "flexif.h"
#include "rfsfile.h"
#include "trans2.h"
#include "dateconv.h"

#if !defined RFS_H
#define RFS_H 1

#define RFS_VER  "VERSION : A7C.0"          // Overall RFS Version Number
#define RFS_DATE __DATE__                   // Compile date
#define SEM_47_RUNNING  "pi:sellockb"       // PSS47 running semephore
#define SEM_LAB_RUNNING "pi:sellockp"       // PRINTSEL running semephore
//#define MAX_UNIT       120                // largest possible unit number
#define MAX_UNIT         255                // largest possible unit number
//#define MAX_CONC_UNITS 40                 // Max. concurrent units
#define MAX_CONC_UNITS   255                // Max. concurrent units
#define ALL_UNITS        -1                 // All units flag for unit dealloc
#define CHECK_G          2200               // number of cycles between checks  was 18 PAB
#define REPORT_DATASIZE  20                 // record size of data blocks
#define REPORT_BUFFER    0x4000L            // report buffer size
#define REPORT_SEQ_SIZE  4                  // Report Command SEQ Size

// Performance tuning options
#define HEADER_MAX       6                  // Max. no. of RLD concatinations
#define DETAIL_MAX       10                 // Max. no. of RUP concatinations

// Report buffer
typedef struct Report_Buffer {
   LONG base;                       // base offset into physical file
   LONG end;                        // end offset of data (rec algnd)
   BYTE *buff;                      // pointer to buffer
} RBUF;

typedef struct FileNum_Table {
   LONG fnumx;
   BYTE ftype[1];
} FILE_TABLE;

typedef struct Active_LRT_Table {
   UBYTE state;
   LONG fnum1;             // work file 1 fnum (CHKWK...)
   LONG fnum2;             // work file 2 fnum (GAPWK...)
   LONG fnum3;             // current report file fnum
   WORD pq_sub1;           // work file 1 pq subscript
   WORD pq_sub2;           // work file 2 pq subscript
   LONG last_active_time;  // time last message received
   BYTE user[3];           // user id
   BYTE abOpName[15];      // Operator name
   BYTE authority[1];      // user's authority
   WORD count1;            // misc count for this handheld
   WORD count2;            // misc count for this handheld
   RBUF *rbufp;            // pointer to report buffer struct
   BYTE txn[3];            // last transaction received (shared info)
   BYTE unique[5];         // txn specific, unique info (shared info)
   BYTE bLocation          // [U]nknown, [S]hop, [O]SSR                     //SDH 19-01-2005
} ACTIVE_LRT;                               // Units currently being used

typedef struct Program_Process_Queue {
   UBYTE state;                     // current processing state
   WORD unit;                       // handheld identifier
   BYTE fname[32];                  // work file name
   BYTE type;                       // work file ind. (SYS_LAB/GAP)
   WORD submitcnt;                  // 26-1-2007 PAB
// BOOLEAN disp;                    // displayed pq entry
// BOOLEAN disp_err;                // displayed pq error
} PROG_PQ;

// v4.01 START
//// 4690 file functions
//typedef struct C4690_File_Control {
//   LONG fnum;
//   UBYTE present;
//   UBYTE sessions;
//} FILE_CTRL;
// v4.01 END

// Shared memory buffer
typedef struct SMem_Status {
   BYTE state[1];          // state
   LONG last_active_time;  // time last txn received
   BYTE user[3];           // user id
   BYTE txn[3];            // last transaction received
   BYTE unique[5];         // variable data, depends on txn
} SHARE_STAT_REC;

// Misc
typedef struct Till_Rec {
   LONG today;
   LONG wtd;
} TILLREC;
typedef struct Till_Takings_Rec {
   TILLREC till[1000];
} TILL_TAKINGS;
//TILL_TAKINGS_REC_LTH = sizeof(TILL_TAKINGS);


// LRT Application level data records

//Miscellaneous
// v2.1
typedef struct LRT_ACK_Txn {
   BYTE cmd[3];
   BYTE msg[63];
} LRT_ACK;                                    // +ve acknowledge
#define LRT_ACK_LTH sizeof(LRT_ACK)

// v2.1
typedef struct LRT_NAK_Txn {
   BYTE cmd[3];
   BYTE msg[150];                             // 25-5-07 PAB Recalls
} LRT_NAK;                                    // -ve acknowledge
#define LRT_NAK_LTH sizeof(LRT_NAK)


// Sign on
// v2.1
typedef struct LRT_SOR_Txn {
   BYTE cmd[3];
   BYTE opid[3];
   BYTE pass[3];
   BYTE abAppID[3];                           // SDH 07-12-2004
} LRT_SOR;                                    // Master signon request
#define LRT_SOR_LTH sizeof(LRT_SOR)

// v2.1
// SNR - existing record appears to be unused - format changed
typedef struct LRT_SNR_Txn {
   BYTE cmd[3];
   BYTE opid[3];
   BYTE auth;                 // ' ' = user, 'S' = Supervisor   //17-11-2004 SDH
   BYTE name[15];
   BYTE stamp[12];            // Date/time stamp - format YYYYMMDDHHMM
   BYTE prtnum[10];           // phase 2 printer config status flags  4.02PAB
   BYTE bOssrWanActive;       // 'Y' if OSSR WAN is active      //17-11-2004  SDH
   BYTE cPlannersActive;      // 'Y' is planners is turned on   //25-Sep-2006 SDH Planners
   BYTE snrprtdesc[200];      // Printer location descriptor
} LRT_SNR;                                    // Price check response
#define LRT_SNR_LTH sizeof(LRT_SNR)

// v2.1
typedef struct LRT_OFF_Txn {
   BYTE cmd[3];
   BYTE opid[3];
} LRT_OFF;                                    // Master signoff
#define LRT_OFF_LTH sizeof(LRT_OFF)


// Price Check
// v2.1
typedef struct LRT_PCS_Txn {
   BYTE cmd[3];
   BYTE opid[3];
} LRT_PCS;                                    // Price check signon
#define LRT_PCS_LTH sizeof(LRT_PCS)

// v2.1
typedef struct LRT_PCR_Txn {
    BYTE cmd[3];
    BYTE pchk_target[4];
    BYTE pchk_done[4];
} LRT_PCR;                                    // Price check start response
#define LRT_PCR_LTH sizeof(LRT_PCR)

// v2.1
typedef struct LRT_PCM_Txn {
   BYTE cmd[3];
   BYTE opid[3];
   BYTE boots_code[7];
   BYTE variance[6];
   BYTE type[1];                              // 26-7-2004 PAB
} LRT_PCM;                                    // Price mismatch
#define LRT_PCM_LTH sizeof(LRT_PCM)

// v2.1
typedef struct LRT_PCX_Txn {
   BYTE cmd[3];
   BYTE opid[3];
   BYTE items[4];
   BYTE sels[4];
} LRT_PCX;                                    // Price check signoff
#define LRT_PCX_LTH sizeof(LRT_PCX)


// Stock Monitor
// v2.1
typedef struct LRT_GAS_Txn {
   BYTE cmd[3];
   BYTE opid[3];  
} LRT_GAS;                                    // Gap Monitor Start
#define LRT_GAS_LTH sizeof(LRT_GAS)

// v2.1
typedef struct LRT_GAR_Txn {
   BYTE cmd[3];
   BYTE list_id[3];  
   BYTE pchk_target[4];
   BYTE pchk_done[4];
} LRT_GAR;                                    // Gap signon response
#define LRT_GAR_LTH sizeof(LRT_GAR)

// v2.1
typedef struct LRT_ENQ_Txn {
   BYTE cmd[3];
   BYTE opid[3];
   BYTE enq_type[1];          // [I]tem / [P]arent
   BYTE function[1];          // [P]Chk / [ ]Other
   BYTE item_code[13];
   BYTE stock_req_flag[1];    // Stock figure required on EQR [Y]es / [N]o
   BYTE cUpdateOssrItem;      // ' '-No change, 'N'-non-OSSR, 'O'-change to OSSR    // SDH 17-11-04 OSSR WAN
} LRT_ENQ;                                      // Stock enquiry
#define LRT_ENQ_LTH sizeof(LRT_ENQ)

//DEALSUM - Used by EQR
typedef struct DEALSUM_Struct {
    BYTE abNum[4];
    BYTE abQualMsgNum[2];
} DEALSUM;

// v2.1
typedef struct LRT_EQR_Txn {
   BYTE cmd[3];
   BYTE boots_code[7];
   BYTE parent_code[7];
   BYTE item_desc[20];
   BYTE item_price[6];
   BYTE sel_desc[45];
   BYTE status[1]; 
   BYTE supply_method[1];
   BYTE redeemable[1];
   BYTE stock_figure[6];      // Items
   BYTE pchk_target[4];
   BYTE pchk_done[4];
   BYTE price_emu[6];         // Cents
   BYTE prim_curr[1];         // [S]terling / [E]cu
   BYTE item_code[13];
   BYTE active_deal_flag[1];  // [Y]es / [N]o
   BYTE check_accepted[1];    // [Y]es / [N]o / [ ]n/a
   BYTE reject_msg[14];       // ASCII "DOW DD/MM/YYYY", set if check rejected
   BYTE cBusCentre;           // SDH 17-11-04 OSSR WAN
   BYTE abBusCentreDesc[14];  // SDH 17-11-04 OSSR WAN
   BYTE cOssrItem;            // SDH 17-11-04 OSSR WAN
   DEALSUM Deal[10];          // SDH 09-12-04 PROMOTIONS
   BYTE abCoreCount[3];       // SDH 12-Oct-06 Planners
   BYTE abNonCoreCount[3];    // SDH 12-Oct-06 Planners
   BYTE cRecallItem[1];       // PAB 22-5-07 Recalls "Y" if item is on recall. else "N"
} LRT_EQR;                                    // stock enquiry response
#define LRT_EQR_LTH sizeof(LRT_EQR)

// v2.1
typedef struct LRT_GAP_Txn {
   BYTE cmd[3];
   BYTE opid[3];
   BYTE list_id[3];
   BYTE seq[3];
   BYTE item_code[13];
   BYTE boots_code[7];
   BYTE current[4];
   BYTE fill_qty[4];
   BYTE gap_flag[1];          // [Y]=Stock monitor, [N]=C&A/RI
   BYTE stock_figure[6];      // Items
   BYTE cUpdateOssrItem;      // ' '-No change, 'N'-non-OSSR, 'O'-change to OSSR    // SDH 17-11-04 OSSR WAN
} LRT_GAP;                                    // Gap Monitor - PL Add/Replace
#define LRT_GAP_LTH sizeof(LRT_GAP)

// v2.1
typedef struct LRT_GAX_Txn {
   BYTE cmd[3];
   BYTE opid[3];
   BYTE list_id[3];
   BYTE picks[4];
   BYTE sels[4];
   BYTE pchks[4];
   //BYTE gaps[4];
} LRT_GAX;                                    // Gap Monitor Exit
#define LRT_GAX_LTH sizeof(LRT_GAX)


// Picking Lists
// v2.1
typedef struct LRT_PLO_Txn {
   BYTE cmd[3];
   BYTE opid[3];
} LRT_PLO;                                                          // Picking list signon
#define LRT_PLO_LTH sizeof(LRT_PLO)

// v2.1
typedef struct LRT_PLR_Txn {
   BYTE cmd[3];
   BYTE opid[3];
   BYTE list_id[3];
   BYTE auth[1];
} LRT_PLR;                                                           // Picking list request
#define LRT_PLR_LTH sizeof(LRT_PLR)

// v2.1
typedef struct LRT_PLL_Txn {
   BYTE cmd[3];
   BYTE list_id[3];
   BYTE seq[3];
   BYTE list_status[1];       // [A]=Supervisor, [U]=normal user
   BYTE stamp[12];            // YYYYMMDDHHMM
   BYTE lines[4];
   BYTE username[15];
   BYTE cListStatus;          // [S]helf Monitor, [F]ast Fill, [O]ssr, [E]xcess stock
} LRT_PLL;                                                           // Picking list response
#define LRT_PLL_LTH sizeof(LRT_PLL)

// v2.1
typedef struct LRT_PLS_Txn {
   BYTE cmd[3];
   BYTE opid[3];
   BYTE list_id[3];
   BYTE seq[3];
} LRT_PLS;                                                           // Picking list select
#define LRT_PLS_LTH sizeof(LRT_PLS)

// v2.1
typedef struct LRT_PLI_Txn {
   BYTE cmd[3];
   BYTE list_id[3];
   BYTE seq[3];
   BYTE boots_code[7];
   BYTE parent_code[7];
   BYTE item_desc[20];
   BYTE fill[4];
   BYTE status[1];  
   BYTE gap_flag[1];
   BYTE active_deal_flag[1];                                         // v2.1
   BYTE stock_figure[6];                                             // v2.1
   BYTE sel_desc[45];                                                // v2.1
   BYTE item_code[13];                                               // v2.1
   BYTE pli_qtyshelf[4];                                             // 19-02-04 PAB
   BYTE abBackCount[4];                                              // SDH 17-11-04 OSSR WAN
   BYTE cOssrItem;                                                   // SDH 17-11-04 OSSR WAN
} LRT_PLI;                                                           // Picking list item
#define LRT_PLI_LTH sizeof(LRT_PLI)

// v2.1
typedef struct LRT_PLC_Txn {
   BYTE cmd[3];
   BYTE opid[3];
   BYTE list_id[3];
   BYTE seq[3];
   BYTE boots_code[7];
   BYTE count[4];
   BYTE gap_flag[1];
   BYTE cPickLocation;                                               // SDH 11-1-04 OSSR WAN
   BYTE abOssrCount[4];                                              // SDH 11-1-04 OSSR WAN
   BYTE cUpdateOssrItem;                                             // SDH 11-1-04 OSSR WAN
} LRT_PLC;                                    // Picking list item update
#define LRT_PLC_LTH sizeof(LRT_PLC)

// v2.1
typedef struct LRT_PLE_Txn {
   BYTE cmd[3];
   BYTE list_id[3];
} LRT_PLE;                                    // Picking list end
#define LRT_PLE_LTH sizeof(LRT_PLE)

// v2.1
typedef struct LRT_PLX_Txn {
   BYTE cmd[3];
   BYTE opid[3];
   BYTE list_id[3];
   BYTE lines[4]; 
   BYTE items[6];
   BYTE complete[1];
} LRT_PLX;                                    // Picking list exit
#define LRT_PLX_LTH sizeof(LRT_PLX)

// v2.1
typedef struct LRT_PLF_Txn {
   BYTE cmd[3];
   BYTE opid[3];
} LRT_PLF;                                    // Picking list main exit
#define LRT_PLF_LTH sizeof(LRT_PLF)


// Item Information
// v2.1
typedef struct LRT_INS_Txn {
   BYTE cmd[3];
   BYTE opid[3];
} LRT_INS;                                    // Information sign on
#define LRT_INS_LTH sizeof(LRT_INS)

// v2.1
typedef struct LRT_INX_Txn {
   BYTE cmd[3];
   BYTE opid[3];
} LRT_INX;                                    // Information exit
#define LRT_INX_LTH sizeof(LRT_INX)

// v2.1
typedef struct LRT_SSE_Txn {
   BYTE cmd[3];
   BYTE opid[3];
} LRT_SSE;                                    // Store sales enquiry
#define LRT_SSE_LTH sizeof(LRT_SSE)

// v2.1
typedef struct LRT_SSR_Txn {
   BYTE cmd[3];
   BYTE sales_t[8];           // Pence
   BYTE sales_w[8];           // Pence
} LRT_SSR;                                    // Store sales info response
#define LRT_SSR_LTH sizeof(LRT_SSR)

// v2.1
typedef struct LRT_ISE_Txn {
   BYTE cmd[3];
   BYTE opid[3];
   BYTE item_code[13];
} LRT_ISE;                                    // Item sales request
#define LRT_ISE_LTH sizeof(LRT_ISE)

// v2.1
typedef struct LRT_ISR_Txn {
   BYTE cmd[3];
   BYTE item_desc[20];
   BYTE sold_q_t[4];
   BYTE sold_v_t[8];
   BYTE sold_q_w[4];
   BYTE sold_v_w[8];
} LRT_ISR;                                    // Item sales response
#define LRT_ISR_LTH sizeof(LRT_ISR)

// v2.1
typedef struct LRT_PLU_Txn {
   BYTE cmd[3];
   BYTE opid[3];
   BYTE item_code[13];
} LRT_PLU;                                    // Item enquiry request
#define LRT_PLU_LTH sizeof(LRT_PLU)

// v2.1
typedef struct LRT_RSP_Txn {
   BYTE cmd[3];
   BYTE boots_code[7];
   BYTE item_desc[20];
   BYTE item_price[6];
   BYTE stock_figure[6];
   BYTE sel_desc[45];
   BYTE supply_method[1];
   BYTE redeemable[1];
} LRT_RSP;                                    // PLU response
#define LRT_RSP_LTH sizeof(LRT_RSP)

// v2.1
typedef struct LRT_PRT_Txn {
   BYTE cmd[3];
   BYTE opid[3];
   BYTE item_code[13];
   BYTE type[1];                              // [B]atch / [I]mmediate print
} LRT_PRT;                                    // SEL print request
#define LRT_PRT_LTH sizeof(LRT_PRT)


// Reporting
typedef struct LRT_RPO_Txn {
   BYTE cmd[3];
   BYTE opid[3];
} LRT_RPO;                                    // Reports sign on
#define LRT_RPO_LTH sizeof(LRT_RPO)

typedef struct LRT_RPX_Txn {
   BYTE cmd[3];
   BYTE opid[3];
} LRT_RPX;                                    // Reports exit
#define LRT_RPX_LTH sizeof(LRT_RPX)

// v2.1
typedef struct LRT_RLE_Txn {
   BYTE cmd[3];
   BYTE opid[3];
   BYTE seq[REPORT_SEQ_SIZE];
} LRT_RLE;                                    // Reports request
#define LRT_RLE_LTH sizeof(LRT_RLE)

// v2.1
typedef struct LRT_RLR_Txn {
   BYTE cmd[3];
   BYTE seq[4];
   BYTE title[REPORT_DATASIZE];
   BYTE fname[12];
} LRT_RLR;                                    // Reports response
#define LRT_RLR_LTH sizeof(LRT_RLR)

// v2.1
typedef struct LRT_RLS_Txn {
   BYTE cmd[3];
   BYTE opid[3];
   BYTE fname[12];
   BYTE seq[REPORT_SEQ_SIZE];
} LRT_RLS;                                    // Report header request
#define LRT_RLS_LTH sizeof(LRT_RLS)

// v2.1
typedef struct LRT_RLD_Rpt {
    BYTE seq[REPORT_SEQ_SIZE];
    BYTE data[REPORT_DATASIZE];
} LRT_RLD_REP;
#define LRT_RLD_REP_LTH sizeof(LRT_RLD_REP)
typedef struct LRT_RLD_Txn {
    BYTE cmd[3];
    BYTE rpt[3];
    LRT_RLD_REP rep[HEADER_MAX];
} LRT_RLD;                                   // Report headers (level 0s)
#define RLD_REP_OFFSET  6                    // Length on non-repeating data
#define LRT_RLD_MAX_LTH sizeof(LRT_RLD)      // N.B. variable length

// v2.1
typedef struct LRT_RPS_Txn {
   BYTE cmd[3];
   BYTE opid[3];
   BYTE fname[12];
   BYTE seq[REPORT_SEQ_SIZE];
} LRT_RPS;                                    // Report data request
#define LRT_RPS_LTH sizeof(LRT_RPS)

// v2.1
typedef struct LRT_RUP_Rpt {
   BYTE level[1];
   BYTE exp[1];
   BYTE data[REPORT_DATASIZE];
} LRT_RUP_REP;
#define LRT_RUP_REP_LTH sizeof(LRT_RUP_REP)
typedef struct LRT_RUP_Txn {
   BYTE cmd[3];
   BYTE rpt[3];
   LRT_RUP_REP rep[DETAIL_MAX];
} LRT_RUP;                                    // Report detail (level 1+s)
#define RUP_REP_OFFSET  6                // Length on non-repeating data
#define LRT_RUP_MAX_LTH sizeof(LRT_RUP)        // N.B. Variable length

// v2.1
typedef struct LRT_RLF_Txn {
   BYTE cmd[3];
} LRT_RLF;                                    // Report - no more data
#define LRT_RLF_LTH sizeof(LRT_RLF)


// List-Driven Counting (all new to v2.1)
// v2.1
typedef struct LRT_CLO_Txn {
   BYTE cmd[3];
   BYTE opid[3];
} LRT_CLO;                                    // Counting - List Signon
#define LRT_CLO_LTH sizeof(LRT_CLO)

typedef struct LRT_CLR_Txn {
   BYTE cmd[3];
   BYTE opid[3];
   BYTE list_id[3];
} LRT_CLR;                                    // Counting - List Request
#define LRT_CLR_LTH sizeof(LRT_CLR)

// Changes req'd : CLL equiv
typedef struct LRT_CLL_Txn {
   BYTE cmd[3];
   BYTE list_id[3];
   BYTE seq[3];
   BYTE num_items[3];         // Total number of items
   BYTE items_shopfloor[3];   // Items left on shopfloor
   BYTE items_backshop[3];    // Items left on backshop
   BYTE list_type[1];         // [H]ead office / [R]ectification
   BYTE bus_unit_name[15];
   BYTE active[1];
   BYTE abItemsOssr[3];       // SDH 17-01-2005 OSSR WAN
} LRT_CLL;                                    // Counting - List Ack
#define LRT_CLL_LTH sizeof(LRT_CLL)

typedef struct LRT_CLS_Txn {
   BYTE cmd[3];
   BYTE opid[3];
   BYTE list_id[3];
   BYTE seq[3];   // Addition to spec - need to check out !!!!!!!!!!!!!!!!
} LRT_CLS;                                    // Counting - List Select
#define LRT_CLS_LTH sizeof(LRT_CLS)

typedef struct LRT_CLI_Txn {
   BYTE cmd[3];
   BYTE list_id[3];
   BYTE seq[3];
   BYTE boots_code[7];
   BYTE parent_code[7];
   BYTE item_code[13];
   BYTE sel_desc[45];
   BYTE active_deal_flag[1];
   BYTE product_group[6];
   BYTE count_backshop[4];
   BYTE count_shopfloor[4];
   BYTE status[1];
   BYTE abOSSRCount[4];                                                     // SDH 17-11-04 OSSR WAN
   BYTE cOssrItem;                                                          // SDH 17-11-04 OSSR WAN
} LRT_CLI;                                                                  // Counting - List Item in List
#define LRT_CLI_LTH sizeof(LRT_CLI)

typedef struct LRT_CLC_Txn {
   BYTE cmd[3];
   BYTE opid[3];
   BYTE list_id[3];
   BYTE seq[3];
   BYTE boots_code[7];
   BYTE count_backshop[4];
   BYTE count_shopfloor[4];
   BYTE abOssrCount[4];
   BYTE cUpdateOssrItem; //' '-no change, 'O'-OSSR item, 'N'-Non-OSSR item
} LRT_CLC;                                    // Counting - List Item Confirm
#define LRT_CLC_LTH sizeof(LRT_CLC)

typedef struct LRT_CLE_Txn {
   BYTE cmd[3];
   BYTE list_id[3];
} LRT_CLE;                                    // Counting - List End
#define LRT_CLE_LTH sizeof(LRT_CLE)

typedef struct LRT_CLX_Txn {
   BYTE cmd[3];
   BYTE list_id[3];
   BYTE commit_flag[1];
} LRT_CLX;                                    // Counting - List Exit
#define LRT_CLX_LTH sizeof(LRT_CLX)

// v2.1
typedef struct LRT_CLF_Txn {
   BYTE cmd[3];
   BYTE opid[3];
} LRT_CLF;                                    // Counting - list main exit
#define LRT_CLF_LTH sizeof(LRT_CLF)

// Version 5.0 Pre-Scan                                             5-5-4 PAB
typedef struct LRT_SUS_Txn {                                     // 5-5-2004 PAB 
   BYTE cmd[3];                                                  // 5-5-2004 PAB 
   BYTE opid[3];                                                 // 5-5-2004 pab
   BYTE sus_items[481]; // 37 * EAN13                            // 5-5-2004 pab
}  LRT_SUS;                                                      // 5-5-2004 PAB
#define LRT_SUS_LTH sizeof(LRT_SUS)                              // 5-5-2004 PAB
                                                                 // 5-5-2004 PAB
typedef struct LRT_SAK_Txn {                                     // 5-5-2004 PAB
  BYTE cmd[3];                                                   // 5-5-2004 PAB
  BYTE till_id[3];                                               // 5-5-2004 PAB
  BYTE txn_num[4];                                               // 5-5-2004 PAB
} LRT_SAK;                                                       // 5-5-2004 PAB
#define LRT_SAK_LTH sizeof(LRT_SAK)                              // 5-5-2004 PAB
                                                                 // 5-5-2004 PAB
// version 6.0 MyStoreNet changes                                // 7-7-2004 PAB
typedef struct LRT_SIE_txn {                                     // 7-7-2004 PAB
  BYTE cmd[3];                                                   // 7-7-2004 PAB
  BYTE opid[3];                                                  // 7-7-2004 PAB
} LRT_SIE;                                                       // 7-7-2004 PAB
#define LRT_SIE_LTH sizeof(LRT_SIE)                              // 7-7-2004 PAB
                                                                 // 7-7-2004 PAB
typedef struct LRT_SIR_txn {                                     // 7-7-2004 PAB
  BYTE cmd[3];                                                   // 7-7-2004 PAB
  BYTE store_number[4];                                          // 7-7-2004 PAB
} LRT_SIR;                                                       // 7-7-2004 PAB
#define LRT_SIR_LTH sizeof (LRT_SIR)                             // 7-7-2004 PAB

// PAstraMI support - v3.0
typedef struct LRT_PAL_Txn {
   BYTE cmd[3];
   BYTE opid[3];
   BYTE item_code[13];
} LRT_PAL;                                    // PAstraMI item info lookup
#define LRT_PAL_LTH sizeof(LRT_PAL)

typedef struct LRT_PAR_Txn {
   BYTE cmd[3];
   BYTE enforcement[1];        // "1"=none, "2"=force info, "3"=force link
   BYTE url_item[60];
   BYTE banner_item[60];
   BYTE url_link[60];
   BYTE banner_link[60];
} LRT_PAR;                                    // PAstraMI item info response
#define LRT_PAR_LTH sizeof(LRT_PAR)

typedef struct LRT_PAS_Txn {
   BYTE cmd[3];
   BYTE opid[3];
} LRT_PAS;                                    // PAstraMI signon request
#define LRT_PAS_LTH sizeof(LRT_PAS)

typedef struct LRT_PAX_Txn {
   BYTE cmd[3];
   BYTE opid[3];
} LRT_PAX;                                    // PAstraMI signoff
#define LRT_PAX_LTH sizeof(LRT_PAX)

typedef struct LRT_PDT_Txn {
    BYTE cmd[3];
    WORD recnum;
    WORD rectot;
    WORD reclth;
    BYTE debug[100];    // Variable length
} LRT_PDT;                                    // PAstraMI debug dump line
#define LRT_PDT_LTH sizeof(LRT_PDT)

typedef struct LRT_PDR_Txn {
   BYTE cmd[3];
} LRT_PDR;                                    // PAstraMI debug dump response
#define LRT_PDR_LTH sizeof(LRT_PDR)

typedef struct LRT_UOS_Txn {                  // Start of UOD                           // SDH 26-11-04 CREDIT CLAIM
   BYTE abCmd[3];                                                                       // SDH 26-11-04 CREDIT CLAIM
   BYTE abOpID[3];                                                                      // SDH 26-11-04 CREDIT CLAIM
   BYTE cListType;  //"G" - Goods out, "C" - credit claim                               // SDH 26-11-04 CREDIT CLAIM
} LRT_UOS;                                                                              // SDH 26-11-04 CREDIT CLAIM
#define LRT_UOS_LTH sizeof(LRT_UOS)                                                     // SDH 26-11-04 CREDIT CLAIM
                                                                                        // SDH 26-11-04 CREDIT CLAIM
typedef struct LRT_UOR_Txn {                  // UOD reponse                            // SDH 26-11-04 CREDIT CLAIM
    BYTE abCmd[3];                                                                      // SDH 26-11-04 CREDIT CLAIM
    BYTE abOpID[3];                                                                     // SDH 26-11-04 CREDIT CLAIM
    BYTE abListNum[4];                                                                  // SDH 26-11-04 CREDIT CLAIM
    BYTE abValidBusCentres[30];                                                         // SDH 26-11-04 CREDIT CLAIM
} LRT_UOR;                                                                              // SDH 26-11-04 CREDIT CLAIM
#define LRT_UOR_LTH sizeof(LRT_UOR)                                                     // SDH 26-11-04 CREDIT CLAIM
                                                                                        // SDH 26-11-04 CREDIT CLAIM
typedef struct LRT_UOA_Txn {                  // Start of UOD                           // SDH 26-11-04 CREDIT CLAIM
    BYTE abCmd[3];                                                                      // SDH 26-11-04 CREDIT CLAIM
    BYTE abOpID[3];                                                                     // SDH 26-11-04 CREDIT CLAIM
    BYTE abListNum[4];                                                                  // SDH 26-11-04 CREDIT CLAIM
    BYTE abRecSeq[4];                                                                   // SDH 26-11-04 CREDIT CLAIM
    BYTE abItemCode[7];                                                                 // SDH 26-11-04 CREDIT CLAIM
    BYTE abQty[4];                                                                      // SDH 26-11-04 CREDIT CLAIM
    BYTE abDesc[20];                                                                    // SDH 26-11-04 CREDIT CLAIM
    BYTE abSelDesc[45];                                                                 // SDH 26-11-04 CREDIT CLAIM
    BYTE abPrice[6];                                                                    // SDH 26-11-04 CREDIT CLAIM
    BYTE abFiller[6];                                                                   // SDH 26-11-04 CREDIT CLAIM
    BYTE cBusCentre;                                                                    // SDH 26-11-04 CREDIT CLAIM
    BYTE abBusCentreDesc[14];                                                           // SDH 26-11-04 CREDIT CLAIM
    BYTE abBarCode[13];                                                                 // SDH 26-11-04 CREDIT CLAIM
    BYTE cItemStatus;                                                                   // SDH 26-11-04 CREDIT CLAIM
} LRT_UOA;                                                                              // SDH 26-11-04 CREDIT CLAIM
#define LRT_UOA_LTH sizeof(LRT_UOA)                                                     // SDH 26-11-04 CREDIT CLAIM

typedef struct LRT_UOX_Txn {                  // UOD reponse                            // SDH 26-11-04 CREDIT CLAIM
    BYTE abCmd[3];                                                                      // SDH 26-11-04 CREDIT CLAIM
    BYTE abOpID[3];                                                                     // SDH 26-11-04 CREDIT CLAIM
    BYTE abListNum[4];                                                                  // SDH 26-11-04 CREDIT CLAIM
    BYTE cListType;                                                                     // SDH 26-11-04 CREDIT CLAIM
    BYTE abUODNum[14];                                                                  // SDH 26-11-04 CREDIT CLAIM
    BYTE cStatus;                                                                       // SDH 26-11-04 CREDIT CLAIM
    BYTE abItemCount[4];                                                                // SDH 26-11-04 CREDIT CLAIM
    BYTE cAdjStockFig;                                                                  // SDH 26-11-04 CREDIT CLAIM
    BYTE cSupplyRoute;                                                                  // SDH 26-11-04 CREDIT CLAIM
    BYTE cDispLocation;                                                                 // SDH 26-11-04 CREDIT CLAIM
    BYTE cBusCentre;                                                                    // SDH 26-11-04 CREDIT CLAIM
    BYTE abBusCentreDesc[14];                                                           // SDH 26-11-04 CREDIT CLAIM
    BYTE abRecallNum[8];                                                                // SDH 26-11-04 CREDIT CLAIM
    BYTE abAuth[15];                                                                    // SDH 26-11-04 CREDIT CLAIM
    BYTE abSupplier[15];                                                                // SDH 26-11-04 CREDIT CLAIM
    BYTE abReturnMethod[2];                                                             // SDH 26-11-04 CREDIT CLAIM
    BYTE abCarrier[2];                                                                  // SDH 26-11-04 CREDIT CLAIM
    BYTE abBirdNum[8];                                                                  // SDH 26-11-04 CREDIT CLAIM
    BYTE abReasonNum[2];                                                                // SDH 26-11-04 CREDIT CLAIM
    BYTE abReceivingStoreNum[4];                                                        // SDH 26-11-04 CREDIT CLAIM
    BYTE abDestination[2];                                                              // SDH 26-11-04 CREDIT CLAIM
    BYTE cWarehouseRoute;                                                               // SDH 26-11-04 CREDIT CLAIM
    BYTE abUODType[2];                                                                  // SDH 26-11-04 CREDIT CLAIM
    BYTE abDamageRsn[2];                                                                // SDH 26-11-04 CREDIT CLAIM
} LRT_UOX;                                                                              // SDH 26-11-04 CREDIT CLAIM
#define LRT_UOX_LTH sizeof(LRT_UOX)                                                     // SDH 26-11-04 CREDIT CLAIM

typedef struct LRT_DSS_Txn {                  // Get Direct Supplier List Start         // SDH 26-11-04 CREDIT CLAIM
    BYTE abCmd[3];                                                                      // SDH 26-11-04 CREDIT CLAIM
    BYTE abOpID[3];                                                                     // SDH 26-11-04 CREDIT CLAIM
} LRT_DSS;                                                                              // SDH 26-11-04 CREDIT CLAIM
#define LRT_DSS_LTH sizeof(LRT_DSS)                                                     // SDH 26-11-04 CREDIT CLAIM

typedef struct LRT_DSG_Txn {                  // Get Direct Supplier List Item          // SDH 26-11-04 CREDIT CLAIM
    BYTE abCmd[3];                                                                      // SDH 26-11-04 CREDIT CLAIM
    BYTE abOpID[3];                                                                     // SDH 26-11-04 CREDIT CLAIM
    BYTE cBusCentre;                                                                    // SDH 26-11-04 CREDIT CLAIM
    BYTE abNextSeqNum[4];                                                               // SDH 26-11-04 CREDIT CLAIM
} LRT_DSG;                                                                              // SDH 26-11-04 CREDIT CLAIM
#define LRT_DSG_LTH sizeof(LRT_DSG)                                                     // SDH 26-11-04 CREDIT CLAIM

typedef struct LRT_DSE_Txn {                  // Direct Supplier List End               // SDH 26-11-04 CREDIT CLAIM
    BYTE abCmd[3];                                                                      // SDH 26-11-04 CREDIT CLAIM
} LRT_DSE;                                                                              // SDH 26-11-04 CREDIT CLAIM
#define LRT_DSE_LTH sizeof(LRT_DSE)                                                     // SDH 26-11-04 CREDIT CLAIM

typedef struct LRT_DSR_Txn {                  // Direct Supplier List Response          // SDH 26-11-04 CREDIT CLAIM
    BYTE abCmd[3];                                                                      // SDH 26-11-04 CREDIT CLAIM
    BYTE cBusCentre;                                                                    // SDH 26-11-04 CREDIT CLAIM
    BYTE abSeqNum[4];                                                                   // SDH 26-11-04 CREDIT CLAIM
    BYTE abSupplierNum[6];                                                              // SDH 26-11-04 CREDIT CLAIM
    BYTE abSupplierName[10];                                                            // SDH 26-11-04 CREDIT CLAIM
} LRT_DSR;                                                                              // SDH 26-11-04 CREDIT CLAIM
#define LRT_DSR_LTH sizeof(LRT_DSR)                                                     // SDH 26-11-04 CREDIT CLAIM

typedef struct LRT_UOQ_Txn {                  // UOD Item Query                         // SDH 26-11-04 CREDIT CLAIM
    BYTE abCmd[3];                                                                      // SDH 26-11-04 CREDIT CLAIM
    BYTE abOpID[3];                                                                     // SDH 26-11-04 CREDIT CLAIM
    BYTE abUODNum[14];                                                                  // SDH 26-11-04 CREDIT CLAIM
} LRT_UOQ;                                                                              // SDH 26-11-04 CREDIT CLAIM
#define LRT_UOQ_LTH sizeof(LRT_UOQ)                                                     // SDH 26-11-04 CREDIT CLAIM

typedef struct LRT_STQ_Txn {                // Stock take query                         // SDH 26-11-04 CREDIT CLAIM
    BYTE abCmd[3];                                                                      // SDH 26-11-04 CREDIT CLAIM
    BYTE abOpID[3];                                                                     // SDH 26-11-04 CREDIT CLAIM
    BYTE abUODPrefix[8];                                                                // SDH 26-11-04 CREDIT CLAIM
} LRT_STQ;                                                                              // SDH 26-11-04 CREDIT CLAIM
#define LRT_STQ_LTH sizeof(LRT_STQ)                                                     // SDH 26-11-04 CREDIT CLAIM

typedef struct LRT_STR_Txn {                                                            // SDH 26-11-04 CREDIT CLAIM
    BYTE abCmd[3];                                                                      // SDH 26-11-04 CREDIT CLAIM
    BYTE abUODPrefix[8];                                                                // SDH 26-11-04 CREDIT CLAIM
    BYTE abUODSuffix[6];                                                                // SDH 26-11-04 CREDIT CLAIM
} LRT_STR;                                                                              // SDH 26-11-04 CREDIT CLAIM
#define LRT_STR_LTH sizeof(LRT_STR)                                                     // SDH 26-11-04 CREDIT CLAIM

typedef struct LRT_DNQ_Txn {
    BYTE abCmd[3];
    BYTE abOpID[3];
    BYTE abDealNum[4];
} LRT_DNQ;
#define LRT_DNQ_LTH sizeof(LRT_DNQ)                                                     // SDH 25-03-2005 Promotions

typedef struct LRT_DQR_Txn {
    BYTE abCmd[3];
    BYTE abDealNum[4];
    BYTE abStartDate[8];
    BYTE abEndDate[8];
    BYTE abDealDesc[35];
} LRT_DQR;
#define LRT_DQR_LTH sizeof(LRT_DQR)

typedef struct {                                                                        // SDH 25-Aug-2006 Planners
    BYTE abCmd[3];                                                                      // SDH 25-Aug-2006 Planners
    BYTE abOpID[3];                                                                     // SDH 25-Aug-2006 Planners
} LRT_PGS;                                                                              // SDH 25-Aug-2006 Planners
#define LRT_PGS_LTH sizeof(LRT_PGS)                                                     // SDH 25-Aug-2006 Planners

typedef struct {                                                                        // SDH 25-Aug-2006 Planners
    BYTE abCmd[3];                                                                      // SDH 25-Aug-2006 Planners
    BYTE abOpID[3];                                                                     // SDH 25-Aug-2006 Planners
} LRT_PGX;                                                                              // SDH 25-Aug-2006 Planners
#define LRT_PGX_LTH sizeof(LRT_PGX)                                                     // SDH 25-Aug-2006 Planners

typedef struct {                                                                        // SDH 25-Aug-2006 Planners
    BYTE abCmd[3];                                                                      // SDH 25-Aug-2006 Planners
    BYTE abOpID[3];                                                                     // SDH 25-Aug-2006 Planners
    BYTE abFamilyRecNum[4];                                                             // SDH 25-Aug-2006 Planners
    BYTE cCoreFlag;                                                                     // SDH 25-Aug-2006 Planners
    BYTE cLivePend;                                                                     // SDH 25-Aug-2006 Planners
} LRT_PGF;                                                                              // SDH 25-Aug-2006 Planners
#define LRT_PGF_LTH sizeof(LRT_PGF)                                                     // SDH 25-Aug-2006 Planners

typedef struct {                                                                        // SDH 25-Aug-2006 Planners
    BYTE abSeq[4];                                                                      // SDH 25-Aug-2006 Planners
    BYTE abDesc[50];                                                                    // SDH 25-Aug-2006 Planners
    BYTE abStartPOGIRec[6];                                                             // SDH 25-Aug-2006 Planners
    BYTE abFamilyType[2];                                                               // SDH 25-Aug-2006 Planners
    BYTE abHierachy[2];                                                                 // SDH 25-Aug-2006 Planners
} LRT_PGG_FAM;                                                                          // SDH 25-Aug-2006 Planners
#define PGG_NUM_FAMS    4                                                               // SDH 25-Aug-2006 Planners
typedef struct {                                                                        // SDH 25-Aug-2006 Planners
    BYTE abCmd[3];                                                                      // SDH 25-Aug-2006 Planners
    LRT_PGG_FAM aFam[PGG_NUM_FAMS];                                                     // SDH 25-Aug-2006 Planners
    BYTE cMoreToCome;                   //Y or N                                        // SDH 25-Aug-2006 Planners
} LRT_PGG;                                                                              // SDH 25-Aug-2006 Planners
#define LRT_PGG_LTH sizeof(LRT_PGG)                                                     // SDH 25-Aug-2006 Planners

typedef struct {                                                                        // SDH 25-Aug-2006 Planners
    BYTE abCmd[3];                                                                      // SDH 25-Aug-2006 Planners
    BYTE abOpID[3];                                                                     // SDH 25-Aug-2006 Planners
    BYTE abPOGIRec[6];                                                                  // SDH 25-Aug-2006 Planners
    BYTE cLivePend;  //L or P                                                           // SDH 25-Aug-2006 Planners
} LRT_PGQ;                                                                              // SDH 25-Aug-2006 Planners
#define LRT_PGQ_LTH sizeof(LRT_PGQ)                                                     // SDH 25-Aug-2006 Planners

typedef struct {                                                                        // SDH 25-Aug-2006 Planners
    BYTE abPOGKey[6];                                                                   // SDH 25-Aug-2006 Planners
    BYTE abDesc[50];                                                                    // SDH 25-Aug-2006 Planners
    BYTE abActiveDate[8];                                                               // SDH 25-Aug-2006 Planners
    BYTE abDeactiveDate[8];                                                             // SDH 25-Aug-2006 Planners
    BYTE abModuleCount[3];                                                              // SDH 25-Aug-2006 Planners
} LRT_PGR_POG;                                                                          // SDH 25-Aug-2006 Planners
#define PGR_NUM_POGS    4                                                               // SDH 25-Aug-2006 Planners
typedef struct {                                                                        // SDH 25-Aug-2006 Planners
    BYTE abCmd[3];                                                                      // SDH 25-Aug-2006 Planners
    LRT_PGR_POG aPOG[PGR_NUM_POGS];                                                     // SDH 25-Aug-2006 Planners
    BYTE abNextPOGIRec[6];      //FFFFFF=Last one                                       // SDH 25-Aug-2006 Planners
} LRT_PGR;                                                                              // SDH 25-Aug-2006 Planners
#define LRT_PGR_LTH sizeof(LRT_PGR)                                                     // SDH 25-Aug-2006 Planners

typedef struct {                                                                        // SDH 25-Aug-2006 Planners
    BYTE abCmd[3];                                                                      // SDH 25-Aug-2006 Planners
    BYTE abOpID[3];                                                                     // SDH 25-Aug-2006 Planners
    BYTE abPOGKey[6];                                                                   // SDH 25-Aug-2006 Planners
    BYTE abModSeq[3];       //Base 0                                                    // SDH 25-Aug-2006 Planners
    BYTE abBootsCode[6];    //"FFFFFF" no filter                                        // PAB 16-Nov 2006
    //BYTE cChain;            //Base 0                                                    // SDH 25-Aug-2006 Planners
    //BYTE cLivePend;         //L or P                                                    // SDH 25-Aug-2006 Planners
} LRT_PGM;                                                                              // SDH 25-Aug-2006 Planners
#define LRT_PGM_LTH sizeof(LRT_PGM)                                                     // SDH 25-Aug-2006 Planners

typedef struct {
    BYTE abModSeq[3];       //Base 0                                                    // SDH 25-Aug-2006 Planners
    BYTE abModuleDesc[50];                                                              // SDH 25-Aug-2006 Planners
    BYTE abShelfCount[2];                                                               // SDH 25-Aug-2006 Planners
    BYTE abFilter[1];                                                                   // PAB 16=Nov-2006
} LRT_PGM_MOD;                                                                          // SDH 25-Aug-2006 Planners
#define PGN_NUM_MODS    4                                                               // SDH 25-Aug-2006 Planners
typedef struct {                                                                        // SDH 25-Aug-2006 Planners
    BYTE abCmd[3];                                                                      // SDH 25-Aug-2006 Planners
    LRT_PGM_MOD aMod[PGN_NUM_MODS];                                                     // SDH 25-Aug-2006 Planners
    BYTE cMoreToCome;                                                                   // SDH 25-Aug-2006 Planners
} LRT_PGN;                                                                              // SDH 25-Aug-2006 Planners
#define LRT_PGN_LTH sizeof(LRT_PGN)                                                     // SDH 25-Aug-2006 Planners

//typedef struct {                                                                        // SDH 25-Aug-2006 Planners
//    BYTE abCmd[3];                                                                      // SDH 25-Aug-2006 Planners
//    BYTE abOpID[3];                                                                     // SDH 25-Aug-2006 Planners
//    BYTE abPOGDataBlast[5][20]; //todo                                                  // SDH 25-Aug-2006 Planners
//} LRT_PPL;                                                                              // SDH 25-Aug-2006 Planners
//#define LRT_PPL_LTH sizeof(LRT_PPL)                                                     // SDH 25-Aug-2006 Planners

typedef struct {                                                                        // SDH 25-Aug-2006 Planners
    BYTE abCmd[3];                                                                      // SDH 25-Aug-2006 Planners
    BYTE abOpID[3];                                                                     // SDH 25-Aug-2006 Planners
    BYTE abPOGKey[6];                                                                   // SDH 25-Aug-2006 Planners
    BYTE abModSeq[3];       //Base 0                                                    // SDH 25-Aug-2006 Planners
    BYTE abShelfNum[3];                                                                 // SDH 25-Aug-2006 Planners    
    BYTE abNextChain[2];    //Base 0                                                    // SDH 25-Aug-2006 Planners
    BYTE abNextItem[2];     //Base 0                                                    // PAB 30 Nov-2006 Planners
} LRT_PSL;                                                                              // SDH 25-Aug-2006 Planners
#define LRT_PSL_LTH sizeof(LRT_PSL)                                                     // SDH 25-Aug-2006 Planners

typedef struct {                                                                        // SDH 25-Aug-2006 Planners
    BYTE abItemCode[6];                                                                 // SDH 25-Aug-2006 Planners
    BYTE abDesc[24];                                                                    // SDH 25-Aug-2006 Planners
    BYTE abFacings[2];                                                                  // SDH 25-Aug-2006 Planners
} LRT_PSR_IOS;                                                                          // SDH 25-Aug-2006 Planners
#define PSR_NUM_ITEMS   15                                                              // SDH 25-Aug-2006 Planners
typedef struct {                                                                        // SDH 25-Aug-2006 Planners
    BYTE abCmd[3];                                                                      // SDH 25-Aug-2006 Planners
    BYTE abNotchNum[3];                                                                 // PAB 14-Nov-2006 Planners
    BYTE abShelfDesc[50];                                                               // SDH 25-Aug-2006 Planners
    LRT_PSR_IOS aShelfItem[PSR_NUM_ITEMS];                                              // SDH 25-Aug-2006 Planners
    BYTE abNextShelf[3];
    BYTE abNextChain[2];                                                                // SDH 25-Aug-2006 Planners
    BYTE abNextItem[2];                                                                 // SDH 25-Aug-2006 Planners
} LRT_PSR;                                                                              // PAB 30-Nov-2006 Planners
#define LRT_PSR_LTH sizeof(LRT_PSR)                                                     // SDH 25-Aug-2006 Planners

typedef struct {                                                                        // SDH 25-Aug-2006 Planners
    BYTE abPOGKey[6];   //TODO                                                          // SDH 25-Aug-2006 Planners
    BYTE abDesc[50];                                                                    // SDH 25-Aug-2006 Planners
} LRT_PPR_POG;                                                                          // SDH 25-Aug-2006 Planners
typedef struct {                                                                        // SDH 25-Aug-2006 Planners
    BYTE abCmd[3];                                                                      // SDH 25-Aug-2006 Planners
    LRT_PPR_POG aPOG[20];   //TODO                                                      // SDH 25-Aug-2006 Planners
} LRT_PPR;                                                                              // SDH 25-Aug-2006 Planners
#define LRT_PPR_LTH sizeof(LRT_PPR)                                                     // SDH 25-Aug-2006 Planners

typedef struct {                                                                        // SDH 25-Aug-2006 Planners
    BYTE abCmd[3];                                                                      // SDH 25-Aug-2006 Planners
    BYTE abOpID[3];                                                                     // SDH 25-Aug-2006 Planners
    BYTE abItemCode[6];                                                                 // SDH 25-Aug-2006 Planners
    BYTE abStartChain[3];                                                               // SDH 25-Aug-2006 Planners
    BYTE abStartMod[3];                                                                 // SDH 25-Aug-2006 Planners
    BYTE cLivePend;         //L or P                                                    // SDH 25-Aug-2006 Planners
} LRT_PGL;                                                                              // SDH 25-Aug-2006 Planners
#define LRT_PGL_LTH sizeof(LRT_PGL)                                                     // SDH 25-Aug-2006 Planners

typedef struct {                                                                        // SDH 25-Aug-2006 Planners
    BYTE abCmd[3];                                                                      // SDH 25-Aug-2006 Planners
    BYTE abOpID[3];                                                                     // SDH 25-Aug-2006 Planners
    BYTE abPOGKey[6];                                                                   // SDH 25-Aug-2006 Planners
    BYTE abMod[3];                                                                      // SDH 25-Aug-2006 Planners
    BYTE cType;                                                                         // SDH 25-Aug-2006 Planners
} LRT_PRP;                                                                              // SDH 25-Aug-2006 Planners
#define LRT_PRP_LTH sizeof(LRT_PRP)                                                     // SDH 25-Aug-2006 Planners

typedef struct {                                                                        // SDH 25-Aug-2006 Planners
    BYTE abKey[6];                                                                      // SDH 25-Aug-2006 Planners
    BYTE abDesc[50];                                                                    // SDH 25-Aug-2006 Planners
    BYTE abModuleCount[3];
} Pog;                                                                                  // SDH 25-Aug-2006 Planners
#define PGI_NUM_POGS    4                                                               // SDH 25-Aug-2006 Planners
typedef struct {                                                                        // SDH 25-Aug-2006 Planners
    BYTE abCmd[3];                                                                      // SDH 25-Aug-2006 Planners
    Pog aPog[PGI_NUM_POGS];                                                             // SDH 25-Aug-2006 Planners
    BYTE abNextChain[3];  //FFF if no more                                              // SDH 25-Aug-2006 Planners
    BYTE abNextMod[3];    //FFF if no more                                              // SDH 25-Aug-2006 Planners 
} LRT_PGI;                                                                              // SDH 25-Aug-2006 Planners
#define LRT_PGI_LTH sizeof(LRT_PGI)                                                     // SDH 25-Aug-2006 Planners


// NOTE the Keys below are in INTEL format                                              // SDH 26-11-04 CREDIT CLAIM
// so reverse the key, OR use the macro below                                           // SDH 26-11-04 CREDIT CLAIM
#define CMD(a,b,c) ((LONG)c<<16) + ((LONG)b<<8) + (LONG)a                               // SDH 26-11-04 CREDIT CLAIM

// LRT Command Lookup (inbound commands)
#define CMD_NULL  0x00000000L        // 15-7-2004 to trap null commands PAB
#define CMD_CLC   0x00434C43L
#define CMD_CLF   0x00464C43L
#define CMD_CLO   0x004F4C43L
#define CMD_CLR   0x00524C43L
#define CMD_CLS   0x00534C43L
#define CMD_CLX   0x00584C43L
#define CMD_DNQ   CMD('D','N','Q')                                                      // SDH 26-11-04 CREDIT CLAIM
#define CMD_DSS   CMD('D','S','S')                                                      // SDH 26-11-04 CREDIT CLAIM
#define CMD_DSG   CMD('D','S','G')                                                      // SDH 26-11-04 CREDIT CLAIM
#define CMD_ENQ   0x00514E45L
#define CMD_GAP   0x00504147L
#define CMD_GAS   0x00534147L
#define CMD_GAX   0x00584147L
#define CMD_INS   0x00534E49L
#define CMD_INX   0x00584E49L
#define CMD_ISE   0x00455349L
#define CMD_OFF   0x0046464FL
#define CMD_PAL   0x004C4150L
#define CMD_PAR   0x00524150L
#define CMD_PAS   0x00534150L
#define CMD_PAX   0x00584150L
#define CMD_PCD   0x00444350L
#define CMD_PCM   0x004D4350L
#define CMD_PCS   0x00534350L
#define CMD_PCX   0x00584350L
#define CMD_PDT   0x00544450L
#define CMD_PGF   CMD('P','G','F')                                          //SDH 14-Sep-2006 Planners
#define CMD_PGG   CMD('P','G','G')                                          //SDH 14-Sep-2006 Planners
#define CMD_PGI   CMD('P','G','I')                                          //SDH 14-Sep-2006 Planners
#define CMD_PGL   CMD('P','G','L')                                          //SDH 14-Sep-2006 Planners
#define CMD_PGM   CMD('P','G','M')                                          //SDH 14-Sep-2006 Planners
#define CMD_PGN   CMD('P','G','N')                                          //SDH 14-Sep-2006 Planners
#define CMD_PGQ   CMD('P','G','Q')                                          //SDH 14-Sep-2006 Planners
#define CMD_PGR   CMD('P','G','R')                                          //SDH 14-Sep-2006 Planners
#define CMD_PGS   CMD('P','G','S')                                          //SDH 14-Sep-2006 Planners
#define CMD_PGX   CMD('P','G','X')                                          //SDH 14-Sep-2006 Planners
#define CMD_PLC   0x00434C50L
#define CMD_PLF   0x00464C50L
#define CMD_PLO   0x004F4C50L
#define CMD_PLR   0x00524C50L
#define CMD_PLS   0x00534C50L
#define CMD_PLU   0x00554C50L
#define CMD_PLX   0x00584C50L
#define CMD_PPL   CMD('P','P','L')                                          //SDH 14-Sep-2006 Planners
#define CMD_PPR   CMD('P','P','R')                                          //SDH 14-Sep-2006 Planners
#define CMD_PRP   CMD('P','R','P')                                          //SDH 14-Sep-2006 Planners
#define CMD_PRT   0x00545250L
#define CMD_PSL   CMD('P','S','L')                                          //SDH 14-Sep-2006 Planners
#define CMD_PSR   CMD('P','S','R')                                          //SDH 14-Sep-2006 Planners
#define CMD_RCA   CMD('R','C','A')                                         // PAB 22-map-2007 Recalls
#define CMD_RCB   CMD('R','C','B')                                         // PAB 22-map-2007 Recalls
#define CMD_RCC   CMD('R','C','C')                                         // PAB 22-map-2007 Recalls
#define CMD_RCD   CMD('R','C','D')                                         // PAB 22-map-2007 Recalls
#define CMD_RCE   CMD('R','C','E')                                         // PAB 22-map-2007 Recalls
#define CMD_RCF   CMD('R','C','F')                                         // PAB 22-map-2007 Recalls
#define CMD_RCG   CMD('R','C','G')                                         // PAB 22-map-2007 Recalls
#define CMD_RCH   CMD('R','C','H')                                         // PAB 22-map-2007 Recalls
#define CMD_RCI   CMD('R','C','I')                                         // PAB 22-map-2007 Recalls
#define CMD_RCJ   CMD('R','C','J')                                         // PAB 22-map-2007 Recalls
#define CMD_RLE   0x00454C52L
#define CMD_RLS   0x00534C52L
#define CMD_RPO   0x004F5052L
#define CMD_RPS   0x00535052L
#define CMD_RPX   0x00585052L
#define CMD_RSP   0x00505352L
#define CMD_SAK   0x0053414BL       // PAB 5-5-4 Pre-Scan 
#define CMD_SIE   0x00454953L
#define CMD_SIR   0x00534953L
#define CMD_SOR   0x00524F53L
#define CMD_SUS   0x00535553L       // PAB 5-5-4 Pre-Scan
#define CMD_SSE   0x00455353L
#define CMD_STQ   CMD('S','T','Q')                                                      // SDH 26-11-04 CREDIT CLAIM
#define CMD_UIS   CMD('U','I','S')                                                      // SDH 26-11-04 CREDIT CLAIM
#define CMD_UIG   CMD('U','I','G')                                                      // SDH 26-11-04 CREDIT CLAIM
#define CMD_UOA   CMD('U','O','A')                                                      // SDH 26-11-04 CREDIT CLAIM
#define CMD_UOD   CMD('U','O','D')                                                      // SDH 26-11-04 CREDIT CLAIM
#define CMD_UOQ   CMD('U','O','Q')                                                      // SDH 26-11-04 CREDIT CLAIM
#define CMD_UOS   CMD('U','O','S')                                                      // SDH 26-11-04 CREDIT CLAIM
#define CMD_UOX   CMD('U','O','X')                                                      // SDH 26-11-04 CREDIT CLAIM
#define CMD_UNK   0x00FFFFFFL
#define CMD_XXX   0x00585858L       // Low-level handheld transactions - keep alive

typedef struct General_Enquiry {
    BYTE boots_code[7];         // IRF
    BYTE parent_code[7];        // IDF
    BYTE item_desc[24];         // IDF
    BYTE item_price[6];         // IRF
    BYTE sel_desc[45];          // ISF
    BYTE status[1];             // IDF                            
    BYTE stock_figure[6];       // VARIOUS                             v2.1
    BYTE supply_method[1];      // IDF
    BYTE redeemable[1];         // IRF
    //BYTE deal_num[4];         // IRF                                 v3.0
    BYTE active_deal_flag[1];   // IRF                                 v3.0
    BYTE item_code[13];         // IRF (incl. calculated check digit)  v2.1
    BYTE items_sold_today[6];   // IMSTC (singles, not 1/100ths)       v2.1
    UBYTE idf_bit_flags_2;      // IDF                                 v2.1
    BYTE pcheck_exempt[1];      // PGF YN //PAB 23-10-03
    BYTE date_last_delivery[3]; // STOCK  //PAB 20-10-04
    BYTE cBusCentre;            // IDF    //SDH 17-11-04 OSSR WAN
    BYTE cOssrItem;             // RFHIST/PGF 'Y' or 'N'                    //SDH 17-11-04 OSSR WAN
    BYTE cPgfOssrFlag;          // PGF 'Y' or 'N'                           //SDH 18-03-05 OSSR WAN
    DEALSUM Deal[10];           // Internal deal table                      //SDH 17-11-04 OSSR WAN
    BYTE abCoreCount[3];        // From SRITML                              //SDH 22-Sep-2006 Planners
    BYTE abNonCoreCount[3];     // From SRITML                              //SDH 22-Sep-2006 Planners
    BYTE cRecallFlag[1];        // From IRF                                 //PAB 22-May-2007 Recalls
} ENQUIRY;                      // General enquiry block
#define ENQUIRY_LTH sizeof(ENQUIRY)

// Global Return Code Stuff
typedef WORD URC;
#define RC_FATAL_ERR     (-128)  // Serious error - Application must end
#define RC_SERIOUS_ERR   (-100)  // Serious error - Application can continue
#define RC_FILE_ERR       (-40)  // File(s) missing at point of access
#define RC_DATA_ERR       (-30)  // General file error - see appl event logs
#define RC_IGNORE_ERR      (-1)  // Error can be ignored - see appl event logs
#define RC_OK               (0)  // Success

// LRT Application States
#define ST_FREE         0                       // Must be zero
#define ST_LOGGED_ON    1
#define ST_RECEIVING    2
#define ST_CLOSING      3
#define ST_STACKED      4

// Process queue states
#define PST_FREE        0
#define PST_ALLOC       1
#define PST_READY       2
#define PST_ADOPTED     3   //SDH 22-June-2006
#define PST_RUNNING     4   //PAB 26-January-2007

// File close flags
#define CL_SESSION      0
#define CL_ALL          1

// Access conflict parms
#define AC_RETRY_DELAY  10
#define AC_MAX_RETRY    12

// gap system flag settings
#define SYS_LAB         0
#define SYS_GAP         1
#define SYS_ORPHAN      2

// audit file (LRTLG) record types
#define LOG_SOR         0
#define LOG_OFF         1
#define LOG_GAS         2
#define LOG_PCM         3
#define LOG_GAX         4
#define LOG_PLX         5
#define LOG_PCS         6
#define LOG_PCX         7
#define LOG_PRT         8
#define LOG_CSS         9   // <v4.0
#define LOG_CSE        10   // <v4.0
#define LOG_TVR        11   // <v4.0
#define LOG_CRQ        12   // <v4.0
#define LOG_CLS        13   // v4.0
#define LOG_CLC        14   // v4.0
#define LOG_CLX        15   // v4.0
#define LOG_SUS        16   // 5-5-04 PAB
#define LOG_ENQ        17   // 2-7-04 PAB
#define LOG_UOS        18
#define LOG_UOA        19
#define LOG_UOX        20
#define LOG_UOQ        21
#define LOG_DSS        22
#define LOG_DSG        23
#define LOG_STQ        24
#define LOG_DNQ        25
#define LOG_PGS        26
#define LOG_PGX        27
#define LOG_PGF        28
#define LOG_PGQ        29
#define LOG_PGM        30
#define LOG_PPL        31
#define LOG_PSL        32
#define LOG_PGL        33
#define LOG_PRP        34
#define LOG_RCA        35  // 22-5-07 PAB Recalls
#define LOG_RCB        36  // 22-5-07 PAB Recalls
//#define LOG_RCC        37  // 22-5-07 PAB Recalls
#define LOG_RCD        38  // 22-5-07 PAB Recalls
//#define LOG_RCE        39  // 22-5-07 PAB Recalls
//#define LOG_RCF        40  // 22-5-07 PAB Recalls
//#define LOG_RCG        41  // 22-5-07 PAB Recalls
#define LOG_RCH        42  // 22-5-07 PAB Recalls
#define LOG_RCI        43  // 22-5-07 PAB Recalls
#define LOG RCJ        44  // 22-5-07 PAB Recalls

// Stock enquiry types
#define SENQ_BOOTS      0
#define SENQ_DESC       1
#define SENQ_SELD       2
#define SENQ_TSF        3

// v4.01
#include "debug.h"
//// Debug
//#define DBG_LOCAL        0
//#define DBG_FILE         1
// v4.01

//////////////////////////////////////////////////////////////////////////////
/// Define log levels.
/// LOG_CRITICAL means log all errors except record not found or EOF
//////////////////////////////////////////////////////////////////////////////
#define LOG_NONE     0
#define LOG_CRITICAL 1
#define LOG_ALL      2


//static BYTE *rfs = {"RFS"};

//Useful macro
#define MEMCPY(a,b) memcpy(a,b,sizeof(a))                                   //SDH 14-Sep-2006 Planners
#define MEMSET(a,b) memset(a,b,sizeof(a))                                   //SDH 14-Sep-2006 Planners

// Function prototypes
VOID form_timestamp( BYTE *buf, WORD lth );
WORD satoi( BYTE *str, WORD lth );
LONG satol( BYTE *str, WORD lth );
void WordToArray(BYTE *pbDest, UWORD uwDestLen, WORD wNum);                 //SDH 14-Sep-2006 Planners
void LongToArray(BYTE *pbDest, UWORD uwDestLen, LONG lNum);                 //SDH 14-Sep-2006 Planners
#define WORD_TO_ARRAY(a,b) WordToArray(a, sizeof(a), b)                     //SDH 14-Sep-2006 Planners
#define LONG_TO_ARRAY(a,b) LongToArray(a, sizeof(a), b)                     //SDH 14-Sep-2006 Planners
LONG OpenDirectFile( BYTE *fname, UWORD flags,
                     WORD report, BOOLEAN fLogError);
LONG OpenKeyedFile( BYTE *fname, UWORD flags,
                    WORD report, BOOLEAN fLogError);
URC log_file_open( LONG filenum, BYTE ftype );
URC open_rfscf( void );
URC close_rfscf( WORD type );
URC open_irf( void );
URC close_irf( WORD type );
URC open_irfdex( void );                                                    //SDH 15-01-2005 Promotions
URC close_irfdex( WORD type );                                              //SDH 15-01-2005 Promotions
URC open_idf( void );
URC close_idf( WORD type );
LONG ReadIdf(LONG lLineNumber);                                             // SDH 10-03-2005 EXCESS
URC open_stock( void );
URC close_stock( WORD type );
LONG ReadStock(LONG lLineNumber);                                           //SDH 10-03-2005 EXCESS
URC open_citem( void );
URC close_citem( WORD type );
URC open_imstc( void );
URC close_imstc( WORD type );
URC open_cimf( void );
URC close_cimf( WORD type );
URC open_af( void );
URC close_af( WORD type );
URC open_isf( void );
URC close_isf( WORD type );
LONG ReadIsf(LONG lLineNumber);                                             // SDH 9-Oct-2006 Planners
URC open_pgf( void );                                                       // PAB 23-10-03
URC close_pgf( WORD type );                                                 // PAB 23-10-03
LONG ReadPgf(LONG lLineNumber);                                             // SDH 26-01-2005
LONG WritePgf(LONG lLineNumber);                                            // SDH 26-01-2005
URC open_suspt( void );                                                     // PAB 5-5-04
URC close_suspt( WORD type );                                               // PAB 5-5-04
URC open_stkmq( void );
URC close_stkmq( WORD type );
URC open_imfp( void );
URC close_imfp( WORD type );
URC open_pllol( void );
URC close_pllol( WORD type );
LONG ReadPllol(LONG lRecNum, LONG lLineNum);                                // SDH 19-11-2004 OSSR WAN
LONG ReadPllolLog(LONG lRecNum, LONG lLineNum, WORD wLogLevel);             // SDH 19-11-2004 OSSR WAN
LONG WritePllol(LONG lRecNum, LONG lLineNum);                               // SDH 19-11-2004 OSSR WAN
URC open_plldb( void );
URC close_plldb( WORD type );
LONG ReadPlldb(LONG lLineNum);                                              // SDH 19-11-2004 OSSR WAN
LONG ReadPlldbLog(LONG lLineNumber, WORD wLogLevel);                        // SDH 19-11-2004 OSSR WAN
LONG WritePlldb(LONG lLineNum);                                             // SDH 19-11-2004 OSSR WAN
LONG ReadPlldbLock(LONG lLineNum);                                          // SDH 19-11-2004 OSSR WAN
LONG WritePlldbUnlock(LONG lLineNum);                                       // SDH 19-11-2004 OSSR WAN
URC open_rfrdesc( void );
URC close_rfrdesc( WORD type );
URC open_tsfD( void );
URC close_tsf( WORD type );
URC open_psbtD( void );
URC close_psbt( WORD type );
URC open_wrfD( void );
URC close_wrf( WORD type );
URC open_nvurl( void );
URC close_nvurl( WORD type );
URC open_epsom( void );                                                     // v3.0
URC close_epsom( WORD type );                                               // v3.0
URC open_pchk( void );                                                      // v3.0
URC close_pchk( WORD type );                                                // v3.0
URC open_prtctl(void);                                                      // SDH 19-11-2004 OSSR WAN
URC close_prtctl(WORD type);                                                // SDH 19-11-2004 OSSR WAN
URC open_prtlist(void);                                                     // SDH 19-11-2004 OSSR WAN
URC close_prtlist(WORD type);                                               // SDH 19-11-2004 OSSR WAN
URC open_rfhist(void);                                                      // SDH 19-11-2004 OSSR WAN
URC close_rfhist(WORD type);                                                // SDH 19-11-2004 OSSR WAN
LONG ReadRfhist(LONG lLineNumber);                                          // SDH 19-11-2004 OSSR WAN
LONG WriteRfhist(LONG lLineNumber);                                         // SDH 19-11-2004 OSSR WAN
URC open_invok(void);                                                       // SDH 19-11-2004 OSSR WAN
URC close_invok(WORD type);                                                 // SDH 19-11-2004 OSSR WAN
URC open_minls(void);                                                       // SDH 19-11-2004 OSSR WAN
URC close_minls(WORD type);                                                 // SDH 19-11-2004 OSSR WAN
LONG ReadMinls(LONG lLineNumber);                                           // SDH 10-03-2005 EXCESS
LONG WriteMinls(LONG lLineNumber);                                          // SDH 10-03-2005 EXCESS
LONG DeleteMinlsRecord(LONG lLineNumber);                                   // SDH 10-03-2005 EXCESS
URC open_rfsstat(void);                                                     // SDH 19-11-2004 OSSR WAN
URC open_ccdmy_locked(void);                                                // SDH 19-11-2004 OSSR WAN
URC close_ccdmy(void);                                                      // SDH 19-11-2004 OSSR WAN
URC open_clolf(void);                                                       // SDH 19-11-2004 OSSR WAN
URC close_clolf(WORD type);                                                 // SDH 19-11-2004 OSSR WAN
URC open_clilf(void);                                                       // SDH 19-11-2004 OSSR WAN
URC close_clilf(WORD type);                                                 // SDH 19-11-2004 OSSR WAN
URC open_bcsmf(void);                                                       // SDH 19-11-2004 OSSR WAN
URC close_bcsmf(WORD type);                                                 // SDH 19-11-2004 OSSR WAN
LONG ReadBcsmf(LONG lLineNumber);                                           // SDH 19-11-2004 OSSR WAN
URC open_cclol(void);                                                       // SDH 29-11-2004 CREDIT CLAIM
URC close_cclol(WORD type);                                                 // SDH 29-11-2004 CREDIT CLAIM
LONG ReadCclol(LONG wRecNum, LONG lLineNum);                                // SDH 29-11-2004 CREDIT CLAIM
LONG WriteCclol(LONG wRecNum, LONG lLineNum);                               // SDH 29-11-2004 CREDIT CLAIM
URC open_ccilf(void);                                                       // SDH 29-11-2004 CREDIT CLAIM
URC close_ccilf(WORD type);                                                 // SDH 29-11-2004 CREDIT CLAIM
LONG ReadCcilf(LONG lLineNum);                                              // SDH 29-11-2004 CREDIT CLAIM
LONG WriteCcilf(LONG lLineNum);                                             // SDH 29-11-2004 CREDIT CLAIM
URC open_cchist(void);                                                      // SDH 29-11-2004 CREDIT CLAIM
URC close_cchist(WORD type);                                                // SDH 29-11-2004 CREDIT CLAIM
LONG ReadCchist(LONG lLineNum);                                             // SDH 29-11-2004 CREDIT CLAIM
LONG WriteCchist(LONG lLineNumber);                                         // SDH 29-11-2004 CREDIT CLAIM
URC open_ccdirsu(void);                                                     // SDH 29-11-2004 CREDIT CLAIM
URC close_ccdirsu(WORD type);                                               // SDH 29-11-2004 CREDIT CLAIM
LONG ReadCcdirsu(LONG lLineNum);                                            // SDH 29-11-2004 CREDIT CLAIM
URC open_deal(void);                                                        // SDH 29-11-2004 PROMOTIONS
URC close_deal(void);                                                       // SDH 29-11-2004 PROMOTIONS
LONG ReadDeal(LONG lLineNum);                                               // SDH 29-11-2004 PROMOTIONS
LONG ReadDealQuick(void);                                                   // SDH 29-11-2004 PROMOTIONS
URC open_tdtff(void);                                                       // SDH 29-11-2004 PROMOTIONS
URC close_tdtff(void);                                                      // SDH 29-11-2004 PROMOTIONS
LONG ReadTDTFFHeader(LONG lLineNum);                                        // SDH 29-11-2004 PROMOTIONS
URC close_rfsstat(WORD type);                                               // SDH 19-11-2004 OSSR WAN
URC close_pilst(WORD type);                                                 // SDH 19-11-2004 OSSR WAN
URC open_pogok(void);
URC close_pogok(WORD type);
LONG ReadPogok(LONG lRecNum, LONG lLineNumber);
LONG WritePogok(LONG lRecNum, LONG lLineNumber);
URC open_srpog(void);
URC close_srpog(WORD type);
LONG ReadSrpog(LONG lLineNumber);
LONG WriteSrpog(LONG lLineNumber);
URC open_srmod(void);
URC close_srmod(WORD type);
LONG ReadSrmod(LONG lLineNumber);
LONG WriteSrmod(LONG lLineNumber);
URC open_sritml(void);
URC close_sritml(WORD type);
LONG ReadSritml(LONG lLineNumber);
LONG WriteSritml(LONG lLineNumber);
URC open_sritmp(void);
URC close_sritmp(WORD type);
LONG ReadSritmp(LONG lLineNumber);
LONG WriteSritmp(LONG lLineNumber);
URC open_srpogif(void);
URC close_srpogif(WORD type);
LONG ReadSrpogif(LONG lRecNum, LONG lLineNumber);
LONG WriteSrpogif(LONG lRecNum, LONG lLineNumber);
URC open_srpogil(void);
URC close_srpogil(WORD type);
LONG ReadSrpogil(LONG lRecNum, LONG lLineNumber);
LONG WriteSrpogil(LONG lRecNum, LONG lLineNumber);
URC open_srpogip(void);
URC close_srpogip(WORD type);
LONG ReadSrpogip(LONG lRecNum, LONG lLineNumber);
LONG WriteSrpogip(LONG lRecNum, LONG lLineNumber);
URC open_srcat(void);
URC close_srcat(WORD type);
LONG ReadSrcat(LONG lRecNum, LONG lLineNumber);
LONG WriteSrcat(LONG lRecNum, LONG lLineNumber);
URC open_srsdf(void);
URC close_srsdf(WORD type);
LONG ReadSrsdf(LONG lLineNumber);
LONG WriteSrsdf(LONG lLineNumber);
URC open_srsxf(void);
URC close_srsxf(WORD type);
LONG ReadSrsxf(LONG lLineNumber);
LONG WriteSrsxf(LONG lLineNumber);

void prepare_logging();
URC lrt_log( BYTE type, WORD unit, BYTE *details );                         // SDH 19-11-2004 OSSR WAN
void unpack( BYTE *dest, WORD dest_lth, BYTE *source, WORD source_lth,
             WORD start_nibble );
void pack( BYTE *dest, WORD dest_lth,
           BYTE *source, WORD source_lth, WORD start_nibble );
WORD unpack_to_word( BYTE *source, WORD source_lth );
URC alloc_report_buffer( RBUF **rbufp );
URC dealloc_report_buffer( RBUF *rbufp );
URC alloc_lrt_table( UWORD unit );
URC dealloc_lrt_table( UWORD unit );
void dump( BYTE *buff, WORD lth );
void calc_boots_cd( BYTE *bccd, BYTE *bc );
URC create_new_plist( BYTE *ret_list_id, BYTE *user );
URC url_enquiry( BYTE *item_code_unp, LRT_PAR *parp );
URC stock_enquiry( BYTE type, BYTE *item_code_unp, ENQUIRY *dest );
URC sales_enquiry( BYTE *item_code_unp, LONG item_price, LRT_ISR *isrp );
URC store_sales_enquiry( LRT_SSR *ssrp );
LONG item_enquiry( BYTE *boots_code, ENQUIRY *dest );
LONG theoretical_stock_figure( BYTE *item_code_unp );
URC process_gap( BYTE *pass_list_id, BYTE *seq,
                 BYTE *item_code_unp, BYTE *boots_code_unp,
                 BYTE *current, BYTE *fill_qty, BYTE gap_flag, BYTE cOssrItem,  // 17-11-04 SDH OSSR WAN
                 UWORD log_unit );
URC authorise_user( BYTE *user, BYTE *password, BYTE *auth, BYTE *username );
URC prepare_workfile( WORD log_unit, BYTE type );
LONG filesize( BYTE *fname );                                                   // SDH Bug Fix 29-July-2006
URC process_workfile( WORD log_unit, BYTE type );
//LONG rename_workfile( BYTE *curr_name, UBYTE type );
UBYTE semaphore_active( BYTE type );
void process_sel_stack( void );
URC pllol_get_next( /*WORD log_unit,*/ BYTE *list_id, LRT_PLL *pllp );
URC plldb_get_next( /*WORD log_unit,*/ BYTE *list_id, BYTE *seq, LRT_PLI *plip );
URC rfrdesc_get_next( /*WORD log_unit,*/ BYTE *seq, LRT_RLR *rlrp );
URC rfrep_get_next_lev0( WORD log_unit, BYTE *seq,
                         LRT_RLD *rldp, WORD *rec_cnt );
URC rfrep_get_next( WORD log_unit, BYTE *seq,
                    LRT_RUP *rupp, WORD *rec_cnt );
WORD check_command();
void CloseAllFiles( void );
void sysdate( LONG *day, LONG *month, LONG *year,
              WORD *hour, WORD *min, LONG *sec );                            // v4.0
void GetSystemDate(B_TIME* pTime, B_DATE* pDate);                            // 17-11-04 SDH OSSR WAN
DOUBLE emu_round( DOUBLE num );                                              // v4.0
//URC CreateRfhist(BYTE cUpdateOssrItem, LONG lLineNumber);                  // SDH 17-11-04 OSSR WAN
URC ProcessRfhist(BYTE* pbBootsCode, BYTE cUpdateOssrItem, LONG lLineNumber);// SDH 17-11-04 OSSR WAN
URC SetListUnpicked(WORD wListId);                                           // 23-05-2005 SDH Excess
void process_orphans(BOOLEAN fRebuild);                                      // SDH 9-May-2006
URC process_rfok(void);
URC process_jobok(void);
URC log_file_close(LONG filenum);
URC clolf_get_next( /*WORD log_unit,*/ BYTE *list_id, LRT_CLL *cllp );
URC clilf_get_next( /*WORD log_unit,*/ BYTE *list_id, BYTE *seq, LRT_CLI *clip );
void buildSNR(LRT_SNR* pSNR, BYTE* pbPrtNum, BYTE* pbOpID, BYTE bAuth,       // 16-11-2004 SDH
              BYTE* pbUserName, BYTE bOssrStore, BYTE cPlannersActive);      // 25-Sep-2006 SDH Planners
LONG UpdateRfscf(LONG lLineNumber);                                          // 16-11-2004 SDH

void RecallStart(char *inbound);                                    // 24-5-2007 PAB Recalls
void RecallExit(char *inbound);                                     // 24-5-2007 PAB Recalls
void RecallListRequest(char *inbound);                              // 24-5-2007 PAB Recalls
void RecallCount(char *inbound);                                    // 25-5-2007 PAB Recalls
void RecallSelectList(char *inbound);                               // 25-5-2007 PAB recalls
void RecallInstructions(char *inbound);                             // 25-5-2007 PAB recalls
void StopRecalls(void);                                             // 25-5-2007 PAB recalls
URC process_recok(void);                                            // 25-5-2007 PAB recalls
void suspend_transaction(char *inbound);                             // 25-5-2007 PAB 

#endif /* RFS_H not defined */
// recall file globals


