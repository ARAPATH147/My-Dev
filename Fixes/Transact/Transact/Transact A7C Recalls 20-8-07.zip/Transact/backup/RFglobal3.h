// ----------------------------------------------------------------------------------------------
//
// Globals for TRANS03 module
//
// Version A:   Paul Bowers             8th August 2007
//
// ----------------------------------------------------------------------------------------------

PHF_REC phfrec;                                                 // PAB 08-08-2007 MObile Printing
IDUF_REC idufrec;                                               // PAB 10-8-2007 mobile printing
SRITML_REC sritmlrec;                                           // PAB 10-8-2007 mobile printing



