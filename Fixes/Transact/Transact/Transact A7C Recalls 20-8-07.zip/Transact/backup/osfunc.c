/*************************************************************************
* 
* 
* File: osfunc.c
*
* Author: Prashant Kotak
*
* Created: 18/08/97
*
* Purpose: 
*
* History: 
* 
*************************************************************************/ 

#include "transact.h"

#include <flexif.h>
#include "sockserv.h" 
#include "output.h"
#include "osfunc.h" // v4.01

// v4.01
// Function prototypes moved to osfunc.h

// module-wide globals
static char YesterDate[10] ;
static char NowDate[10] ;  
static char FlagDate[10] ;

static long OpenFileForSendTx ( FILEINFO * FileInfo )
{

   LogMessage ( 5, "Opening File %s for Sending", FileInfo->FileName ) ;
   return s_open ( A_READ, FileInfo->FileName ) ;
}

static long OpenFileForReceiveTx ( FILEINFO * FileInfo )
{
   long rc ;
   unsigned int flags ;

   LogMessage ( 5, "Opening File %s for Receive", FileInfo->FileName ) ;

   // is this the first time this file is being opened in a transfer ?
   if ( FileInfo->FilePointer <= 0 ) {
      LogMessage ( 8, "FilePointer <= 0, FileAttr : %Xh", 
                   FileInfo->FileAttributes) ;
      if ( FileInfo->FileAttributes == RF_FILE_REPLACE ) {
         LogMessage ( 8, "File %s to be RF_FILE_REPLACE'ed", 
                      FileInfo->FileName );
         rc = s_delete ( 0x0000, FileInfo->FileName ) ;
         if ( rc != E_SUCCESS ) {
            LogMessage ( 1, "Delete of %s failed %lXh", 
                         FileInfo->FileName, rc ) ;
         } else {
            LogMessage ( 8, "File %s Deleted", FileInfo->FileName );
         }
      }
   }

   flags = A_SET | A_READ | A_WRITE ; // always want to read and write 
   rc = s_open ( flags, FileInfo->FileName ) ;
   if ( rc < E_SUCCESS ) {
      LogMessage ( 7, "Open failed with %lXh, so will create file", rc ) ;
      // file does not exist, so create it with same flags
      rc = s_create ( O_FILE, flags, FileInfo->FileName, 0, FS_NO, 0L );  
      if ( rc < E_SUCCESS ) {
         LogMessage ( 1, "Create of %s failed with %lXh", 
                      FileInfo->FileName, rc ) ;
      }
   }

   return rc;
}

static void CloseFile ( long FileHandle )
{
   s_close ( 0, FileHandle ) ;
}

//static long SeekToEndOfFile ( long FileHandle )
//{
//   return s_seek ( A_EOFOFF, FileHandle, 0L ) ;
//}

static long GetFileSize ( long FileHandle, FILEINFO *FileInfo )
{
   long nbytes ;

   if (FileHandle > 0) {
      FileInfo->FileSize = s_seek ( 0x200, FileHandle, 0 ) ; // record size
      LogMessage ( 9, "File Size = %ld", FileInfo->FileSize ) ;
      nbytes = FileInfo->FileSize ; // record size of file for return
      s_seek ( 0, FileHandle, 0 ) ; // move pointer back to top...
      FileInfo->FilePointer = 0 ; // and indicate that
   } else {
      nbytes = -1 ; // error
   } 

   return nbytes ;
}

static long GetNextFilePacket(long FileHandle, 
                              unsigned char *BufferPtr, 
                              FILEINFO *FileInfo)
{
   long nbytes;

   LogMessage ( 10, "In GetNextFilePacket") ; 
   if (FileHandle > 0) {
      LogMessage ( 10, "Packet Size = %d, FileHandle = %ld, FilePointer = %d", 
                   FileInfo->PacketSize, FileHandle, FileInfo->FilePointer);
      LogMessage ( 10, "BufferPtr: %ld", BufferPtr);

      // read PacketSize bytes
      nbytes = s_read(0x01, FileHandle, (far char *)BufferPtr, 
                      FileInfo->PacketSize, FileInfo->FilePointer);

      LogMessage ( 9, "Read %ld bytes", nbytes ) ; 
   } else {
      nbytes = -1; // error
   } 

   return nbytes;
}

static long PutNextFilePacket( long FileHandle, 
                               unsigned char *BufferPtr, 
                               FILEINFO *FileInfo )
{
   long nbytes, bytes_left ;

   LogMessage ( 10, "In PutNextFilePacket" ) ; 
   if (FileHandle > 0) {
      LogMessage ( 10, "Packet Size = %d, File Handle = %lXh, FilePointer = %d", 
                   FileInfo->PacketSize, FileHandle, FileInfo->FilePointer ) ;
      LogMessage ( 10, "BufferPtr: %lXh", BufferPtr ) ;

      bytes_left = FileInfo->FileSize - FileInfo->FilePointer; 

      nbytes =  bytes_left < FileInfo->PacketSize ? 
                bytes_left : FileInfo->PacketSize ; 
      LogMessage ( 10, "nbytes to Write: %ld ", nbytes ) ;

      // write PacketSize or less bytes
      nbytes = s_write( A_FLUSH | A_EOFOFF, 
                        FileHandle, 
                        ( far char * ) BufferPtr, 
                        nbytes, 0L ) ;

      LogMessage ( 9, "Written %lx bytes", nbytes ) ; 
      //dump (BufferPtr, nbytes);
   } else {
      nbytes = -1; // error
   } 

   return nbytes;
}

static void * MallocShuffle ( char * BufferPtr, int * NewBufferSizePtr )
{
   void * NewMem;

   if (*NewBufferSizePtr < (long) BUFFER_SIZE) {
      LogMessage ( 10, "Not allowed to allocate a buffer smaller then BUFFER_SIZE");
      *NewBufferSizePtr = BUFFER_SIZE ;
   }

   // realloc the buffer to match the size needed
   LogMessage ( 10, "New BufferSize = %ld, BUFFER_SIZE = %ld", 
                *NewBufferSizePtr,  BUFFER_SIZE) ;
   NewMem = AllocateBuffer ( *NewBufferSizePtr ) ;
   if (NewMem != NULL) {
      LogMessage ( 10, "Doing the malloc() shuffle, Old=%ld, New=%ld", 
                   BufferPtr, NewMem ) ;
      // copy only the default size amount of the buffer
      memcpy( ( char * ) NewMem, BufferPtr, ( size_t ) BUFFER_SIZE);
      FreeBuffer ( ( void * ) BufferPtr ) ;
   } else {
      LogMessage ( 1, "New Malloc Failed!" ) ;
   }

   return NewMem;
}

// fills up client->buffer with the file 
// details, also returns the size of the file 
long GetFileDetails(CLIENT *client)
{
   RBSRXFileDetailsStruct *RbsRxFileDetails;
   RBSTXFileDetailsStruct *RbsTxFileDetails;
   DISKFILE FileDetails;
   long nfound, rc;
   char DateTime[10];

   // cast it for easier access to details
   RbsRxFileDetails = (RBSRXFileDetailsStruct *)client->Buffer;
   RbsTxFileDetails = (RBSTXFileDetailsStruct *)client->Buffer;

   LogMessage( 9, "In GetFileDetails, name: %s, bufsize %d", 
               RbsRxFileDetails->FullyQualifiedNullTerminatedFilename,       
               sizeof FileDetails);

   nfound = s_lookup(T_FILE, 0, 
                     RbsRxFileDetails->FullyQualifiedNullTerminatedFilename,       
                     (far char *)&FileDetails,
                     DSKFSIZE, DSKFSIZE, 0L);

   if (nfound > 0) {
      // success, so clear out message area
      memset(RbsTxFileDetails, 0, sizeof RbsTxFileDetails);

      // set up struct header
      memcpy(RbsTxFileDetails->TID, RF_HHT_MSG_RBS_RESERVED, 3);
      RbsTxFileDetails->Command = RF_HHT_MSG_RBS_TX_FILE_DETAILS; 

      sprintf(DateTime, "%4.4d%2.2d%2.2d", FileDetails.df_modyear, 
              FileDetails.df_modmonth, FileDetails.df_modday);
      LogMessage( 7, "Date: %8.8s", DateTime); 
      memcpy(RbsTxFileDetails->FileDateYYYYMMDD, DateTime,
             (sizeof RbsTxFileDetails->FileDateYYYYMMDD)); 


      sprintf(DateTime, "%2.2d%2.2d%2.2d", FileDetails.df_modhr, 
              FileDetails.df_modmin,  FileDetails.df_modsec);
      LogMessage( 7, "Time: %6.6s", DateTime); 
      memcpy(RbsTxFileDetails->FileTimeHHMMSS, DateTime,
             (sizeof RbsTxFileDetails->FileTimeHHMMSS)); 

      RbsTxFileDetails->FileSize = FileDetails.df_size;
      LogMessage( 7, "File Size: %ld", FileDetails.df_size);

      RbsTxFileDetails->FileAttributes = FileDetails.df_attr1;
      LogMessage( 7, "File Attributes: %X", FileDetails.df_attr1);

      //set the length of message to transmit
      client->MessageLen = sizeof ( RBSTXFileDetailsStruct ) ;

      rc = RbsTxFileDetails->FileSize;
   } else {
      // failed
      LogMessage ( 2, "FileDetails s_lookup() on %s failed with %lx",
                   RbsRxFileDetails->FullyQualifiedNullTerminatedFilename,
                   nfound ) ; 
      rc = -1; 
   }
   return rc;
}

void AssignFileInfo( CLIENT * client )
{  
   void * rc;

   //dump ( client->Buffer, 100 );

   rc = AllocateBuffer ( sizeof ( FILEINFO ) ) ;

   client->FileInfo = ( FILEINFO * ) rc ;

   LogMessage( 10, "Attempted %d, Malloc'ed : %ld, rc : %ld", 
               sizeof(FILEINFO), client->FileInfo, rc);

   // lazy man's copy
  // *( ( RBSRXFileStruct * ) client->FileInfo ) = 
  // *( ( RBSRXFileStruct * ) client->Buffer );

   // and initialise the rest of the structure
   client->FileInfo->FilePointer = 0;
   client->FileInfo->Done = 0 ;

   //dump ( client->FileInfo, sizeof ( FILEINFO ) );
}

void ReadNextFilePacket(CLIENT *client)
{
   FILEINFO *FileInfo;
   RBSTXFileHeaderStruct *RbsTXFile;
   int NewBufferSize;
   long fnum, nbytes;
   void * rc;

   FileInfo = client->FileInfo; 

   //dump (client, sizeof(CLIENT));

   // open the file
   fnum = OpenFileForSendTx ( FileInfo );
   LogMessage( 10, "Opened File %s, Handle %lXh", FileInfo->FileName, fnum ) ;
   if ( fnum > 0 ) {
      // Is this is the first time?, if so  
      // we need to work out size of file
      if ( FileInfo->FileSize == -1 ) {
         FileInfo->FilePointer = 0 ;
         nbytes = GetFileSize ( fnum, FileInfo ) ;
         LogMessage ( 10, "File size is %ld", nbytes ) ; 

         // realloc the buffer to match the size needed  
         NewBufferSize = sizeof ( RBSTXFileHeaderStruct ) + 
                         client->FileInfo->PacketSize ;
         rc = MallocShuffle ( client->Buffer,  &NewBufferSize ) ;
         if ( rc != NULL ) {
            client->Buffer = ( char * ) rc ;
            client->BufferSize = NewBufferSize ;
            LogMessage ( 10, "BufferSize set to %d", client->BufferSize ) ;
         } else {
            LogMessage( 1, "MallocShuffle Failed!!" ) ;
         }
      }

      // read PacketSize bytes
      nbytes = GetNextFilePacket ( fnum, ( unsigned char * ) 
                                   ( client->Buffer + sizeof ( RBSTXFileHeaderStruct ) ),  
                                   FileInfo ) ; 
      LogMessage( 10, "Got Next File Packet, nbytes %ld", nbytes ) ;

      if ( nbytes >= 0 ) {
         // adjust file pointer for next packet
         FileInfo->FilePointer += nbytes;

         // have we reached EOF?
         if (FileInfo->FilePointer == FileInfo->FileSize) {
            LogMessage( 9, "File Read Done" ) ;
            FileInfo->Done = 1;
         }

         CloseFile(fnum); // shut down file

         RbsTXFile = (RBSTXFileHeaderStruct *)client->Buffer;

         // indicate (to HHT) that we're sending a 
         // bit 'o file  by setting the appropriate command
         RbsTXFile->Command = RF_HHT_MSG_RBS_TX_FILE;
         RbsTXFile->FileSize = FileInfo->FileSize; 
         LogMessage( 10, "Assigned RbsTXFile->FileSize = %ld", 
                     RbsTXFile->FileSize);

         client->MessageLen = client->BufferSize;
         LogMessage( 10, "File Tx Message Len: %d", client->MessageLen ) ;

      } else {
         // error
         LogMessage( 1, "GetNextFilePacket returned %ld", nbytes);
      }
   } else {
      // error
      
   } 
}

void ProcessFileRxAck(CLIENT *client)
{
   FILEINFO *FileInfo;
   RBSCommandStruct *RbsAndCommand;
   int BufferSize;    
   void * rc ;

   if ( client->FileInfo == ( void * ) NULL) {
      //SetupRbsNakCmd ( client, "FILEINFO", "NOT", "VALID" ) ;
      return ;
   }

   // casts and such to make life easier...
   FileInfo = client->FileInfo;

   if (FileInfo->Done == 1) {
      if (client->FileInfo != (void *)NULL) {
         // dealloc the FILEINFO structure 
         FreeBuffer ((void *) client->FileInfo);

         // and mark it unallocated
         client->FileInfo = (void *)NULL;
      }

      // realloc the buffer to default size  
      BufferSize = BUFFER_SIZE ; 
      rc = MallocShuffle ( client->Buffer, &BufferSize ) ; 
      if (rc != NULL) {
         client->Buffer = ( char * ) rc ; // record new alloc'd buffer
         client->BufferSize = BufferSize; // record the new size of buffer

         LogMessage( 10, "Setting RF_HHT_MSG_RBS_SRV_LSTN" ) ; 

         // file transfer's done, so indicate to client
         // that we're going to listen mode by setting 
         // the appropriate command  
         RbsAndCommand = (RBSCommandStruct *)client->Buffer;
         RbsAndCommand->Command = RF_HHT_MSG_RBS_SRV_LSTN;
         client->MessageLen = sizeof (RBSCommandStruct);
         client->SocketState = AWAITING_DISCONNECT;
      } else {
         LogMessage( 1, "MallocShuffle Failed!!" ) ; 
      }
   } else {
      ReadNextFilePacket(client);
   }
}

void WriteNextFilePacket( CLIENT *client )
{
   FILEINFO *FileInfo;
   RBSCommandStruct *RbsAndCommand;
   int NewBufferSize;
   long fnum, nbytes;
   void * rc ;

   // is this the first time ?
   if ( client->FileInfo  ==  NULL ) {
      // yes, so assign the struct for dealing with transfer
      // this will setup filename etc.
      AssignFileInfo( client ) ; 
      //dump ( client->FileInfo, sizeof ( FILEINFO ) ) ;

      // realloc the buffer to match the size needed  
      NewBufferSize = sizeof ( RBSTXFileHeaderStruct ) + 
                      client->FileInfo->PacketSize ; 
      rc = MallocShuffle ( client->Buffer, &NewBufferSize ) ;
      if ( rc != NULL ) {
         client->Buffer = ( char * ) rc ; 
         client->BufferSize = NewBufferSize;

         LogMessage( 10, "BufferSize set to %d", client->BufferSize ) ;

         RbsAndCommand = (RBSCommandStruct *)client->Buffer; 

         // indicate (to HHT) that we've written a 
         // bit 'o file  by setting the appropriate ACK command
         RbsAndCommand->Command = RF_HHT_MSG_RBS_TX_FILE_ACK; 

         client->MessageLen = sizeof ( RBSCommandStruct ) ; 
      } else {
         LogMessage ( 1, "Malloc Failed!!" ) ;
      }
   } else {

      FileInfo = client->FileInfo;  
      FileInfo->FileSize =  
      ( ( RBSTXFileStruct * ) client->Buffer )->FileSize ;
      //dump (client->Buffer, 100);

      // open the file
      fnum = OpenFileForReceiveTx ( FileInfo ) ;

      if ( fnum < 0 ) {
         //SetupRbsNakCmd ( client, "FILEINFO", "NOT", "VALID" ) ;
         return ;
      }

      LogMessage( 10, "Opened File %s, Handle %lXh", 
                  FileInfo->FileName, fnum ) ;
      if (fnum > 0) {
         // seek to end of file
         // SeekToEndOfFile ( fnum ) ;

         // write PacketSize bytes
         nbytes = PutNextFilePacket( fnum, 
                                     (unsigned char *) (client->Buffer+sizeof(RBSTXFileHeaderStruct)),  
                                     FileInfo ) ; 
         LogMessage ( 10, "Put Next File Packet, nbytes %ld", nbytes ) ;

         if (nbytes >= 0) {
            // adjust file pointer for next packet
            FileInfo->FilePointer += nbytes;

            // have we reached EOF?
            if (FileInfo->FilePointer == FileInfo->FileSize) {
               LogMessage ( 10, "File Write Done" ) ;
               FileInfo->Done = 1;
            }

            RbsAndCommand = (RBSCommandStruct *)client->Buffer; 
            // indicate (to HHT) that we've written a 
            // bit 'o file  by setting the appropriate ACK command
            RbsAndCommand->Command = RF_HHT_MSG_RBS_TX_FILE_ACK; 
            client->MessageLen = sizeof (RBSCommandStruct);
         } else {
            // error
            LogMessage ( 1, "PutNextFilePacket returned %ld", nbytes ) ;
         }
      } else {
         // error
         
      } 

      CloseFile ( fnum ) ; // shut down file

   }
}

void * AllocateBuffer ( long BufferSize )
{
   MPB mpb ; // param block for s_malloc
   long rc ;

   mpb.mp_start = 0L ;
   mpb.mp_min = BufferSize ;
   mpb.mp_max = BufferSize ;

   rc = s_malloc ( O_NEWHEAP, ( MPB * ) &mpb ) ;    
   if ( rc < 0L ) {
      LogMessage ( 1, "s_malloc Failed with %lx !!", rc) ;
   } else {
      LogMessage ( 10, "s_malloc success: %ld", mpb.mp_start ) ;
   }

   return ( void * ) mpb.mp_start ;
}

void FreeBuffer ( void * AllocatedBuffer )
{
   s_mfree ( ( BYTE * ) AllocatedBuffer ) ;
}

void ExitApplication ( void )
{
   s_exit ( 0L ) ;
}

void CtlBrkHandler ( void )
{
   LogMessage ( 1, "CtkBrkHandler!!" ) ;

   ShutDownAllSockets () ;

   if ( DebugFileHandle != NULL ) {
      printf ("Closing Debug File\r\n") ; 
      fclose ( DebugFileHandle ) ;
   }

   ExitApplication();   //SDH 04-05-2005

}

long TermEvent ( void )
{
   long emask ;

   //emask = e_termevent( ( far LONG (*) () ) CtlBrkHandler, 0L ) ;
   emask = e_termevent( ( LONG (*) () ) CtlBrkHandler, 0L ) ; // SDH 19-May-2006

   return emask ;
}

void ProcessGetTime ( CLIENT * client ) 
{
   RBSRecvTimeStruct * SendTime ;
   time_t CurrentTime ;
   struct tm * ptrTime; 

   SendTime = ( RBSRecvTimeStruct *) client->Buffer ;

   SendTime->Command = RF_HHT_MSG_RBS_SEND_TIME ;

   time ( &CurrentTime );

   ptrTime = localtime ( &CurrentTime ) ;

   // Warning NULL character put on end of string
   // ensure client buffer can cope with this!
   sprintf ( SendTime->DateYYYYMMDD, "%4.4d%2.2d%2.2d%2.2d%2.2d%2.2d",
             ptrTime->tm_year,
             ptrTime->tm_mon + 1,
             ptrTime->tm_mday,
             ptrTime->tm_hour,
             ptrTime->tm_min,
             ptrTime->tm_sec         ) ;

   LogMessage ( 8, "System Date Time = %s", SendTime->DateYYYYMMDD ) ;


   //set the length of message to transmit
   client->MessageLen = sizeof ( RBSRecvTimeStruct ) ;
}

void DelayProcess(long MilliSecs)
{
   //long rc ;

   //rc = s_timer ( 0, MilliSecs ) ;
    s_timer ( 0, MilliSecs ) ;
}


int DateHasChanged ( void )
{ 
   struct tm * ptrTime ;
   int retval ; 
   //long nfound ;

   retval = FALSE ; // preset failure

   memcpy ( YesterDate, NowDate, 10 ) ;
   ptrTime = CurrentDateTime () ; 

   sprintf ( NowDate, "%4.4d%2.2d%2.2d", ptrTime->tm_year, 
             ptrTime->tm_mon + 1, ptrTime->tm_mday ) ;  
   LogMessage ( 7, "System Date: %8.8s", NowDate ) ; 

   if ( *YesterDate == 0 ) {
      memcpy ( YesterDate, NowDate, 10 ) ;
   }

   if ( *FlagDate == 0 ) {
      TouchOrCreateFlagFile () ;
   }

   if ( *FlagDate && strcmp ( FlagDate, NowDate ) < 0 ) {
      retval = TRUE;
   }

   return retval ;
}

void CycleHhtLogs ( void )
{ 
   char FileSpec[64] = { 0} ;
   char FileDate[10] = { 0} ;   
   char * TheDate ;

   DISKFILE FileDetails = { 0} ;
   long rc, i ;

   sprintf ( FileSpec, "%s*.%s", SockDir, HhtLogExt ) ;

   LogMessage ( 9, "In CycleHhtLogs, FileSpec: %s", FileSpec ) ;
   for ( rc = 1L, i = 0L ; rc > 0L ; i = FileDetails.df_key ) {
      rc = LookupFileDetails ( FileSpec, i, &FileDetails ) ;
      if ( rc > 0 ) {
         sprintf ( FileDate, "%4.4d%2.2d%2.2d", FileDetails.df_modyear, 
                   FileDetails.df_modmonth, FileDetails.df_modday ) ;

         LogMessage ( 8, "After Lookup, File Name: %s, Date : %s", 
                      FileDetails.df_name, FileDate ) ; 

         DeleteIfOlder ( &FileDetails ) ;
      }
   }

   TouchOrCreateFlagFile () ;

   // Get the date of the live log if poss, else use yesterdays date
   if ( ( rc = GetFileDate ( FileDate, HhtLiveLog, 0L ) ) <= 0L ) {
      TheDate = YesterDate ;
   } else {
      TheDate = FileDate ;
   }

   sprintf ( FileSpec, "%s%s.%s", SockDir, TheDate, HhtLogExt ) ;

   LogMessage ( 9, "Renaming Log %s to : %s%s.%s", HhtLiveLog, FileSpec ) ;

   if ( s_rename ( 0, HhtLiveLog, FileSpec ) < 0 ) {
      LogMessage ( 2, "Rename of LogFile %s to %s failed",
                   HhtLiveLog, FileSpec ) ;
   }
}

static int TouchFile ( char * FileName, char * DateStr )
{
   long fnum/*, rc*/ ;
   int rc1 = 0 ;
   DISKFILE FileDetails ;
   int Day = 0, Month = 0, Year = 0 ; 

   fnum = s_open ( A_SET | A_READ | A_WRITE, FileName ) ;
   if ( fnum > 0L ) {
      if ( s_get ( T_FILE, fnum, ( VOID * ) &FileDetails, DSKFSIZE) 
           >= E_SUCCESS ) {
         ExtractDateFromDateStr ( DateStr, &Day, &Month, &Year ) ;

         FileDetails.df_modyear = Year ;  
         FileDetails.df_modmonth = Month ;
         FileDetails.df_modday = Day ; 

         if ( s_set ( T_FILE, fnum, ( VOID * ) &FileDetails, DSKFSIZE ) 
              < E_SUCCESS ) {
            LogMessage ( 2, "Setting Touch on %s failed", FileName ) ; 
         }
      }

      //rc = s_close ( 0, fnum ) ;  
      s_close ( 0, fnum ) ;  
      rc1 = 1 ;
   } else {
      LogMessage ( 2, "TouchFile on %s Failed", FileName ) ;
   }

   return rc1 ;
}

static void TouchOrCreateFlagFile ()
{
   long nfound, fnum ;
   unsigned int flags ;


   nfound = GetFileDate ( FlagDate, HhtFlagFile, 0L ) ;
   if ( nfound > 0L ) {
      // Flag File is there, so just alter its date
      TouchFile ( HhtFlagFile, NowDate ) ;
   } else { // have to create Flag File
      // failed
      LogMessage ( 2, "FileDetails s_lookup() on %s failed with %lX",
                   HhtFlagFile, nfound ) ; 

      // file does not exist, so create it with same flags
      flags = A_SET | A_READ | A_WRITE ; // always want to read and write 
      fnum = s_create ( O_FILE, flags, HhtFlagFile, 0, FS_NO, 0L );  
      if ( fnum < E_SUCCESS ) {
         LogMessage ( 1, "Create of %s failed with %lXh", 
                      HhtFlagFile, fnum ) ; 
      } else {   // success, so close the newly created Flag file
         s_close ( 0, fnum ) ;
      }
   }

   // and record its date in FlagDate
   GetFileDate ( FlagDate, HhtFlagFile, 0L ) ;
}

static long LookupFileDetails ( char * FileName, long Key, 
                                DISKFILE * FileDetails )
{ 
   return s_lookup ( T_FILE, 0, FileName, ( far char * ) FileDetails,
                     DSKFSIZE, DSKFSIZE, Key ) ;
}

static long GetFileDate ( char * DateStr, char * FileName, long Key )
{
   long nfound ; 
   DISKFILE FileDetails ;

   nfound = LookupFileDetails ( FileName, Key, &FileDetails ) ;

   if ( nfound > 0 ) {
      sprintf ( DateStr, "%4.4d%2.2d%2.2d", FileDetails.df_modyear, 
                FileDetails.df_modmonth, FileDetails.df_modday ) ;
      LogMessage( 7, "File Date: %8.8s", DateStr ); 
   }

   return nfound ;
}

static struct tm * CurrentDateTime () {
   static struct tm Time2000 ;
   time_t CurrentTime ;
   struct tm * ptrTime ;

   time ( &CurrentTime );
   ptrTime = localtime ( &CurrentTime ) ;
   Time2000 = *ptrTime ;

   Time2000.tm_year += 1900 ;

   return &Time2000 ;
}

static void ExtractDateFromDateStr ( char * DateStr, int * Day, 
                                     int * Month, int * Year )
{ 
   char DateStrom[10] = { 0} ;

   memcpy ( DateStrom, DateStr, 8 ) ; // don't destroy the original!

   // Days is
   *Day = atoi ( DateStrom+6 ) ;
   DateStrom[6] = 0 ;

   // Month is 
   *Month = atoi ( DateStrom+4 ) ; 
   DateStrom[4] = 0 ;

   // Year is
   *Year = atoi ( DateStrom ) ; 

   LogMessage ( 9, "DateStrom, Day: %d, Month %d, Year %d", 
                *Day, *Month, *Year ) ;

}

static long JulianDay ( char * DateStr ) 
{ 
   static int DaysInMonth[] = 
   { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31} ;
   long Year, RobinDaysSonJulian = 0L ;
   int Day, Month, LYear, i ;

   ExtractDateFromDateStr ( DateStr, &Day, &Month, &LYear ) ;

   Year = ( long ) LYear ;

   // is it a leap year ?
   DaysInMonth[1] = (( Year % 4 && !( Year % 100 ) || Year % 400 ) ? 29 : 28 ) ;

   // Julianise it
   for ( i = 0 ; i < Month - 1 ; i++ ) {
      RobinDaysSonJulian += DaysInMonth[i] ;
   }

   RobinDaysSonJulian += ( Year * 1000 ) + Day ;
   LogMessage ( 8, "Julian Day for %s: %ld", DateStr, RobinDaysSonJulian ) ;

   return ( RobinDaysSonJulian ) ;
}

static int DeleteIfOlder ( DISKFILE * FileDetails )
{ 
   struct tm * ptrTime ;
   static char FileName[128] ;
   char FileDate[10] ;
   long NowDateJulian, FileDateJulian ;
   int rc = FALSE ; // preset NO Deletes

   ptrTime = CurrentDateTime () ;

   sprintf ( NowDate, "%4.4d%2.2d%2.2d", ptrTime->tm_year, 
             ptrTime->tm_mon + 1, ptrTime->tm_mday ) ;

   sprintf ( FileDate, "%4.4d%2.2d%2.2d", FileDetails->df_modyear, 
             FileDetails->df_modmonth, FileDetails->df_modday ) ;

   NowDateJulian = JulianDay ( NowDate ) ; 
   FileDateJulian = JulianDay ( FileDate ) ;

   if ( NowDateJulian  > FileDateJulian + 400 ) {
      FileDateJulian += 635 ;
   }

   if ( FileDateJulian <= NowDateJulian - KeepArchives ) {
      sprintf ( FileName, "%s%s", SockDir, FileDetails->df_name ) ;
      LogMessage ( 7, "About to Delete file %s", FileName ) ;
      if ( s_delete ( 0, FileName ) < 0 ) {
         LogMessage ( 1, "Delete of %s%s failed", 
                      SockDir, FileDetails->df_name ) ;
      } else {
         LogMessage ( 9, "Delete succeeded" ) ;
         rc = TRUE ;
      }
   }

   return rc ;
}
