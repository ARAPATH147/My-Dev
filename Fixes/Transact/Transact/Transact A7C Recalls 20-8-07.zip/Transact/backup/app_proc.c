/*************************************************************************
* 
* 
* File: app_proc.c
*
* Author: Prashant Kotak
*
* Created: 18/08/97
*
* Purpose: 
*
* History: 
* 
*************************************************************************/

#include "transact.h" //SDH 19-May-2006

#include "flexif.h"
#include "output.h"
#include "sockserv.h"

//#include "file.h"       // v4.01
//#include "rfs.h"        // v4.01
//#include "transact.h"   // v4.01
//#include "trans2.h"     // v4.01

//externals
// int process ( char *, int * ) ;  // v4.01
extern int process ( char *, int * ) ;  // v4.01   

// local prototypes
static int ParseMessageType ( char * ) ;
static void ProcessRbsCommand ( CLIENT * ) ;
static void ProcessBootsCommand ( CLIENT * ) ;

// Commands we need to process here...
#define CMD_SOR 0x00524F53L
#define CMD_OFF 0x0046464FL
#define CMD_RLS 0x00534C52L 
#define CMD_RLD 0x00444C52L 
#define CMD_RPS 0x00535052L 
#define CMD_RUP 0x00505552L
#define CMD_NAK 0x004E414BL
#define CMD_RBS 0x002E582EL


void ProcessMessage ( CLIENT *client )
{
    switch ( ParseMessageType ( client->Buffer ) )
    {
        case MSG_TYPE_RBS:
            // the message is to be processed locally
            ProcessRbsCommand ( client ) ;
            break ;

        case MSG_TYPE_BOOTS:
            // the message is to be passed to the Boots App
            ProcessBootsCommand ( client ) ;
            break ;

        default:
            // eh?
            break ;
    }
}


static int ParseMessageType ( char *buffer )
{
    int rc ;
    long cmd ;
    
    // cast the commands to longs for easier compares 
    cmd = ( *(long *) buffer ) & 0x00FFFFFF ;
    
    switch (cmd)
    {
        case CMD_RBS:
            rc = MSG_TYPE_RBS ;
            LogMessage( 8, "Got Message Type RBS" ) ;
            break ;

        default: // all others must be for the Boots app 
            rc = MSG_TYPE_BOOTS ;
            LogMessage( 8, "Got Message Type Boots" ) ;
            break ;
    }
    
    return rc ;
}


static void ProcessRbsCommand( CLIENT *client )
{ 
    RBSCommandStruct  *RbsAndCmd ;
    long rc = 0L ;
    
    LogMessage( 8, "Processing Rbs Message... " ) ;
    
    // cast it so that we can extract the command
    RbsAndCmd = ( RBSCommandStruct * ) client->Buffer ;
    
    LogMessage( 9, "Tid: %3.3s, Command: %u, %X", RbsAndCmd->TID,
      RbsAndCmd->Command, RbsAndCmd->Command ) ;
     
    switch (RbsAndCmd->Command)
    {
        case RF_HHT_MSG_RBS_RX_FILE_DETAILS:
            // get file details and prepare for transmission
            LogMessage( 9, "Got RF_HHT_MSG_RBS_RX_FILE_DETAILS" ) ;
            rc = GetFileDetails( client ) ;
            break ;
            
        case RF_HHT_MSG_RBS_RX_FILE:
            // we've got to transmit a file, so
            // go and get first bit o' file.
            AssignFileInfo ( client ) ; 
            client->FileInfo->FileSize = -1 ; 
            LogMessage ( 9, "Got RF_HHT_MSG_RBS_RX_FILE" ) ;
            ReadNextFilePacket ( client ) ;
            break ;
            
        case RF_HHT_MSG_RBS_RX_FILE_ACK:
            // the clients answered it got the last 
            //   bit o' file sent, so get next bit to
            //   transmit more, if there's more to send,
            //   otherwise send back: "we're finished".
            LogMessage ( 9, "Got RF_HHT_MSG_RBS_RX_FILE_ACK" ) ;
            ProcessFileRxAck ( client ) ;
            break ;

        case RF_HHT_MSG_RBS_TX_FILE: 
        case RF_HHT_MSG_RBS_TX_FILE_DATA:
            // the client has told us that it will transmit a bit o' file to us
            LogMessage ( 9, "Got RF_HHT_MSG_RBS_TX_FILE_DATA" ) ;
            WriteNextFilePacket ( client ) ;
            break ;

        case RF_HHT_MSG_RBS_GET_TIME: 
            // The client requires the current time to be
            // sent so that the clocks can be sycronised
            LogMessage ( 9, "Got RF_HHT_MSG_RBS_GET_TIME" ) ;
            ProcessGetTime ( client ) ;
            break ;

        default:
            LogMessage ( 9, "Unknown Command : %d ", RbsAndCmd->Command ) ;
            break;
    }
    
    if ( rc < 0 ) // command failed 
    {
        SetupRbsNakCmd ( client , "RBS", "Command", "Failed" ) ;
    }
}


static void ProcessBootsCommand ( CLIENT *client )
{ 
    RBSCommandStruct  *RbsAndCmd ;
    long Command, Response ;
    
    LogMessage ( 8, "Processing Boots Message..." ) ;
    
    // cast it so that we can extract the command
    RbsAndCmd = (RBSCommandStruct *)client->Buffer ;
    Command = ( *( long * ) RbsAndCmd ) & 0x00FFFFFF ;
    
    // call the boots app process called process()... 
    
    LogMessage ( 9, "Buffer before process(): %*.*s", client->MessageLen, 
                 client->MessageLen, client->Buffer) ;
    
    CurrentHHT = client->HhtId ; // setup for process()
    process ( client->Buffer, &( client->MessageLen ) ) ; 
    // process() will return with the answer

    LogMessage ( 9, "Buffer after process(): %3.3s, %X, %X", 
      client->Buffer, client->Buffer[3], client->Buffer[4] ) ; 

    // extract the response
    Response = ( *(long *) RbsAndCmd ) & 0x00FFFFFF ;

    // we'll have everything setup in the buffer, except if...
    LogMessage ( 9, "Boots Command: %3.3s, %lX", RbsAndCmd->TID, Command ) ; 
    switch ( Command )
    {
        case CMD_SOR:
            if ( Response == CMD_NAK )  // Sign On Request. Did it fail ?
            {
                LogMessage ( 2, "SOR failed, socket marked for disconnect" ) ;
                client->SocketState = AWAITING_DISCONNECT ;
            }
            else // Sign On succeeded, so mark the fact.
            {
                client->SignedOn = 1 ;
            }
            break ;

        case CMD_OFF :
            LogMessage ( 8, "Got CMD_OFF" ) ;
            // if the command was to shut down, mark it for shutdown
            // TH removed as app closed socket before messge received
            // by HHT
            //client->SocketState = AWAITING_DISCONNECT ;
            break ;

        case CMD_RLS : 
            if (Response == CMD_RLD)
            {
                client->MessageLen = sizeof ( RLDStruct ) ;
            }
            break ;


        case CMD_RPS: 
            if (Response == CMD_RUP)
            {
                client->MessageLen = sizeof ( RUPStruct ) ;
            }
            break ;

        default:
            // do nowt
            break ;
    }
}

void IssueCmdOffToBootsApp(int HhtId)
{ 
    int SizeOfOff;
    char Buffer[BUFFER_SIZE]; // why? because process() may return a long answer

    SizeOfOff = RF_MESSAGE_TID_LENGTH;
    memcpy(Buffer, RF_HHT_MSG_OFF, SizeOfOff);  

    // issue it
    CurrentHHT = HhtId ; // setup for process()
    process(Buffer, &SizeOfOff); 
}

void SetupRbsNakCmd ( CLIENT *client, char *Msg1, char *Msg2, char *Msg3 )
{ 
    RBSNAKStruct *RbsNak;

    RbsNak = (RBSNAKStruct *) client->Buffer;

    memcpy( RbsNak->TID, RF_HHT_MSG_RBS_RESERVED, RF_MESSAGE_TID_LENGTH );
    RbsNak->Command = RF_HHT_MSG_RBS_NAK; 
    memcpy( RbsNak->MESSAGE1, Msg1, sizeof( Msg1 ) );  
    memcpy( RbsNak->MESSAGE2, Msg1, sizeof( Msg2 ) );   
    memcpy( RbsNak->MESSAGE3, Msg1, sizeof( Msg3 ) );  
    //dump ( ( char * )RbsNak, sizeof( RBSNAKStruct ));
}

void DummyCallToProcess ( void )
{ 
    char Buffer[256];
    RBSCommandStruct *RbsCmd;
    int SizeOfCmd;

    RbsCmd = ( RBSCommandStruct * ) Buffer;
    // setup dummy command
    memcpy( RbsCmd->TID, RF_HHT_MSG_RBS_RESERVED, RF_MESSAGE_TID_LENGTH );
    RbsCmd->Command = -1; // dummy, invalid command

    // issue it to hook into Boots code 
    CurrentHHT = -1 ; // setup for process() 
    process( ( char * ) RbsCmd , &SizeOfCmd);  
}
