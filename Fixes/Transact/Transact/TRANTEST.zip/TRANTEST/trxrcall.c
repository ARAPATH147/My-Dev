// ------------------------------------------------------------------------
//                     Boots The Chemists Store Systems
//                  Radio Frequency Transaction Processor
//
// Version 4.0               Steve Wright                28th August 2003
//     2003 Trial
//     Update to cope with new deal system
//
// Version 4.0               Paul Bowers                 26th September 2003
//    Various fixes for 2003 trial
//    Implement split of transact.c into trans2.c
//
// Version 5.0               Paul Bowers                 25 May 2007
//    Implement changes to support the Recall System in A7C
//
// Version 5.1               Brian Greenfield            23rd August 2007
//    Removed check of PSB70 flag in the RECOK file as the PPC should
//    be allowed to access recalls regardless of this status.
//
// Version 5.2               Brian Greenfield            30th August 2007
//    Removed write of anCountTSF field back to the Recall as this was
//    forcing the count to 0 and updating it in the recall file for the
//    item when this should not be happening. This code was left in after
//    the count calculation had been removed by PAB.
//    Altered the uncounted to be F's not spaces.
//
// Version 5.3               Brian Greenfield            7th September 2007
//    Changed recall file open errors to be more generic and not critial.
//    If Recall rfindx file is opened but is empty, pass non-critical error
//    to PPC.
//    Also pass item count status flag to PPC in RCF response. now we are
//    Also if a list request finds items flagged as Y (probably due to a
//    PPC reload) then pass the session count.
//
// Version 5.4               Brian Greenfield            10th September 2007
//    Changed a couple of files to close all sessions.
//
// Version 5.5               Brian Greenfield            11th September 2007
//    Changed a couple of files to close all sessions.
//    Altered process_sel_stack slightly as print is retried every 15
//    minutes in transact.c.
//    Reduced print retries to 5 because we now try every 15 minutes as well.
//    Added some debug to StopRecalls.
//
// Version 5.6               Brian Greenfield            14th April 2008
//    Reverse Logistics Changes
//    Recalls of type I & C should not be sent if their expiry date is
//    today or older. Also expiry date is now passed to pocket PC from
//    newly added fiels in RCINDX file
//
// Version 5.7               Brian Greenfield            30th April 2008
//    Reverse Logistics Modifications
//    Recalls type is now passed in RCD message so only send
//    recalls that match the request.
//    Also moved process_sel_stack to trans03.c.
//    Added passing of MRQ value to the PPC in the RCD message.
//    Expiry date now passed in active date field in RCC. Removed the
//    expiry date form the RCC record layout.
//
// Version 5.8               Brian Greenfield            20th June 2008
//    Further Reverse Logistics Modifications
//    The Recall expiry date requirement has changed so that the date of
//    expiry is now valid. tests changed accordingly.
//    Moved suspend_transaction to trans03 due to space.
//
// Version 5.9              Brian Greenfield            1st Sept 2008
//    Added bits for ASN/Directs. (Now not in this module due to Streamlining changes!)
//
// Version 5.10              Brian Greenfield           16th Sept 2008
//    Added PDTASSET file.
// Moved the following to trans04:
//   SignOffNak
//   prep_nak
//   prep_ack
//   prep_pq_full_nak
//   IsStoreClosed
//   IsHandheldUnknown
//   UpdateActiveTime
//   IsReportMntActive
//
//  Version 5.11            Brian Greenfield            20th February 2009
//  Corrected code so that the RCINDX size is no longer hard coded!
//
//  Version 5.12            charles skadorwa            13th May 2010
//  Changes to support 2010 Recalls Phase 1 Project
//
//  Version 5.13            Charles Skadorwa            30th Nov 2010
//  Changes to support 2010 Recalls Improvements Project
//  Defect 4806: Fix to RCF processing where recalled item is not on file.
//  Tailored item rules modified to include Stock last count and last
//  delivery date checks.
// -----------------------------------------------------------------------

/* include files */
#include "transact.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <flexif.h>
#include "trxbase.h"                    // Streamline SDH 22-Sep-2008
#include "trxutil.h"                    // Streamline SDH 22-Sep-2008
#include "osfunc.h"                   /* needed for disp_msg() */
//#include "adxsrvst.h"                   /* needed for bg */
#include "trxfile.h"                    // Streamline SDH 22-Sep-2008
//#include "rfs.h"
//#include "rfs2.h"                       // PAB 24-May-2007 Recalls
#include "rfsfile.h"
//#include "rfsfile2.h"                   // PAB 24-May-2007 Recalls
//#include "dateconv.h"
//#include "wrap.h"
#include "sockserv.h"
#include "rfglobal.h"                   // v4.0
//#include "rfglobal2.h"                  // PAB 24-May-2007 Recalls
#include "osfunc.h"
#include "prtctl.h"                     // Streamline SDH 17-Sep-2008
#include "srfiles.h"
#include "idf.h"
#include "irf.h"
#include "rfscf.h"
#include "ccfiles.h"
#include "invok.h"

// =============================================================// Streamline SDH 23-Sep-2008
// Module level static variables                                // Streamline SDH 23-Sep-2008
// =============================================================// Streamline SDH 23-Sep-2008

static int gRecallFilesAvailable = 0;                           // Streamline SDH 23-Sep-2008

// =============================================================// 24-05-07 PAB Recalls
// Recall Procedures follow          24th May 2007   Paul Bowers// 24-05-07 PAB Recalls
// =============================================================// 24-05-07 PAB Recalls

URC process_recok(void)                                         // 24-05-07 PAB Recalls
{                                                               // 24-05-07 PAB Recalls
    LONG usrrc = RC_OK;                                         // 24-05-07 PAB Recalls
    LONG rc;                                                    // 24-05-07 PAB Recalls
    usrrc = open_recok();                                       // 24-05-07 PAB Recalls
                                                                // 24-05-07 PAB Recalls
    // if the recall OK file is not found.                      // 24-05-07 PAB Recalls
    if (usrrc != RC_OK) {                                       // 24-05-07 PAB Recalls
        prep_nak("ERRORUnable to open RECOK file. "             // 24-05-07 PAB Recalls
                 "Check appl event logs" );                     // 24-05-07 PAB Recalls
        return RC_FILE_ERR;                                     // 24-05-07 PAB Recalls
    }                                                           // 24-05-07 PAB Recalls
                                                                // 24-05-07 PAB Recalls
    // read the current status record & close the file          // 24-05-07 PAB Recalls
    rc = s_read( A_BOFOFF,                                      // 24-05-07 PAB Recalls
                 recok.fnum, (void *)&recokrec, RECOK_RECL, 0L);// 24-05-07 PAB Recalls
                                                                // 24-05-07 PAB Recalls
                                                                // 24-05-07 PAB Recalls
    close_recok ( CL_SESSION );                                 // 24-05-07 PAB Recalls
                                                                // 24-05-07 PAB Recalls
    gRecallFilesAvailable = 0;                                  // 24-05-07 PAB Recalls
//    if (recokrec.cPSB70Processing != 'E') {                     // 24-05-07 PAB Recalls // 23-08-2007 5.1 BMG
//        disp_msg("Recall Files are not available");             // 24-05-07 PAB Recalls // 23-08-2007 5.1 BMG
//        gRecallFilesAvailable = 1;                              // 24-05-07 PAB Recalls // 23-08-2007 5.1 BMG
//        // force physical close of recall files                 // 31-05-07 PAB Recalls // 23-08-2007 5.1 BMG
//        close_recall( CL_ALL );                                 // 31-05-07 PAB Recalls // 23-08-2007 5.1 BMG
//        close_rcindx ( CL_ALL );                                // 31-05-07 PAB Recalls // 23-08-2007 5.1 BMG
//        close_rcspi ( CL_ALL) ;                                 // 31-05-07 PAB Recalls // 23-08-2007 5.1 BMG
//        return RC_OK;                                           // 24-05-07 PAB Recalls // 23-08-2007 5.1 BMG
//        }                                                       // 24-05-07 PAB Recalls // 23-08-2007 5.1 BMG
                                                                // 24-05-07 PAB Recalls
                                                                // 24-05-07 PAB Recalls
    if (rc <= 0L) {                                             // 24-05-07 PAB Recalls
        log_event101(rc, RFOK_REP, __LINE__);                   // 24-05-07 PAB Recalls
        sprintf(sbuf, "ERR-R RECOK. RC:%081X", rc);             // Streamline SDH 24-Sep-2008
        disp_msg(sbuf);                                         // Streamline SDH 24-Sep-2008
        prep_nak("ERRORRECOK read error. Check appl event logs");// Streamline SDH 24-Sep-2008
        return RC_DATA_ERR;                                     // 24-05-07 PAB Recalls
    }                                                           // 24-05-07 PAB Recalls
                                                                // 24-05-07 PAB Recalls
    return RC_OK;                                               // 24-05-07 PAB Recalls
}                                                               // 24-05-07 PAB Recalls


static LONG CheckRecallAvailable(void ) {

   LONG usrrc = RC_OK;

   // check status of recok record                             // 24-05-07 PAB Recalls
   usrrc = process_recok();                                    // 24-05-07 PAB Recalls
   if (usrrc!=RC_OK) {                                         // 24-05-07 PAB Recalls
       return 0;                                               // 24-05-07 PAB Recalls
       }                                                       // 24-05-07 PAB Recalls
                                                               // 24-05-07 PAB Recalls
                                                               // 24-05-07 PAB Recalls
   // if the recall files are not available.                   // 24-05-07 PAB Recalls
   if (gRecallFilesAvailable == 1) {                           // 24-05-07 PAB Recalls
       prep_nak("ERRORRecall Files are not available."         // 24-05-07 PAB Recalls
                " Please try later.");                         // 25-05-07 PAB Recalls
       return 1;                                               // 24-05-07 PAB Recalls
   }

}


void RecallStart(char *inbound) {                               // 24-05-07 PAB Recalls
                                                                // 24-05-07 PAB Recalls
    LONG usrrc = RC_OK;                                         // 24-05-07 PAB Recalls
                                                                // 24-05-07 PAB Recalls
    // check status of recall files                             // 24-05-07 PAB Recalls
   usrrc = CheckRecallAvailable();                              // 24-05-07 PAB Recalls
   if (usrrc!=0) {                                              // 24-05-07 PAB Recalls
       return;                                                  // 24-05-07 PAB Recalls
   }                                                            // 24-05-07 PAB Recalls
                                                                // 24-05-07 PAB Recalls
   UNUSED(inbound);                                             // 24-05-07 PAB Recalls
   // Open the recall files                                     // 24-05-07 PAB Recalls
   usrrc = open_recall();                                       // 24-05-07 PAB Recalls
   if (usrrc != RC_OK) {                                        // 24-05-07 PAB Recalls
       disp_msg("RECALL file not found");                       // 24-05-07 PAB Recalls
//     prep_nak("ErrorUnable to open RECALL file. "             // 24-05-07 PAB Recalls // 07-09-2007 5.3 BMG
//              "Check appl event logs" );                      // 24-05-07 PAB Recalls // 07-09-2007 5.3 BMG
       prep_nak("There are no Head Office recalls "                                     // 07-09-2007 5.3 BMG
                "to be actioned at this time." );                                       // 07-09-2007 5.3 BMG
       return;                                                  // 24-05-07 PAB Recalls
       }                                                        // 24-05-07 PAB Recalls
                                                                // 24-05-07 PAB Recalls
   usrrc = open_rcspi();                                        // 24-05-07 PAB Recalls
   if (usrrc != RC_OK) {                                        // 24-05-07 PAB Recalls
       disp_msg("RCSPI file not found");                        // 24-05-07 PAB Recalls
//     prep_nak("ErrorUnable to open RCSPI file. "              // 24-05-07 PAB Recalls // 07-09-2007 5.3 BMG
//              "Check appl event logs" );                      // 24-05-07 PAB Recalls // 07-09-2007 5.3 BMG
       prep_nak("There are no Head Office recalls "                                     // 07-09-2007 5.3 BMG
                "to be actioned at this time." );                                       // 07-09-2007 5.3 BMG
       return;                                                  // 24-05-07 PAB Recalls
       }                                                        // 24-05-07 PAB Recalls
                                                                // 24-05-07 PAB Recalls
                                                                // 24-05-07 PAB Recalls
   usrrc = open_rcindx();                                       // 24-05-07 PAB Recalls
   if (usrrc != RC_OK) {                                        // 24-05-07 PAB Recalls
       disp_msg("RCINDX file not found");                       // 24-05-07 PAB Recalls
//     prep_nak("ErrorUnable to open RCINDX file. "             // 24-05-07 PAB Recalls // 07-09-2007 5.3 BMG
//              "Check appl event logs" );                      // 24-05-07 PAB Recalls // 07-09-2007 5.3 BMG
       prep_nak("There are no Head Office recalls "                                     // 07-09-2007 5.3 BMG
                "to be actioned at this time." );                                       // 07-09-2007 5.3 BMG
       return;                                                  // 24-05-07 PAB Recalls
       }                                                        // 24-05-07 PAB Recalls

   // Read the first record and return an error if no record found                      // 07-09-2007 5.3 BMG
   usrrc = s_read( A_BOFOFF,                                                            // 07-09-2007 5.3 BMG
                rcindx.fnum, (void *)&rcindxrec,                                        // 07-09-2007 5.3 BMG
                RCINDX_RECL, 0);                                                        // 07-09-2007 5.3 BMG
   if (usrrc <= RC_OK) {                                                                // 07-09-2007 5.3 BMG
       disp_msg("RCINDX is empty");                                                     // 07-09-2007 5.3 BMG
       prep_nak("There are no Head Office recalls "                                     // 07-09-2007 5.3 BMG
                "to be actioned at this time." );                                       // 07-09-2007 5.3 BMG
       return;                                                                          // 07-09-2007 5.3 BMG
   }                                                                                    // 07-09-2007 5.3 BMG


   if (CchistOpen() != RC_OK) {
//     prep_nak("errorUnable to open "                          // 24-05-07 PAB Recalls // 07-09-2007 5.3 BMG
//              "CCHIST file. "                                 // 24-05-07 PAB Recalls // 07-09-2007 5.3 BMG
//              "Check appl event logs" );                      // 24-05-07 PAB Recalls // 07-09-2007 5.3 BMG
       prep_nak("There are no Head Office recalls "                                     // 07-09-2007 5.3 BMG
                "to be actioned at this time." );                                       // 07-09-2007 5.3 BMG
       return;                                                  // 24-05-07 PAB Recalls
       }

                                                                // 24-05-07 PAB Recalls
// Recall files available ok send acknowledgement               // 24-05-07 PAB Recalls
   prep_ack("");                                                // 24-05-07 PAB Recalls
}                                                               // 24-05-07 PAB Recalls

typedef struct LRT_RCB_Txn {
   BYTE cmd[3];
   BYTE opid[3];
   BYTE anRecallNumber[22];                           // recal ref (8) uod (14)
   BYTE cListStatus[1];                               // "P","A"," "
} LRT_RCB;                                    
#define LRT_RCB_LTH sizeof(LRT_RCB)

void RecallExit(char *inbound) {                                // 24-05-07 PAB Recalls
                                                                // 24-05-07 PAB Recalls
    LRT_RCB* pRCB = (LRT_RCB*)inbound;

    LONG usrrc = RC_OK;                                         // 24-05-07 PAB Recalls
    BYTE RecallNumber[23];                                      // 24-05-07 PAB Recalls
    UNUSED(inbound);                                            // 24-05-07 PAB Recalls
                                                                // 24-05-07 PAB Recalls
    // check status of recall files                             // 24-05-07 PAB Recalls
   usrrc = CheckRecallAvailable();                              // 24-05-07 PAB Recalls
   if (usrrc!=0) {                                              // 24-05-07 PAB Recalls
       return;                                                  // 24-05-07 PAB Recalls
   }                                                            // 24-05-07 PAB Recalls
                                                                // 24-05-07 PAB Recalls
                                                                // 24-05-07 PAB Recalls
   if (pRCB->cListStatus[0] != 0x58){                           // 20-06-07 PAB Recalls
      // if not "X" so it must be "P" or "A"
      // then status is "P" or "A" then update and despatch this recall
      // lift the first 8 digits asa this is the recall ref no
      // the next 14 are the UOD number to send to RFSCC
      memcpy( recallrec.abRecallReference,                      // 24-05-07 PAB Recalls
             pRCB->anRecallNumber, 8 );                         // 24-05-07 PAB Recalls
      recallrec.ubChain = 0;                                    // 24-05-07 PAB Recalls
      usrrc = s_read( 0, recall.fnum, (void *)&recallrec,       // 24-05-07 PAB Recalls
                              RECALL_RECL, RECALL_KEYL );       // 24-05-07 PAB Recalls
      //If error reading RECALL                                 // 24-05-07 PAB Recalls
      if (usrrc<=0L) {                                          // 24-05-07 PAB Recalls
          log_event101(usrrc, RECALL_REP, __LINE__);            // 24-05-07 PAB Recalls
          if (debug) {                                          // 24-05-07 PAB Recalls
              sprintf(msg, "Err-R RECALL. RC:%08lX", usrrc);    // 24-05-07 PAB Recalls
              disp_msg(msg);                                    // 24-05-07 PAB Recalls
              }                                                 // 24-05-07 PAB Recalls
           prep_nak("ERRORThis Recall could not be read from "  // 24-05-07 PAB Recalls
                    "Recall file. Check appl event logs" );     // 24-05-07 PAB Recalls
           return;                                              // 24-05-07 PAB Recalls
          //Else there is a RECALL record                       // 24-05-07 PAB Recalls
      } else {                                                  // 24-05-07 PAB Recalls
          recall.present=TRUE;                                  // 24-05-07 PAB Recalls
          if (debug) {                                          // 24-05-07 PAB Recalls
              sprintf(msg, "OK, REC :");                        // 24-05-07 PAB Recalls
              disp_msg(msg);                                    // 24-05-07 PAB Recalls
              dump( (BYTE *)&recallrec, RECALL_RECL );          // 24-05-07 PAB Recalls
          }                                                     // 24-05-07 PAB Recalls
          // update the recall record                           // 24-05-07 PAB Recalls
          memcpy( recallrec.cRecallStatus,                      // 24-05-07 PAB Recalls
              pRCB->cListStatus, 1 );                           // 24-05-07 PAB Recalls
          usrrc = WriteRecall(__LINE__);                        // 24-05-07 PAB Recalls
          if (usrrc <= 0L) {                                    // 24-05-07 PAB Recalls
             // there was an error writing back the recall record.
              log_event101(usrrc, RECALL_REP, __LINE__);        // 24-05-07 PAB Recalls
              if (debug) {                                      // 24-05-07 PAB Recalls
                  sprintf(msg, "Err-W RECALL. RC:%08lX", usrrc);// 24-05-07 PAB Recalls
                  disp_msg(msg);                                // 24-05-07 PAB Recalls
              }                                                 // 24-05-07 PAB Recalls
              prep_nak("ERRORThere was a failure updating the"  // 24-05-07 PAB Recalls
                        "Recall file. Check appl event logs" ); // 24-05-07 PAB Recalls
              return;                                           // 24-05-07 PAB Recalls
              }                                                 // 24-05-07 PAB Recalls
          // The recall record updated ok                       // 24-05-07 PAB Recalls
          memcpy( RecallNumber, pRCB->anRecallNumber, 22);      // 24-05-07 PAB Recalls
          RecallNumber[22] = 0x00;                              // 24-05-07 PAB Recalls
          usrrc = start_background_app( "ADX_UPGM:RFSCC.286",   // 24-05-07 PAB Recalls
                                        RecallNumber,           // 24-05-07 PAB Recalls
                                        "Despatching Recall" ); // 24-05-07 PAB Recalls
          if (usrrc < 0) {                                      // 24-05-07 PAB Recalls
              prep_nak("ERRORUnable to start RFSCC to despatch" // 24-05-07 PAB Recalls
                       " this Recall. Please try again ");      // 24-05-07 PAB Recalls
          }                                                     // 24-05-07 PAB Recalls
      }                                                         // 24-05-07 PAB Recalls
   }                                                            // 24-05-07 PAB Recalls
   if (pRCB->cListStatus[0] != 'P'){                            // 21-06-07 PAB recalls
      // Only close the files if finished the UOD, if Partial then
      // Multiple UODs can be requested for the same Recall Ref.
      close_recall( CL_SESSION );                               // 24-05-07 PAB Recalls
      close_rcindx( CL_ALL );                                   // 24-05-07 PAB Recalls  // 07-09-2007 5.4 BMG
      close_rcspi( CL_ALL );                                    // 24-05-07 PAB Recalls  // 07-09-2007 5.4 BMG
      CchistClose ( CL_SESSION );                              // 4-6-07  PAB Recalls
   }                                                            // 21-6-07 PAB Recalls
   prep_ack("");                                                // 24-05-07 PAB Recalls
   return;                                                      // 24-05-07 PAB Recalls
}                                                               // 24-05-07 PAB Recalls


typedef struct LRT_RCC_Txn {
   BYTE cmd[3];
   BYTE opid[3];
   BYTE Index[4];
   BYTE anRecallRef[8];                               
   BYTE cRecallType[1];
   BYTE abRecallDesc[20];
   BYTE anRecallCnt[4];
   BYTE cActiveDate[8];                          // YYYYMMDD
   BYTE cMsgAvail[1];                            // "Y" is msg available on Recall Msg File.
   BYTE cLabelType[2];
   BYTE cMRQ[2];                                 // 2 digit Minimun Return Quantity // 05-05-2008 1.4 BMG
   BYTE cRecallStatus; // A-Actioned P-Partially actioned N-Not actioned  // CSk 13-05-2010 Recalls Phase 1
   BYTE cTailored;     // Y = Tailored List, N = Not Tailored             // CSk 13-05-2010 Recalls Phase 1
} LRT_RCC;                                    
#define LRT_RCC_LTH sizeof(LRT_RCC)
                       
typedef struct LRT_RCD_Txn {
   BYTE cmd[3];
   BYTE opid[3];
   BYTE anIndex[4];                             
   BYTE cRecallType[1];
} LRT_RCD;                                    
#define LRT_RCD_LTH sizeof(LRT_RCD)

typedef struct LRT_RCE_Txn {
   BYTE cmd[3];
   BYTE opid[3];                            
} LRT_RCE;                                    
#define LRT_RCE_LTH sizeof(LRT_RCE)

void RecallListRequest(char *inbound) {                         // 24-05-07 PAB Recalls
                                                                // 29-05-07 PAB Recalls
    LRT_RCD* pRCD = (LRT_RCD*)inbound;                          // 31-05-07 PAB Recalls
    LRT_RCE* pRCE = (LRT_RCE*)out;                              // 31-05-07 PAB Recalls
    LRT_RCC* pRCC = (LRT_RCC*)out;                              // 31-05-07 PAB Recalls
                                                                // 31-05-07 PAB Recalls
    LONG usrrc = RC_OK;                                         // 24-05-07 PAB Recalls
    LONG lIndexPtr = 0;                                         // 29-05-07 PAB Recalls
    int iExpired = 0;                                                                   // 14-04-2008 5.6 BMG
    int iBypass = 0;                                                                    // 30-04-2008 5.7 BMG
    DOUBLE dRecallExpiryDate;                                                           // 14-04-2008 5.6 BMG
    DOUBLE dTodayDate;                                                                  // 14-04-2008 5.6 BMG
    WORD hour, min;                                                                     // 14-04-2008 5.6 BMG
    LONG sec, day, month, year;                                                         // 14-04-2008 5.6 BMG
    UNUSED(inbound);                                            // 24-05-07 PAB Recalls
                                                                // 24-05-07 PAB Recalls
    // check status of recall files                             // 24-05-07 PAB Recalls
    usrrc = CheckRecallAvailable();                             // 24-05-07 PAB Recalls
    if (usrrc!=0) {                                             // 24-05-07 PAB Recalls
        return;                                                 // 24-05-07 PAB Recalls
    }                                                           // 24-05-07 PAB Recalls
                                                                // 29-05-07 PAB Recalls
    // The hand-held will make a number of RCD requests for TRANSACT to return the      // CSk 30-11-2010 Recall Improvements
    // recalls of the requested type. Each RCD contains a record pointer into the       // CSk 30-11-2010 Recall Improvements
    // RCINDX file which gets incremented each time until the end of file is reached    // CSk 30-11-2010 Recall Improvements
    // or a match is found. If a match is not found at the current record, then the     // CSk 30-11-2010 Recall Improvements
    // RCINDX is scanned until the next match is found or end-of-file. The RCC contains // CSk 30-11-2010 Recall Improvements
    // the pointer to the current position in the RCINDX file in order that the next    // CSk 30-11-2010 Recall Improvements
    // RCD request can continue reading without going to the start. The trace will      // CSk 30-11-2010 Recall Improvements
    // display ALL the recalls read from the RCINDX file - not just the requested ones! // CSk 30-11-2010 Recall Improvements
                                                                // 29-05-07 PAB Recalls
    lIndexPtr = satoi(pRCD->anIndex, 4);                        // 29-05-07 PAB Recalls
    lIndexPtr = lIndexPtr * RCINDX_RECL;                        // 30-05-07 PAB Recalls // 14-04-2008 5.6 BMG
                                                                // 29-05-07 PAB Recalls
    // read the current status record & close the file          // 24-05-07 PAB Recalls
    usrrc = s_read( A_BOFOFF,                                   // 24-05-07 PAB Recalls
                 rcindx.fnum, (void *)&rcindxrec,               // 29-05-07 PAB Recalls
                 RCINDX_RECL, lIndexPtr);                       // 24-05-07 PAB Recalls
                                                                // 29-05-07 PAB Recalls
                                                                // 29-05-07 PAB Recalls
                                                                // 31-05-07 PAB Recalls
    if (debug) {
       sprintf(msg, "Read from RCINDX. RC:%08lX recall status %c recall type %c record index %d", usrrc,   // 30-04-2008 5.7 BMG
                       *rcindxrec.cRecallStatus,*rcindxrec.cRecallType,lIndexPtr); // 31-05-07 PAB Recalls // 30-04-2008 5.7 BMG
       disp_msg(msg);                                           // 31-05-07 PAB Recalls
       }                                                        // 31-05-07 PAB Recalls
                                                                // 31-05-07 PAB Recalls

    if (usrrc > RC_OK) {                                                               // CSk 13-05-2010 Recalls Phase 1 
        // Checking expiry date for all Recall types                                   // CSk 30-11-2010 Recall Improvements  
        //                          RULES                                              // CSk 30-11-2010 Recall Improvements
        //                          -----                                              // CSk 30-11-2010 Recall Improvements
        // For 100% Returns and Batch Returns         then expiry date + 15 days       // CSk 30-11-2010 Recall Improvements
        // For Customer-Emergency & Withdrawn recalls then expiry date + 28 days       // CSk 30-11-2010 Recall Improvements
        // For Excess Salesplan   &  Planner Leaver   then expiry date                 // CSk 30-11-2010 Recall Improvements
        sysdate( &day, &month, &year, &hour, &min, &sec );                             // CSk 30-11-2010 Recall Improvements 
        dTodayDate = ConvGJ( day, month, year );                                       // CSk 30-11-2010 Recall Improvements 
        unpack( sbuf, 8, rcindxrec.abExpiryDate, 4, 0 );                               // CSk 30-11-2010 Recall Improvements  
        day   = satol( sbuf+6, 2 );                                                    // CSk 30-11-2010 Recall Improvements  
        month = satol( sbuf+4, 2 );                                                    // CSk 30-11-2010 Recall Improvements  
        year  = satol( sbuf,   4 );                                                    // CSk 30-11-2010 Recall Improvements  
        dRecallExpiryDate = ConvGJ( day, month, year );                                // CSk 30-11-2010 Recall Improvements 
                                                                                       // CSk 30-11-2010 Recall Improvements
        iExpired = 1; // set default to expired                                        // CSk 30-11-2010 Recall Improvements  
                                                                                       // CSk 30-11-2010 Recall Improvements
        if ((*rcindxrec.cRecallType == 'C') || (*rcindxrec.cRecallType == 'I')) {      // CSk 30-11-2010 Recall Improvements
            // Excess Salesplan or Planner Leaver                                      // CSk 30-11-2010 Recall Improvements
            if ((dRecallExpiryDate - dTodayDate) >= 0) {                               // CSk 30-11-2010 Recall Improvements  
                iExpired = 0;                                                          // CSk 30-11-2010 Recall Improvements  
            }                                                                          // CSk 30-11-2010 Recall Improvements  
        }                                                                              // CSk 30-11-2010 Recall Improvements
        else {                                                                         // CSk 30-11-2010 Recall Improvements
            if ((*rcindxrec.cRecallType == 'R') || (*rcindxrec.cRecallType == 'S')) {  // CSk 30-11-2010 Recall Improvements
                // 100% Returns or 100% Batch Returns - 15 day rule applies            // CSk 30-11-2010 Recall Improvements
                if ((dRecallExpiryDate+15 - dTodayDate) >= 0) {                        // CSk 30-11-2010 Recall Improvements  
                    iExpired = 0;                                                      // CSk 30-11-2010 Recall Improvements  
                }                                                                      // CSk 30-11-2010 Recall Improvements  
            }                                                                          // CSk 30-11-2010 Recall Improvements
            else { // 28 day rule applies                                              // CSk 30-11-2010 Recall Improvements
                // Customer Emergency or Withdrawn or Batch Customer or Batch Withdrawn// CSk 30-11-2010 Recall Improvements
                //     E              or     W     or      F         or      X         // CSk 30-11-2010 Recall Improvements
                if ((dRecallExpiryDate+28 - dTodayDate) >= 0) {                        // CSk 30-11-2010 Recall Improvements  
                    iExpired = 0;                                                      // CSk 30-11-2010 Recall Improvements  
                }                                                                      // CSk 30-11-2010 Recall Improvements  
            }                                                                          // CSk 30-11-2010 Recall Improvements
        }                                                                              // CSk 30-11-2010 Recall Improvements
        /*If head office recall requested but we have an I or C, bypass this record*/       // 30-04-2008 5.7 BMG
        if ( memcmp(pRCD->cRecallType,"*",1) == 0 ) {                                       // 30-04-2008 5.7 BMG
            if ( (memcmp(rcindxrec.cRecallType,"C",1) == 0) ||                              // 30-04-2008 5.7 BMG
                 (memcmp(rcindxrec.cRecallType,"I",1) == 0)) {                              // 30-04-2008 5.7 BMG
                iBypass = 1;                                                                // 30-04-2008 5.7 BMG
            }                                                                               // 30-04-2008 5.7 BMG
        } else { /*An I or C was requested to bypass of we don't have a match */            // 30-04-2008 5.7 BMG
            if ( memcmp(pRCD->cRecallType,rcindxrec.cRecallType,1) ) {                      // 30-04-2008 5.7 BMG
                iBypass = 1;                                                                // 30-04-2008 5.7 BMG
            }                                                                               // 30-04-2008 5.7 BMG
        }                                                                                   // 30-04-2008 5.7 BMG
    } // end of if (usrrc > RC_OK)                                                      // CSk 13-05-2010 Recalls Phase 1 

    if ((iExpired || iBypass) && (usrrc > RC_OK)) {                                     // CSk 13-05-2010 Recalls Phase 1
        // Recall just read does not meet criteria so continue scanning through the     // CSk 13-05-2010 Recalls Phase 1
        // RCINDX file until you find the next non-expired/bypassed recall              // CSk 13-05-2010 Recalls Phase 1
        while ((iExpired || iBypass) && (usrrc > RC_OK)) {                              // CSk 13-05-2010 Recalls Phase 1
           lIndexPtr = lIndexPtr + RCINDX_RECL;
           usrrc = s_read( A_BOFOFF,                            // 24-05-07 PAB Recalls
                rcindx.fnum, (void *)&rcindxrec,                // 29-05-07 PAB Recalls
                RCINDX_RECL, lIndexPtr);                        // 24-05-07 PAB Recalls

           if (usrrc > RC_OK) {                                                          // CSk 13-05-2010 Recalls Phase 1 
               sysdate( &day, &month, &year, &hour, &min, &sec );                             // CSk 30-11-2010 Recall Improvements 
               dTodayDate = ConvGJ( day, month, year );                                       // CSk 30-11-2010 Recall Improvements 
               unpack( sbuf, 8, rcindxrec.abExpiryDate, 4, 0 );                               // CSk 30-11-2010 Recall Improvements  
               day   = satol( sbuf+6, 2 );                                                    // CSk 30-11-2010 Recall Improvements  
               month = satol( sbuf+4, 2 );                                                    // CSk 30-11-2010 Recall Improvements  
               year  = satol( sbuf,   4 );                                                    // CSk 30-11-2010 Recall Improvements  
               dRecallExpiryDate = ConvGJ( day, month, year );                                // CSk 30-11-2010 Recall Improvements 
                                                                                              // CSk 30-11-2010 Recall Improvements
               iExpired = 1; // set default to expired                                        // CSk 30-11-2010 Recall Improvements  
                                                                                              // CSk 30-11-2010 Recall Improvements
               if ((*rcindxrec.cRecallType == 'C') || (*rcindxrec.cRecallType == 'I')) {      // CSk 30-11-2010 Recall Improvements
                   // Excess Salesplan or Planner Leaver                                      // CSk 30-11-2010 Recall Improvements
                   if ((dRecallExpiryDate - dTodayDate) >= 0) {                               // CSk 30-11-2010 Recall Improvements  
                       iExpired = 0;                                                          // CSk 30-11-2010 Recall Improvements  
                   }                                                                          // CSk 30-11-2010 Recall Improvements  
               }                                                                              // CSk 30-11-2010 Recall Improvements
               else {                                                                         // CSk 30-11-2010 Recall Improvements
                   if ((*rcindxrec.cRecallType == 'R') || (*rcindxrec.cRecallType == 'S')) {  // CSk 30-11-2010 Recall Improvements
                       // 100% Returns or 100% Batch Returns - 15 day rule applies            // CSk 30-11-2010 Recall Improvements
                       if ((dRecallExpiryDate+15 - dTodayDate) >= 0) {                        // CSk 30-11-2010 Recall Improvements  
                           iExpired = 0;                                                      // CSk 30-11-2010 Recall Improvements  
                       }                                                                      // CSk 30-11-2010 Recall Improvements  
                   }                                                                          // CSk 30-11-2010 Recall Improvements
                   else { // 28 day rule applies                                              // CSk 30-11-2010 Recall Improvements
                       // Customer Emergency or Withdrawn or Batch Customer or Batch Withdrawn// CSk 30-11-2010 Recall Improvements
                       //     E              or     W     or      F         or      X         // CSk 30-11-2010 Recall Improvements
                       if ((dRecallExpiryDate+28 - dTodayDate) >= 0) {                        // CSk 30-11-2010 Recall Improvements  
                           iExpired = 0;                                                      // CSk 30-11-2010 Recall Improvements  
                       }                                                                      // CSk 30-11-2010 Recall Improvements  
                   }                                                                          // CSk 30-11-2010 Recall Improvements
               }                                                                              // CSk 30-11-2010 Recall Improvements

               /*If head office recall requested but we have an I or C, bypass this record*/// 30-04-2008 5.7 BMG
               iBypass = 0;                                                                 // 30-04-2008 5.7 BMG
               if ( memcmp(pRCD->cRecallType,"*",1) == 0 ) {                                // 30-04-2008 5.7 BMG
                   if ( (memcmp(rcindxrec.cRecallType,"C",1) == 0) ||                       // 30-04-2008 5.7 BMG
                        (memcmp(rcindxrec.cRecallType,"I",1) == 0)) {                       // 30-04-2008 5.7 BMG
                       iBypass = 1;                                                         // 30-04-2008 5.7 BMG
                   }                                                                        // 30-04-2008 5.7 BMG
               } else { /*An I or C was requested to bypass of we don't have a match */     // 30-04-2008 5.7 BMG
                   if ( memcmp(pRCD->cRecallType,rcindxrec.cRecallType,1) ) {               // 30-04-2008 5.7 BMG
                       iBypass = 1;                                                         // 30-04-2008 5.7 BMG
                   }                                                                        // 30-04-2008 5.7 BMG
               }                                                                            // 30-04-2008 5.7 BMG
           } // end of if (usrrc > RC_OK)                                                   // CSk 30-11-2010 Recall Improvements 

           if (debug) {
               if (usrrc < RC_OK) {
                   // end of index file reached
                   sprintf(msg, "Search RCINDX. RC:%08lX record index %d EOF RCINDX", usrrc,lIndexPtr); // 30-04-2008 5.7 BMG
                   disp_msg(msg);                                                                       // 30-04-2008 5.7 BMG
                   break;
               } else {
                   sprintf(msg, "Search RCINDX. RC:%08lX recall status %c recall type %c record index %d", usrrc, // 14-04-2008 5.6 BMG
                          *rcindxrec.cRecallStatus,*rcindxrec.cRecallType,lIndexPtr);                             // 14-04-2008 5.6 BMG
                   disp_msg(msg);                                   // 31-05-07 PAB Recalls
                   if (iExpired) {                                                          // 14-04-2008 5.6 BMG
                       sprintf(msg, "               RECALL IS EXPIRED");                    // 14-04-2008 5.6 BMG
                       disp_msg(msg);                                                       // 14-04-2008 5.6 BMG
                   }
                   if (iBypass) {                                                           // 30-04-2008 5.7 BMG
                       sprintf(msg, "               RECALL IS WRONG TYPE");                 // 30-04-2008 5.7 BMG
                       disp_msg(msg);                                                       // 30-04-2008 5.7 BMG
                   }
               }
           }  // end of if (debug)                                                  // 31-05-07 PAB Recalls
        } //end of while
    } // end of if iExpired || iBypass

    if (usrrc < RC_OK) {
       // we reached end of index file without finding an unprocessed record
       memcpy(pRCE->cmd, "RCE", sizeof(pRCE->cmd));
       memcpy(pRCE->opid, pRCD->opid, sizeof(pRCE->opid));
       out_lth = LRT_RCE_LTH;
       return;
    }

    // prepare RCC response

    memcpy(pRCC->cmd,"RCC", sizeof(pRCC->cmd));
    memcpy(pRCC->opid, pRCD->opid, sizeof(pRCC->opid));
    lIndexPtr = (lIndexPtr / RCINDX_RECL);                                                              // 20-02-2009 5.1 BMG
    LONG_TO_ARRAY(pRCC->Index, lIndexPtr);
    unpack(pRCC->anRecallRef, 8, rcindxrec.abRecallReference, 4, 0);
    memcpy(pRCC->cRecallType,rcindxrec.cRecallType,sizeof(pRCC->cRecallType));
    memcpy(pRCC->abRecallDesc,rcindxrec.abRecallDesc,sizeof(pRCC->abRecallDesc));
    unpack(pRCC->anRecallCnt,4,rcindxrec.abItemCount,2,0);
    /* If we have a type I or type C, write the due by date into the active */                          // 30-04-2008 5.7 BMG
    /* date field to make PPC processing easier. */                                                     // 30-04-2008 5.7 BMG
    // 3 lines commented out                                                   // CSk 30-11-2010 Recall Improvements
    //if ( ((memcmp(rcindxrec.cRecallType,"C",1) == 0) || (memcmp(rcindxrec.cRecallType,"I",1) == 0)) ) { // 30-04-2008 5.7 BMG
    //    unpack(pRCC->cActiveDate,8,rcindxrec.abExpiryDate,4,0);                                         // 30-04-2008 5.7 BMG
    //} else unpack(pRCC->cActiveDate,8,rcindxrec.abActiveDate,4,0);                                      // 30-04-2008 5.7 BMG
    // Copy Expiry Date to Active Date for all recall types                    // CSk 30-11-2010 Recall Improvements
    unpack(pRCC->cActiveDate,8,rcindxrec.abExpiryDate,4,0);                    // CSk 30-11-2010 Recall Improvements
    memcpy(pRCC->cMsgAvail,rcindxrec.cSpeicalIns,sizeof(pRCC->cMsgAvail));
    memcpy(pRCC->cLabelType, rcindxrec.abLabelType, 2);
    memcpy(pRCC->cMRQ, rcindxrec.cMRQ, 2);                                                              // 30-04-2008 5.7 BMG
    
    pRCC->cRecallStatus = *rcindxrec.cRecallStatus;             // CSk 13-05-2010 Recalls Phase 1
    pRCC->cTailored = 'N';                                      // CSk 13-05-2010 Recalls Phase 1
                                                                // CSk 13-05-2010 Recalls Phase 1
    if ((  (*rcindxrec.cRecallType == 'R')     //100% Returns      // CSk 13-05-2010 Recalls Phase 1
        || (*rcindxrec.cRecallType == 'S')) && //100% Batch Returns// CSk 13-05-2010 Recalls Phase 1
         strncmp(rcindxrec.abRecallDesc, "NT*", 3)) {           // CSk 13-05-2010 Recalls Phase 1
           // if does NOT start with NT*                        // CSk 13-05-2010 Recalls Phase 1
        pRCC->cTailored = 'Y';                                  // CSk 13-05-2010 Recalls Phase 1
    }                                                           // CSk 13-05-2010 Recalls Phase 1

    out_lth = LRT_RCC_LTH;
    return;
}


typedef struct LRT_RCG_Txn {
   BYTE cmd[3];
   BYTE opid[3];
   BYTE anRecallRef[8];
   BYTE anRecallItem[6];                 // Boots Code no check digit unpacked
   BYTE anRecallCount[4];                // item count to update recall file
} LRT_RCG;                                    
#define LRT_RCG_LTH sizeof(LRT_RCG)

void RecallCount(char *inbound) {                               // 24-05-07 PAB Recalls

    LRT_RCG* pRCG = (LRT_RCG*)inbound;                          // 31-05-07 PAB Recalls

    LONG usrrc = RC_OK;                                         // 24-05-07 PAB Recalls
    LONG lItemArrayptr = 0;                                     // 31-05-07 PAB Recalls
    LONG lRecallCount = 0;                                      // 31-05-07 PAB Recalls
    //LONG lNewCount = 0;                                       // 31-05-07 PAB recalls
    BYTE anRecallCount[4];                                      // 20-06-07 PAB recalls
    BYTE uncounted[2];
    memset(uncounted, 0xFF, 2);                                                          // 30-08-2007 5.2 BMG
    UNUSED(inbound);                                            // 24-05-07 PAB Recalls
                                                                // 24-05-07 PAB Recalls
    // check status of recall files                             // 24-05-07 PAB Recalls
    usrrc = CheckRecallAvailable();                             // 24-05-07 PAB Recalls
    if (usrrc!=0) {                                             // 24-05-07 PAB Recalls
        return;                                                 // 24-05-07 PAB Recalls
    }                                                           // 24-05-07 PAB Recalls
                                                                // 24-05-07 PAB Recalls
    memcpy( recallrec.abRecallReference,                        // 24-05-07 PAB Recalls
            pRCG->anRecallRef, 8 );                             // 24-05-07 PAB Recalls
                                                                // 31-05-07 PAB Recalls
    recallrec.ubChain = 0;                                      // 31-05-07 PAB Recalls
    // read the first chain  and look for the item to update    // 31-05-07 PAB Recalls
    while (usrrc >= 0) {
       usrrc = s_read( 0, recall.fnum, (void *)&recallrec,      // 24-05-07 PAB Recalls
                         RECALL_RECL, RECALL_KEYL );            // 24-05-07 PAB Recalls
                                                                // 31-05-07 PAB Recalls
       if (usrrc < RC_OK) {                                     // 24-05-07 PAB Recalls
          disp_msg("RD RECALL failed");                         // 24-05-07 PAB Recalls
          prep_nak("ERRORUThis item could not be found "        // 24-05-07 PAB Recalls
                   "on this Recall");                           // 24-05-07 PAB Recalls
          return;                                               // 24-05-07 PAB Recalls
       }

       lItemArrayptr = 0;                                       // 31-05-07 PAB Recalls
       // look for the item on this recall record
       pack(sbuf, 3, pRCG->anRecallItem, 6, 0);                 // 31-05-07 PAB Recalls

       if (debug) {
          disp_msg("Update Recall Item");
          dump(sbuf,3);
       }

       while (lItemArrayptr < 50) {                                                                     // 31-05-07 PAB Recalls
          if (memcmp(sbuf, recallrec.aRecallItems[lItemArrayptr].abItemCode, 3 )==0) {                  // 31-05-07 PAB Recalls
              // the item is found on the current recall record
              // if this item has a previous count then send it to the PPC                              // 20-6-2007 PAB
              if (memcmp(recallrec.aRecallItems[lItemArrayptr].anCountTSF, uncounted, 2) == 0) {        // 20-6-2007 PAB
                  // the count is F's so dont try and unpack it                                         // 20-6-2007 PAB // 30-08-2007 5.2 BMG
                  lRecallCount = 0;
              } else {                                                                                  // 20-6-2007 PAB
                 unpack(anRecallCount,4,recallrec.aRecallItems[lItemArrayptr].anCountTSF, 2, 0);        // 20-6-2007 PAB
                 lRecallCount = satoi(anRecallCount, 4);
              }
              //RFSCC will now update the running total when the recall is committed to the STKMQ       // 9-8-07 PAB
              //lNewCount = satoi(pRCG->anRecallCount,4);
              //lRecallCount = lRecallCount + lNewCount;                                                // 9-8-07 PAB
              LONG_TO_ARRAY(anRecallCount, lRecallCount);                                               // 20-6-2007 PAB
              //pack(recallrec.aRecallItems[lItemArrayptr].anCountTSF, 4,anRecallCount, 2,0);             // 20-6-2007 PAB // 30-08-2007 5.2 BMG
              pack(recallrec.aRecallItems[lItemArrayptr].anSessionCount, 2, pRCG->anRecallCount ,4 ,0); // 20-6-2007 PAB
              // set counted today flag to "Y"
              memset(recallrec.aRecallItems[lItemArrayptr].cCountUpdatedToday,0x59,1);
              // write back the recall record
              usrrc = s_write( 0, recall.fnum,
                             (void *)&recallrec, RECALL_RECL, 0L );
              if (usrrc < RC_OK) {                                                                      // 24-05-07 PAB Recalls
                 disp_msg("WR RECALL failed");                                                          // 24-05-07 PAB Recalls
                 prep_nak("ERRORUnable to update RECALL file. "                                         // 24-05-07 PAB Recalls
                          "Check appl event logs" );                                                    // 24-05-07 PAB Recalls
                 return;                                                                                // 24-05-07 PAB Recalls
             }
             prep_ack("");
             return;
         }
          lItemArrayptr++;                                                                              // 31-05-07 PAB Recalls
       }
       recallrec.ubChain++;
    }
    // fall through should never get here
    disp_msg("Recall item update item not found");              // 24-05-07 PAB Recalls
    prep_nak("ERRORUThis item could not be found "              // 24-05-07 PAB Recalls
             "on this Recall");                                 // 24-05-07 PAB Recalls
    return;
}                                                               // 24-05-07 PAB Recalls


typedef struct {                                                                       
    BYTE anRecallItem[6];                                                          
    BYTE abItemDesc[20];
    BYTE anItemTSF[4];
    BYTE anRecCnt[4];                      // 20-6-2007 PAB
    BYTE cItemFlag[1];                     // 07-09-2007 1.1 BMG
    BYTE cVisible;                         // CSk 13-05-2010 Recalls Phase 1
} aRecalls;                                                                         

typedef struct LRT_RCF_Txn {
   BYTE cmd[3];
   BYTE opid[3];
   BYTE anRecallRef[8];
   BYTE cMoreItems[1];                      // "Y" if more items to come
   BYTE cStatus[1];                        // status of recall from file.
   aRecalls abItemArray[10];               // Pre-Pack with "FFFFFF"
} LRT_RCF;                                    
#define LRT_RCF_LTH sizeof(LRT_RCF)

typedef struct LRT_RCH_Txn {
   BYTE cmd[3];
   BYTE opid[3];                  
   BYTE anRecallRef[8];
   BYTE anItemPtr[4];                     // pointer to item in recall record -> start "0000"
} LRT_RCH;                                    
#define LRT_RCH_LTH sizeof(LRT_RCH)

void RecallSelectList(char *inbound) {                          // 24-05-07 PAB Recalls
                                                                // 31-05-07 PAB Recalls
    LRT_RCH* pRCH = (LRT_RCH*)inbound;                          // 31-05-07 PAB Recalls
    LRT_RCF* pRCF = (LRT_RCF*)out;                              // 31-05-07 PAB Recalls
    LRT_RCE* pRCE = (LRT_RCE*)out;                              // 31-05-07 PAB Recalls
                                                                // 31-05-07 PAB Recalls
    DOUBLE dDateOfStockMovement;                                // CSk 30-11-2010 Recall Improvements
    DOUBLE dTodayDate;                                          // CSk 13-05-2010 Recalls Phase 1
    WORD hour, min;                                             // CSk 13-05-2010 Recalls Phase 1
    LONG sec, day, month, year;                                 // CSk 13-05-2010 Recalls Phase 1
    LONG usrrc = RC_OK;                                         // 24-05-07 PAB Recalls
    LONG lIndexPtr = 0;                                         // 29-05-07 PAB Recalls
    LONG lItemCnt = 0;                                          // 31-05-07 PAB Recalls
    LONG lArrayPtr = 0;                                         // 31-05-07 PAB Recalls
    LONG lItemsinRecall = 0;                                    // 31-05-07 PAB Recalls
    // BYTE boots_code[4];                                      // 31-05-07 PAB Recalls
    BYTE boots_code_ncd[4];                                     // 31-05-07 PAB Recalls
    memset(boots_code_ncd, 0x00, 4);                            // 31-05-07 PAB Recalls
    BYTE null_boots_code[3];                                    // 31-05-07 PAB Recalls
    BYTE uncounted[2];                                          // 20-06-07 PAB Recalls
    memset(null_boots_code, 0x00, 3);                           // 31-05-07 PAB Recalls
    memset(uncounted, 0xFF, 2);                                 // 27-06-07 PAB recalls
                                                                // 31-05-07 PAB Recalls
    UNUSED(inbound);                                            // 24-05-07 PAB Recalls
                                                                // 24-05-07 PAB Recalls
    // check status of recall files                             // 24-05-07 PAB Recalls
    usrrc = CheckRecallAvailable();                             // 24-05-07 PAB Recalls
    if (usrrc!=0) {                                             // 24-05-07 PAB Recalls
        return;                                                 // 24-05-07 PAB Recalls
    }                                                           // 24-05-07 PAB Recalls                                               // 31-05-07 PAB Recalls
                                                                // 31-05-07 PAB Recalls
    // Read the recalls file for the requested ID               // 31-05-07 PAB Recalls
                                                                // 31-05-07 PAB Recalls
    memcpy( recallrec.abRecallReference,                        // 24-05-07 PAB Recalls
             pRCH->anRecallRef, 8 );                            // 24-05-07 PAB Recalls
                                                                // 31-05-07 PAB Recalls
    // compute which recall chain the items required are located// 31-05-07 PAB Recalls
    lIndexPtr = satoi(pRCH->anItemPtr, 4);                      // 31-05-07 PAB Recalls
    lItemCnt = lIndexPtr;                                       // 31-05-07 PAB Recalls
    recallrec.ubChain = 0;                                      // 31-05-07 PAB Recalls

    while (lIndexPtr >= 50) {                                   // 31-05-07 PAB Recalls
        recallrec.ubChain++;                                    // 31-05-07 PAB Recalls
        lIndexPtr = lIndexPtr - 50;                             // 31-05-07 PAB Recalls
    }                                                           // 31-05-07 PAB Recalls
                                                                // 31-05-07 PAB Recalls
        usrrc = s_read( 0, recall.fnum, (void *)&recallrec,     // 24-05-07 PAB Recalls
                              RECALL_RECL, RECALL_KEYL );       // 24-05-07 PAB Recalls
                                                                // 31-05-07 PAB Recalls
        //If error reading RECALL                               // 24-05-07 PAB Recalls
        if (usrrc<=RC_OK) {                                     // 24-05-07 PAB Recalls
           recall.present=FALSE;                                // 24-05-07 PAB Recalls
        } else {  // 24-05-07 PAB Recalls                       // 31-05-07 PAB Recalls
            recall.present=TRUE;                                // 24-05-07 PAB Recalls
            if (debug) {                                        // 24-05-07 PAB Recalls
               sprintf(msg, "OK, REC :");                       // 24-05-07 PAB Recalls
               disp_msg(msg);                                   // 24-05-07 PAB Recalls
               //dump( (BYTE *)&recallrec, RECALL_RECL );       // 24-05-07 PAB Recalls
            }
        }

       if (debug) {
          sprintf(msg, "Requesting Recall Items. %08lX ", lItemCnt );
          disp_msg(msg);
          disp_msg("Recall item count is -");
          dump((BYTE *)recallrec.anItemCount,sizeof(recallrec.anItemCount));
       }

       lItemsinRecall = satoi(recallrec.anItemCount, sizeof(recallrec.anItemCount));

       // if all items send constuct RCE
       if (recall.present == FALSE || lItemCnt >= lItemsinRecall) {
          // we have sent all the items
          memcpy(pRCE->cmd, "RCE", sizeof(pRCE->cmd));
          memcpy(pRCE->opid, pRCH->opid, sizeof(pRCE->opid));
          out_lth = LRT_RCE_LTH;
          return;
       }

       // else construct RCF response record to send items
       memcpy(pRCF->cmd, "RCF", sizeof(pRCF->cmd));
       memcpy(pRCF->opid, pRCH->opid, sizeof(pRCF->opid));
       memcpy(pRCF->anRecallRef,pRCH->anRecallRef,sizeof(pRCF->anRecallRef));

       if (lItemCnt < lItemsinRecall) {
          memset(pRCF->cMoreItems,'Y',1);
       }

     while (lArrayPtr < 10) {
        // prepack outbound array with 'FF'
        memset(pRCF->abItemArray[lArrayPtr].anRecallItem,0x46,
               sizeof(pRCF->abItemArray[lArrayPtr].anRecallItem));
        memset(pRCF->abItemArray[lArrayPtr].abItemDesc,0x46,
               sizeof(pRCF->abItemArray[lArrayPtr].abItemDesc));
        memset(pRCF->abItemArray[lArrayPtr].anItemTSF,0x46,
               sizeof(pRCF->abItemArray[lArrayPtr].anItemTSF));
        memset (pRCF->abItemArray[lArrayPtr].anRecCnt,0x46,          // 20-6-2007 PAB
               sizeof(pRCF->abItemArray[lArrayPtr].anRecCnt));       // 20-6-2007 PAB
        lArrayPtr++;
    }

    lArrayPtr=0;
    open_imstc();
    IdfOpen();
    open_stock();

    // populate the item array
    while ((lArrayPtr < 10) &&
           (lItemCnt <= lItemsinRecall)) {

        // unpack the boots code from recall rec to output txn.
        if (memcmp(recallrec.aRecallItems[lIndexPtr].abItemCode,
                   null_boots_code, 3) == 0) {
                   // null item code reached in recall record array
            memset(pRCF->cMoreItems,'N',1);
            break;
        }

        unpack(pRCF->abItemArray[lArrayPtr].anRecallItem,6,
               recallrec.aRecallItems[lIndexPtr].abItemCode,3,0);

        if (*recallrec.aRecallItems[lIndexPtr].cCountUpdatedToday == 'Y') {                                      // 07-09-2007 5.3 BMG
            unpack(pRCF->abItemArray[lArrayPtr].anRecCnt,4,                                                      // 07-09-2007 5.3 BMG
                   recallrec.aRecallItems[lIndexPtr].anSessionCount, 2, 0);                                      // 07-09-2007 5.3 BMG
        } else {                                                                                                 // 07-09-2007 5.3 BMG
           // if this item has a previous count then send it to the PPC                    // 20-6-2007 PAB
           if (memcmp(recallrec.aRecallItems[lIndexPtr].anCountTSF, uncounted, 2) == 0) {  // 20-6-2007 PAB
               // the count is spaces so dont try and unpack it                            // 20-6-2007 PAB
               memset(pRCF->abItemArray[lArrayPtr].anRecCnt,0x20,4);                       // 20-6-2007 PAB
           } else {                                                                        // 20-6-2007 PAB
               unpack(pRCF->abItemArray[lArrayPtr].anRecCnt,4,                             // 20-6-2007 PAB
                      recallrec.aRecallItems[lIndexPtr].anCountTSF, 2, 0);                 // 20-6-2007 PAB
           }                                                                               // 20-6-2007 PAB
        }                                                                                                        // 07-09-2007 5.3 BMG

        memcpy(pRCF->abItemArray[lArrayPtr].cItemFlag, recallrec.aRecallItems[lIndexPtr].cCountUpdatedToday, 1); // 07-09-2007 5.3 BMG
        

        // look up the item description from the IDF
        calc_boots_cd(idfrec.boots_code, recallrec.aRecallItems[lIndexPtr].abItemCode);
        usrrc = IdfRead(__LINE__);

        if (usrrc<=0L) {
            // set idf descrption to not of file
            memcpy( pRCF->abItemArray[lArrayPtr].abItemDesc,
                    "Item not on file    ", 20 );                      //Defect 4806    // CSk 30-11-2010 Recall Improvements
        } else {
            memcpy( pRCF->abItemArray[lArrayPtr].abItemDesc, idfrec.stndrd_desc, 20 );
        }

        // get the current TSF.
        // look up item on IMSTC (to get latest stock figure)

        memcpy(boots_code_ncd+1, recallrec.aRecallItems[lIndexPtr].abItemCode, 3);
        memset ( imstcrec.bar_code, 0x00, sizeof(imstcrec.bar_code) ) ;
        memcpy ( imstcrec.bar_code + 7, boots_code_ncd, 4 ) ;

        if (debug) {
            disp_msg ( "RD IMSTC : " ) ;
            dump ( imstcrec.bar_code, 11 ) ;
        }
        usrrc = s_read(0, imstc.fnum, (void *)&imstcrec, IMSTC_RECL, IMSTC_KEYL);

        if (usrrc<=0L) {
            imstc.present=FALSE;
        } else {
            imstc.present=TRUE;
        }

        if (imstc.present) {
           // Use stock figure from IMSTC
           sprintf( sbuf, "%04d", imstcrec.stock_figure );
           memcpy( pRCF->abItemArray[lArrayPtr].anItemTSF, sbuf,
                   sizeof(pRCF->abItemArray[lArrayPtr].anItemTSF) );
        } else {
           memcpy(stockrec.boots_code, idfrec.boots_code, sizeof(stockrec.boots_code) );    // 02-08-07 PAB Recalls
           usrrc = ReadStock(__LINE__);
           if (usrrc<=0L) {
               memset( pRCF->abItemArray[lArrayPtr].anItemTSF, 0x30,
                       sizeof(pRCF->abItemArray[lArrayPtr].anItemTSF) );
           } else {
              // Use stock figure from STOCK
              sprintf( sbuf, "%04d", stockrec.stock_fig );
              memcpy( pRCF->abItemArray[lArrayPtr].anItemTSF, sbuf,
                      sizeof(pRCF->abItemArray[lArrayPtr].anItemTSF) );
           }
        }

        pRCF->abItemArray[lArrayPtr].cVisible = 'N';                                              // CSk 13-05-2010 Recalls Phase 1
        //--------------------------------------------------------------------------------        // CSk 13-05-2010 Recalls Phase 1
        //Perform tailoring checks if 100% Returns and description does NOT start with NT*        // CSk 13-05-2010 Recalls Phase 1
        //--------------------------------------------------------------------------------        // CSk 13-05-2010 Recalls Phase 1
        if (( (*rcindxrec.cRecallType == 'R') || (*rcindxrec.cRecallType == 'S')) &&              // CSk 30-11-2010 Recall Improvements
            strncmp(rcindxrec.abRecallDesc, "NT*", 3)) {                                          // CSk 13-05-2010 Recalls Phase 1
            //-------------------------------------------------------                             // CSk 13-05-2010 Recalls Phase 1
            // Set item to visible if one of the following 3 is true:                             // CSk 13-05-2010 Recalls Phase 1
            //                                                                                    // CSk 13-05-2010 Recalls Phase 1
            // 1. Item has had a stock movement in the last 3 months (90 days)                    // CSk 13-05-2010 Recalls Phase 1
            // 2. Item was counted in the last 3 months (90 days)                                 // CSk 30-11-2010 Recall Improvements
            // 3. Item had a delivery in the last 3 months (90 days)                              // CSk 30-11-2010 Recall Improvements
            //------------------------------------------------------                              // CSk 13-05-2010 Recalls Phase 1
            sysdate( &day, &month, &year, &hour, &min, &sec );                                    // CSk 13-05-2010 Recalls Phase 1 
            dTodayDate = ConvGJ( day, month, year );                                              // CSk 13-05-2010 Recalls Phase 1 
                                                                                                  // CSk 13-05-2010 Recalls Phase 1
            if (imstc.present) {                                                                  // CSk 13-05-2010 Recalls Phase 1
                // If item on IMSTC, then this means that we have not read the STOCK              // CSk 13-05-2010 Recalls Phase 1
                // file at this point in order to obtain the date of last movement                // CSk 13-05-2010 Recalls Phase 1
                memcpy(stockrec.boots_code, idfrec.boots_code, sizeof(stockrec.boots_code) );     // CSk 13-05-2010 Recalls Phase 1
                usrrc = ReadStock(__LINE__);                                                      // CSk 13-05-2010 Recalls Phase 1
                
                if (usrrc > RC_OK) {  // Use Date of Last Sale from STOCK                         // CSk 30-11-2010 Recall Improvements
                   memcpy(sbuf, "20", 2);                               // Add century            // CSk 13-05-2010 Recalls Phase 1
                   unpack( sbuf+2, 6, stockrec.date_last_move, 3, 0 );                            // CSk 13-05-2010 Recalls Phase 1  
                   day   = satol( sbuf+6, 2 );                                                    // CSk 13-05-2010 Recalls Phase 1  
                   month = satol( sbuf+4, 2 );                                                    // CSk 13-05-2010 Recalls Phase 1  
                   year  = satol( sbuf,   4 );                                                    // CSk 13-05-2010 Recalls Phase 1  
                   dDateOfStockMovement = ConvGJ( day, month, year );                             // CSk 30-11-2010 Recall Improvements 

                   if ((dTodayDate - dDateOfStockMovement) <= 90) {  // approx. 3 months          // CSk 30-11-2010 Recall Improvements 
                       pRCF->abItemArray[lArrayPtr].cVisible = 'Y';                               // CSk 30-11-2010 Recall Improvements
                                                                                                  // CSk 30-11-2010 Recall Improvements
                   } else { // Use Date of Last Count from STOCK                                  // CSk 30-11-2010 Recall Improvements   
                      memcpy(sbuf, "20", 2);                               // Add century         // CSk 30-11-2010 Recall Improvements   
                      unpack( sbuf+2, 6, stockrec.date_last_count, 3, 0 );                        // CSk 30-11-2010 Recall Improvements    
                      day   = satol( sbuf+6, 2 );                                                 // CSk 30-11-2010 Recall Improvements    
                      month = satol( sbuf+4, 2 );                                                 // CSk 30-11-2010 Recall Improvements    
                      year  = satol( sbuf,   4 );                                                 // CSk 30-11-2010 Recall Improvements    
                      dDateOfStockMovement = ConvGJ( day, month, year );                          // CSk 30-11-2010 Recall Improvements 

                      if ((dTodayDate - dDateOfStockMovement) <= 90) {  // approx. 3 months       // CSk 30-11-2010 Recall Improvements 
                          pRCF->abItemArray[lArrayPtr].cVisible = 'Y';                            // CSk 30-11-2010 Recall Improvements
                      } else { // Use Date of Last Delivery from STOCK                            // CSk 30-11-2010 Recall Improvements                                                 
                          memcpy(sbuf, "20", 2);                               // Add century     // CSk 30-11-2010 Recall Improvements   
                          unpack( sbuf+2, 6, stockrec.date_last_rec, 3, 0 );                      // CSk 30-11-2010 Recall Improvements    
                          day   = satol( sbuf+6, 2 );                                             // CSk 30-11-2010 Recall Improvements    
                          month = satol( sbuf+4, 2 );                                             // CSk 30-11-2010 Recall Improvements    
                          year  = satol( sbuf,   4 );                                             // CSk 30-11-2010 Recall Improvements    
                          dDateOfStockMovement = ConvGJ( day, month, year );                      // CSk 30-11-2010 Recall Improvements 

                          if ((dTodayDate - dDateOfStockMovement) <= 90) {  // approx. 3 months   // CSk 30-11-2010 Recall Improvements 
                              pRCF->abItemArray[lArrayPtr].cVisible = 'Y';                        // CSk 30-11-2010 Recall Improvements
                          }                                                                       // CSk 30-11-2010 Recall Improvements
                      }                                                                           // CSk 30-11-2010 Recall Improvements
                   }                                                                              // CSk 30-11-2010 Recall Improvements
                } // else drop through to next test                                               // CSk 30-11-2010 Recall Improvements
            } 
                                                                                                  // CSk 30-11-2010 Recall Improvements
            if  (pRCF->abItemArray[lArrayPtr].cVisible == 'N') {                                  // CSk 13-05-2010 Recalls Phase 1 
                //-----------------                                                               // CSk 13-05-2010 Recalls Phase 1
                // 2. Item TSF > 0                                                                // CSk 13-05-2010 Recalls Phase 1
                //-----------------                                                               // CSk 13-05-2010 Recalls Phase 1
                if (strncmp(pRCF->abItemArray[lArrayPtr].anItemTSF, "0000", 4)) {                 // CSk 13-05-2010 Recalls Phase 1                                                                                         
                    pRCF->abItemArray[lArrayPtr].cVisible = 'Y';                                  // CSk 13-05-2010 Recalls Phase 1
                } else {                                                                          // CSk 13-05-2010 Recalls Phase 1
                    //--------------------------                                                  // CSk 13-05-2010 Recalls Phase 1
                    // 3. Item is an active SKU                                                   // CSk 13-05-2010 Recalls Phase 1
                    //--------------------------                                                  // CSk 13-05-2010 Recalls Phase 1
                    // Check if item is on a LIVE Planner                                         // CSk 13-05-2010 Recalls Phase 1
                    usrrc = SritmlOpen();                                                         // CSk 13-05-2010 Recalls Phase 1
                                                                                                  // CSk 13-05-2010 Recalls Phase 1
                    MEMCPY(sritmlrec.abItemCode, recallrec.aRecallItems[lIndexPtr].abItemCode);   // CSk 13-05-2010 Recalls Phase 1
                    sritmlrec.ubRecChain = 0;                                                     // CSk 13-05-2010 Recalls Phase 1
                                                                                                  // CSk 13-05-2010 Recalls Phase 1
                    usrrc = SritmlRead(__LINE__);                                                 // CSk 13-05-2010 Recalls Phase 1
                    if (usrrc < 0) {                                                              // CSk 13-05-2010 Recalls Phase 1
                        // Item is not on a Live planner so check PENDING Planners                // CSk 13-05-2010 Recalls Phase 1
                        usrrc = SritmpOpen();                                                     // CSk 13-05-2010 Recalls Phase 1
                                                                                                  // CSk 13-05-2010 Recalls Phase 1
                       MEMCPY(sritmprec.abItemCode, recallrec.aRecallItems[lIndexPtr].abItemCode);// CSk 13-05-2010 Recalls Phase 1
                       sritmprec.ubRecChain = 0;                                                  // CSk 13-05-2010 Recalls Phase 1
                                                                                                  // CSk 13-05-2010 Recalls Phase 1
                       usrrc = SritmpRead(__LINE__);                                              // CSk 13-05-2010 Recalls Phase 1
                       if (usrrc >= 0) {                                                          // CSk 13-05-2010 Recalls Phase 1
                           // Item is ON PENDING Planner                                          // CSk 13-05-2010 Recalls Phase 1
                           pRCF->abItemArray[lArrayPtr].cVisible = 'Y';                           // CSk 13-05-2010 Recalls Phase 1
                       }                                                                          // CSk 13-05-2010 Recalls Phase 1
                       SritmpClose( CL_SESSION );                                                 // CSk 13-05-2010 Recalls Phase 1
                    } else {                                                                      // CSk 13-05-2010 Recalls Phase 1
                        pRCF->abItemArray[lArrayPtr].cVisible = 'Y';                              // CSk 13-05-2010 Recalls Phase 1
                    }                                                                             // CSk 13-05-2010 Recalls Phase 1
                    SritmlClose( CL_SESSION );                                                    // CSk 13-05-2010 Recalls Phase 1
                }                                                                                 // CSk 13-05-2010 Recalls Phase 1
            }                                                                                     // CSk 13-05-2010 Recalls Phase 1
        }                                                                                         // CSk 13-05-2010 Recalls Phase 1

        lArrayPtr++;                                           // 31-05-07 PAB Recalls
        lIndexPtr++;                                           // 31-05-07 PAB Recalls
    }                                                          // 31-05-07 PAB Recalls
                                                               // 31-05-07 PAB Recalls
    if (lItemCnt == lItemsinRecall) {                          // 31-05-07 PAB Recalls
       memset(pRCF->cMoreItems,'N',1);                         // 31-05-07 PAB Recalls
    }                                                          // 31-05-07 PAB Recalls
    memcpy(pRCF->cStatus,recallrec.cRecallStatus,1);           // 09-08-07 PAB Recalls
                                                               // 31-05-07 PAB Recalls
    close_imstc(CL_SESSION);                                   // 31-05-07 PAB Recalls
    IdfClose(CL_SESSION);                                      // 31-05-07 PAB Recalls
    close_stock( CL_SESSION );                                 // 31-05-07 PAB Recalls
                                                               // 31-05-07 PAB Recalls
    out_lth = LRT_RCF_LTH;                                     // 31-05-07 PAB Recalls
    return;                                                    // 31-05-07 PAB Recalls
}                                                              // 24-05-07 PAB Recalls


typedef struct LRT_RCI_Txn {
   BYTE cmd[3];
   BYTE opid[3];                  
   BYTE anRecallRef[8];
} LRT_RCI;                                    
#define LRT_RCI_LTH sizeof(LRT_RCI)

typedef struct LRT_RCJ_Txn {
   BYTE cmd[3];
   BYTE opid[3];                  
   BYTE anRecallRef[8];
   BYTE abSpecialIns[160];
} LRT_RCJ;                                    
#define LRT_RCJ_LTH sizeof(LRT_RCJ)

void RecallInstructions(char *inbound) {                       // 24-05-07 PAB Recalls

   LRT_RCI* pRCI = (LRT_RCI*)inbound;                          // 31-05-07 PAB Recalls
   LRT_RCJ* pRCJ = (LRT_RCJ*)out;                              // 31-05-07 PAB Recalls
                                                               // 31-05-07 PAB Recalls
   LONG usrrc = RC_OK;                                         // 24-05-07 PAB Recalls
                                                               // 31-05-07 PAB Recalls
   UNUSED(inbound);                                            // 24-05-07 PAB Recalls
                                                               // 24-05-07 PAB Recalls
   // check status of recall files                             // 24-05-07 PAB Recalls
   usrrc = CheckRecallAvailable();                             // 24-05-07 PAB Recalls
   if (usrrc!=0) {                                             // 24-05-07 PAB Recalls
       return;                                                 // 24-05-07 PAB Recalls
   }                                                           // 24-05-07 PAB Recalls
                                                               // 24-05-07 PAB Recalls
   memcpy(rcspirec.abRecallReference,pRCI->anRecallRef,8);     // 24-05-07 PAB Recalls
   usrrc = s_read( 0, rcspi.fnum, (void *)&rcspirec,           // 24-05-07 PAB Recalls
                              RCSPI_RECL, RCSPI_KEYL );        // 24-05-07 PAB Recalls

   if (usrrc < RC_OK) {                                         // 24-05-07 PAB Recalls
       disp_msg("RCSPI Record not found");                      // 24-05-07 PAB Recalls
       prep_nak("The special instructions "                     // 20-08-07 PAB Recalls
                "for this Recall could not be found." );        // 24-05-07 PAB Recalls
       return;                                                  // 24-05-07 PAB Recalls
  }                                                             // 24-05-07 PAB Recalls
   memcpy(pRCJ->cmd, "RCJ", sizeof(pRCJ->cmd));
   memcpy(pRCJ->opid,pRCI->opid,sizeof(pRCJ->opid));
   memcpy(pRCJ->anRecallRef, pRCI->anRecallRef,
          sizeof(pRCJ->anRecallRef));
   memcpy(pRCJ->abSpecialIns,rcspirec.abMessage,
           sizeof(rcspirec.abMessage));

   out_lth = LRT_RCF_LTH;                                       // 31-05-07 PAB Recalls
   return;

}                                                               // 24-05-07 PAB Recalls


void StopRecalls(void) {                                        // 24-05-07 PAB Recalls
    // block access to recall files                             // 24-05-07 PAB Recalls
    gRecallFilesAvailable = 1;                                  // 24-05-07 PAB Recalls
    // and force physical close of recall files.                // 31-05-07 PAB Recalls
    if (debug) {                                                // 11-09-2007 5.5 BMG
        disp_msg("Got REC* so closing Recalls Files");          // 11-09-2007 5.5 BMG
    }                                                           // 11-09-2007 5.5 BMG
    close_recall( CL_ALL );                                     // 31-05-07 PAB Recalls
    close_rcindx ( CL_ALL );                                    // 31-05-07 PAB Recalls
    close_rcspi ( CL_ALL) ;                                     // 31-05-07 PAB Recalls
    if (debug) {                                                // 11-09-2007 5.5 BMG
        disp_msg("Closed Recalls Files");                       // 11-09-2007 5.5 BMG
    }                                                           // 11-09-2007 5.5 BMG
                                                                // 31-05-07 PAB Recalls
}                                                               // 24-05-07 PAB Recalls
                                                                // 24-05-07 PAB Recalls
                                                                // 24-05-07 PAB Recalls
