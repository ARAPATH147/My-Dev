// 2.1 - SW - 04/11/1998
//       Phase II enhancements
//       Add extra details into ENQUIRY structure
// 3.0 - SW - 28/08/2003
//       2003 Trial updates
//       Amend General_Enquiry struct to hold an active deal flag instead of
//       containing the deal number. Actual new deals info not required.
//
//4.02 - PAB 18/02/2004
//       2004 RF Trial Phase2 development
//       Changes to SNR and PRT transaction layouts for proximity printing
//
// 5.00 - PAB 5/5/04
//       Changes to include Pre-Scan transactions
//
// 6.00 - PAB 7-7-2004
//       Changes for MyStoreNet to include new transaction types
//
// 7.00 - PAB 22-5-2007 
//       Changes to include transaction types for recalls A7C
//
// 8.00 - PAB 7-8-2007
//       new transaction for Mobile Printing
//
// 9.00 - BMG 11-09-2007
//       New printer status PST_STALLED
//       Added last_access_time to PROG_PQ.
//       Moved DealEnquiry to here from transact.c.
//       Moved dump_pq_stack to here from rfs.c
//       Increased size of sales values in LRT_SSR and TILLREC.
//
// 10.00 - BMG 03-01-2008
//       Added WRF.
//
// 11.00 - BMG 06-02-2008
//       Added markdown flag to ENQUIRY and EQR structures.
//
// 12.00 - BMG 12-08-2008
//       Added changes for Multi-Sited Counts including adding new MSA & MSB messages
//       Altered process_gap and trans04_LRT_PRT function calls.
//
// 13.00 - BMG 01-09-2008
//       Added commands for ASN's.
//
// 14.00 - BMG 10-09-2008
//       Added ALR command for MC70 device support and modified SOR 
//       request with additiona fields.
//       Extended SOR request.
//       Added prototype for Wriekeyed.
// -------------------------------------------------------------------------------

//#include "flexif.h"

//#include "trans2.h"
//#include "dateconv.h"


#if !defined RFS_H
#define RFS_H 1

#include "rfsfile.h"
#include <time.h>                           // 11-09-2007 9 BMG

#define RFS_VER  "VERSION : A9B.0"          // Overall RFS Version Number
#define RFS_DATE __DATE__                   // Compile date
#define SEM_47_RUNNING  "pi:sellockb"       // PSS47 running semephore
#define SEM_LAB_RUNNING "pi:sellockp"       // PRINTSEL running semephore
//#define MAX_UNIT       120                // largest possible unit number
#define MAX_UNIT         255                // largest possible unit number
//#define MAX_CONC_UNITS 40                 // Max. concurrent units
#define MAX_CONC_UNITS   255                // Max. concurrent units
#define ALL_UNITS        -1                 // All units flag for unit dealloc
#define CHECK_G          2200               // number of cycles between checks  was 18 PAB
#define REPORT_DATASIZE  20                 // record size of data blocks
#define REPORT_BUFFER    0x4000L            // report buffer size
#define REPORT_SEQ_SIZE  4                  // Report Command SEQ Size

// Performance tuning options
#define HEADER_MAX       6                  // Max. no. of RLD concatinations
#define DETAIL_MAX       10                 // Max. no. of RUP concatinations

//Debug constants
#define DBG_LOCAL       0
#define DBG_FILE        1

// Report buffer
typedef struct Report_Buffer {
   LONG base;                       // base offset into physical file
   LONG end;                        // end offset of data (rec algnd)
   BYTE *buff;                      // pointer to buffer
} RBUF;

typedef struct FileNum_Table {
   LONG fnumx;
   BYTE ftype[1];
} FILE_TABLE;

typedef struct Active_LRT_Table {
   UBYTE state;
   LONG fnum1;             // work file 1 fnum (CHKWK...)
   LONG fnum2;             // work file 2 fnum (GAPWK...)
   LONG fnum3;             // current report file fnum
   WORD pq_sub1;           // work file 1 pq subscript
   WORD pq_sub2;           // work file 2 pq subscript
   LONG last_active_time;  // time last message received
   BYTE user[3];           // user id
   BYTE abOpName[15];      // Operator name
   BYTE authority[1];      // user's authority
   WORD count1;            // misc count for this handheld
   WORD count2;            // misc count for this handheld
   RBUF *rbufp;            // pointer to report buffer struct
   BYTE txn[3];            // last transaction received (shared info)
   BYTE unique[5];         // txn specific, unique info (shared info)
   BYTE bLocation;         // [U]nknown, [S]hop, [O]SSR                     //SDH 19-01-2005
   BYTE Type[1];           // Device Type [R] = RF PPC, [M] = MC70          //BMG 10-09-2008 14 MC70
} ACTIVE_LRT;                               // Units currently being used

typedef struct Program_Process_Queue {
   UBYTE state;                     // current processing state
   WORD unit;                       // handheld identifier
   BYTE fname[32];                  // work file name
   BYTE type;                       // work file ind. (SYS_LAB/GAP)
   WORD submitcnt;                  // 26-1-2007 PAB
   time_t last_access_time;         // Last time of file access 11-09-2007 9 BMG
   BYTE DevType[1];                 // Device Type [R] = RF PPC, [M] = MC70 //BMG 10-09-2008 14 MC70
// BOOLEAN disp;                    // displayed pq entry
// BOOLEAN disp_err;                // displayed pq error
} PROG_PQ;

// v4.01 START
//// 4690 file functions
//typedef struct C4690_File_Control {
//   LONG fnum;
//   UBYTE present;
//   UBYTE sessions;
//} FILE_CTRL;
// v4.01 END

// Shared memory buffer
typedef struct SMem_Status {
   BYTE state[1];          // state
   LONG last_active_time;  // time last txn received
   BYTE user[3];           // user id
   BYTE txn[3];            // last transaction received
   BYTE unique[5];         // variable data, depends on txn
} SHARE_STAT_REC;

// Misc
typedef struct Till_Rec {
   DOUBLE today;            // 11-09-2007 9 BMG
   DOUBLE wtd;              // 11-09-2007 9 BMG
} TILLREC;
typedef struct Till_Takings_Rec {
   TILLREC till[1000];
} TILL_TAKINGS;
//TILL_TAKINGS_REC_LTH = sizeof(TILL_TAKINGS);

// v2.1
typedef struct LRT_PLL_Txn {
   BYTE cmd[3];
   BYTE list_id[3];
   BYTE seq[3];
   BYTE list_status[1];       // [A]=Supervisor, [U]=normal user
   BYTE stamp[12];            // YYYYMMDDHHMM
   BYTE lines[4];
   BYTE username[15];
   BYTE cListStatus;          // [S]helf Monitor, [F]ast Fill, [O]ssr, [E]xcess stock
} LRT_PLL;                                                           // Picking list response
#define LRT_PLL_LTH sizeof(LRT_PLL)

// v2.1

// v2.1
typedef struct LRT_PLI_Txn {
   BYTE cmd[3];
   BYTE list_id[3];
   BYTE seq[3];
   BYTE boots_code[7];
   BYTE parent_code[7];
   BYTE item_desc[20];
   BYTE fill[4];
   BYTE status[1];  
   BYTE gap_flag[1];
   BYTE active_deal_flag[1];                                         // v2.1
   BYTE stock_figure[6];                                             // v2.1
   BYTE sel_desc[45];                                                // v2.1
   BYTE item_code[13];                                               // v2.1
   BYTE pli_qtyshelf[4];                                             // 19-02-04 PAB
   BYTE abBackCount[4];                                              // SDH 17-11-04 OSSR WAN
   BYTE cOssrItem;                                                   // SDH 17-11-04 OSSR WAN
   BYTE MultiSited[1];  // Multi-Site Item "Y" or " "                //BMG 12-Aug-2008 Multi-Sited Counts
} LRT_PLI;                                                           // Picking list item
#define LRT_PLI_LTH sizeof(LRT_PLI)

// v2.1

// v2.1

// v2.1

// v2.1


// Item Information
// v2.1

// v2.1

// v2.1

// v2.1

// v2.1

// v2.1

// v2.1
typedef struct {
   BYTE cmd[3];
   BYTE opid[3];
   BYTE item_code[13];
} LRT_PLU;                                    // Item enquiry request
#define LRT_PLU_LTH sizeof(LRT_PLU)

// v2.1
typedef struct {
   BYTE cmd[3];
   BYTE boots_code[7];
   BYTE item_desc[20];
   BYTE item_price[6];
   BYTE stock_figure[6];
   BYTE sel_desc[45];
   BYTE supply_method[1];
   BYTE redeemable[1];
} LRT_RSP;                                    // PLU response
#define LRT_RSP_LTH sizeof(LRT_RSP)

// v2.1

//MObile Printing PAB 07-08-07

// Reporting
typedef struct LRT_RPO_Txn {
   BYTE cmd[3];
   BYTE opid[3];
} LRT_RPO;                                    // Reports sign on
#define LRT_RPO_LTH sizeof(LRT_RPO)

typedef struct LRT_RPX_Txn {
   BYTE cmd[3];
   BYTE opid[3];
} LRT_RPX;                                    // Reports exit
#define LRT_RPX_LTH sizeof(LRT_RPX)

// v2.1

// v2.1
typedef struct LRT_RLR_Txn {
   BYTE cmd[3];
   BYTE seq[4];
   BYTE title[REPORT_DATASIZE];
   BYTE fname[12];
} LRT_RLR;                                    // Reports response
#define LRT_RLR_LTH sizeof(LRT_RLR)

// v2.1

// v2.1
typedef struct {
    BYTE seq[REPORT_SEQ_SIZE];
    BYTE data[REPORT_DATASIZE];
} LRT_RLD_REP;
#define LRT_RLD_REP_LTH sizeof(LRT_RLD_REP)
typedef struct LRT_RLD_Txn {
    BYTE cmd[3];
    BYTE rpt[3];
    LRT_RLD_REP rep[HEADER_MAX];
} LRT_RLD;                                   // Report headers (level 0s)
#define RLD_REP_OFFSET  6                    // Length on non-repeating data
#define LRT_RLD_MAX_LTH sizeof(LRT_RLD)      // N.B. variable length

// v2.1
typedef struct LRT_RPS_Txn {
   BYTE cmd[3];
   BYTE opid[3];
   BYTE fname[12];
   BYTE seq[REPORT_SEQ_SIZE];
} LRT_RPS;                                    // Report data request
#define LRT_RPS_LTH sizeof(LRT_RPS)

// v2.1
typedef struct LRT_RUP_Rpt {
   BYTE level[1];
   BYTE exp[1];
   BYTE data[REPORT_DATASIZE];
} LRT_RUP_REP;
#define LRT_RUP_REP_LTH sizeof(LRT_RUP_REP)
typedef struct LRT_RUP_Txn {
   BYTE cmd[3];
   BYTE rpt[3];
   LRT_RUP_REP rep[DETAIL_MAX];
} LRT_RUP;                                    // Report detail (level 1+s)
#define RUP_REP_OFFSET  6                // Length on non-repeating data
#define LRT_RUP_MAX_LTH sizeof(LRT_RUP)        // N.B. Variable length

// v2.1


// List-Driven Counting (all new to v2.1)
// v2.1

// Changes req'd : CLL equiv
typedef struct LRT_CLL_Txn {
   BYTE cmd[3];
   BYTE list_id[3];
   BYTE seq[3];
   BYTE num_items[3];         // Total number of items
   BYTE items_shopfloor[3];   // Items left on shopfloor
   BYTE items_backshop[3];    // Items left on backshop
   BYTE list_type[1];         // [H]ead office / [R]ectification
   BYTE bus_unit_name[15];
   BYTE active[1];
   BYTE abItemsOssr[3];       // SDH 17-01-2005 OSSR WAN
} LRT_CLL;                                    // Counting - List Ack
#define LRT_CLL_LTH sizeof(LRT_CLL)


typedef struct LRT_CLI_Txn {
   BYTE cmd[3];
   BYTE list_id[3];
   BYTE seq[3];
   BYTE boots_code[7];
   BYTE parent_code[7];
   BYTE item_code[13];
   BYTE sel_desc[45];
   BYTE active_deal_flag[1];
   BYTE product_group[6];
   BYTE count_backshop[4];
   BYTE count_shopfloor[4];
   BYTE status[1];
   BYTE abOSSRCount[4];                                                     // SDH 17-11-04 OSSR WAN
   BYTE cOssrItem;                                                          // SDH 17-11-04 OSSR WAN
} LRT_CLI;                                                                  // Counting - List Item in List
#define LRT_CLI_LTH sizeof(LRT_CLI)


// v2.1
typedef struct LRT_CLF_Txn {
   BYTE cmd[3];
   BYTE opid[3];
} LRT_CLF;                                    // Counting - list main exit
#define LRT_CLF_LTH sizeof(LRT_CLF)

// Version 5.0 Pre-Scan                                             5-5-4 PAB
                                                                 // 5-5-2004 PAB
                                                                 // 5-5-2004 PAB

// PAstraMI support - v3.0
/*
typedef struct {
   BYTE cmd[3];
   BYTE opid[3];
} LRT_PAS;                                    // PAstraMI signon request
#define LRT_PAS_LTH sizeof(LRT_PAS)

typedef struct {
   BYTE cmd[3];
   BYTE opid[3];
} LRT_PAX;                                    // PAstraMI signoff
#define LRT_PAX_LTH sizeof(LRT_PAX)

typedef struct {
    BYTE cmd[3];
    WORD recnum;
    WORD rectot;
    WORD reclth;
    BYTE debug[100];    // Variable length
} LRT_PDT;                                    // PAstraMI debug dump line
#define LRT_PDT_LTH sizeof(LRT_PDT)

typedef struct LRT_PDR_Txn {
   BYTE cmd[3];
} LRT_PDR;                                    // PAstraMI debug dump response
#define LRT_PDR_LTH sizeof(LRT_PDR)

*/

typedef struct {                                                                        //BMG 01-09-2008 13 ASN's
    BYTE abCmd[3];                                                                      //BMG 01-09-2008 13 ASN's
    BYTE abOpID[3];                                                                     //BMG 01-09-2008 13 ASN's
    BYTE abCarton[14];                                                                  //BMG 01-09-2008 13 ASN's
} LRT_ASA;                                                                              //BMG 01-09-2008 13 ASN's
#define LRT_ASA_LTH sizeof(LRT_ASA)                                                     //BMG 01-09-2008 13 ASN's

typedef struct LRT_ALR_Txn {                                                            //BMG 10-09-2008 14 MC70
    BYTE cmd[3];                                                                        //BMG 10-09-2008 14 MC70
    BYTE opid[3];                                                                       //BMG 10-09-2008 14 MC70
    BYTE application[8];                                                                //BMG 10-09-2008 14 MC70
} LRT_ALR;                                                                              //BMG 10-09-2008 14 MC70
#define LRT_ALR_LTH sizeof(LRT_ALR)                                                     //BMG 10-09-2008 14 MC70


// NOTE the Keys below are in INTEL format                                              // SDH 26-11-04 CREDIT CLAIM
// so reverse the key, OR use the macro below                                           // SDH 26-11-04 CREDIT CLAIM
#define CMD(a,b,c) ((LONG)c<<16) + ((LONG)b<<8) + (LONG)a                               // SDH 26-11-04 CREDIT CLAIM

// LRT Command Lookup (inbound commands)
#define CMD_NULL  0x00000000L        // 15-7-2004 to trap null commands PAB
#define CMD_ASA   CMD('A','S','A')                                                      //BMG 01-09-2008 13 ASN's
#define CMD_ALR   CMD('A','L','R')                                                      //BMG 10-09-2008 14 MC70
#define CMD_CLC   0x00434C43L
#define CMD_CLF   0x00464C43L
#define CMD_CLO   0x004F4C43L
#define CMD_CLR   0x00524C43L
#define CMD_CLS   0x00534C43L
#define CMD_CLX   0x00584C43L
#define CMD_DNQ   CMD('D','N','Q')                                                      // SDH 26-11-04 CREDIT CLAIM
#define CMD_DSS   CMD('D','S','S')                                                      // SDH 26-11-04 CREDIT CLAIM
#define CMD_DSG   CMD('D','S','G')                                                      // SDH 26-11-04 CREDIT CLAIM
#define CMD_ENQ   0x00514E45L
#define CMD_GAP   0x00504147L
#define CMD_GAS   0x00534147L
#define CMD_GAX   0x00584147L
#define CMD_INS   0x00534E49L
#define CMD_INX   0x00584E49L
#define CMD_ISE   0x00455349L
#define CMD_MSA   CMD('M','S','A')                                          //BMG 12-Aug-2008 Multi-Sited Counts
#define CMD_MSB   CMD('M','S','B')                                          //BMG 12-Aug-2008 Multi-Sited Counts
#define CMD_OFF   0x0046464FL
#define CMD_PAL   0x004C4150L
#define CMD_PAR   0x00524150L
#define CMD_PAS   0x00534150L
#define CMD_PAX   0x00584150L
#define CMD_PCD   0x00444350L
#define CMD_PCM   0x004D4350L
#define CMD_PCS   0x00534350L
#define CMD_PCX   0x00584350L
#define CMD_PDT   0x00544450L
#define CMD_PGF   CMD('P','G','F')                                          //SDH 14-Sep-2006 Planners
#define CMD_PGG   CMD('P','G','G')                                          //SDH 14-Sep-2006 Planners
#define CMD_PGI   CMD('P','G','I')                                          //SDH 14-Sep-2006 Planners
#define CMD_PGL   CMD('P','G','L')                                          //SDH 14-Sep-2006 Planners
#define CMD_PGM   CMD('P','G','M')                                          //SDH 14-Sep-2006 Planners
#define CMD_PGN   CMD('P','G','N')                                          //SDH 14-Sep-2006 Planners
#define CMD_PGQ   CMD('P','G','Q')                                          //SDH 14-Sep-2006 Planners
#define CMD_PGR   CMD('P','G','R')                                          //SDH 14-Sep-2006 Planners
#define CMD_PGS   CMD('P','G','S')                                          //SDH 14-Sep-2006 Planners
#define CMD_PGX   CMD('P','G','X')                                          //SDH 14-Sep-2006 Planners
#define CMD_PLC   0x00434C50L
#define CMD_PLF   0x00464C50L
#define CMD_PLO   0x004F4C50L
#define CMD_PLR   0x00524C50L
#define CMD_PLS   0x00534C50L
#define CMD_PLU   0x00554C50L
#define CMD_PLX   0x00584C50L
#define CMD_PPL   CMD('P','P','L')                                          //SDH 14-Sep-2006 Planners
#define CMD_PPR   CMD('P','P','R')                                          //SDH 14-Sep-2006 Planners
#define CMD_PRP   CMD('P','R','P')                                          //SDH 14-Sep-2006 Planners
#define CMD_PRT   0x00545250L
#define CMD_PSL   CMD('P','S','L')                                          //SDH 14-Sep-2006 Planners
#define CMD_PSR   CMD('P','S','R')                                          //SDH 14-Sep-2006 Planners
#define CMD_RCA   CMD('R','C','A')                                         // PAB 22-map-2007 Recalls
#define CMD_RCB   CMD('R','C','B')                                         // PAB 22-map-2007 Recalls
#define CMD_RCC   CMD('R','C','C')                                         // PAB 22-map-2007 Recalls
#define CMD_RCD   CMD('R','C','D')                                         // PAB 22-map-2007 Recalls
#define CMD_RCE   CMD('R','C','E')                                         // PAB 22-map-2007 Recalls
#define CMD_RCF   CMD('R','C','F')                                         // PAB 22-map-2007 Recalls
#define CMD_RCG   CMD('R','C','G')                                         // PAB 22-map-2007 Recalls
#define CMD_RCH   CMD('R','C','H')                                         // PAB 22-map-2007 Recalls
#define CMD_RCI   CMD('R','C','I')                                         // PAB 22-map-2007 Recalls
#define CMD_RCJ   CMD('R','C','J')                                         // PAB 22-map-2007 Recalls
#define CMD_RLE   0x00454C52L
#define CMD_RLS   0x00534C52L
#define CMD_RPO   0x004F5052L
#define CMD_RPS   0x00535052L
#define CMD_RPX   0x00585052L
#define CMD_RSP   0x00505352L
#define CMD_SAK   0x0053414BL       // PAB 5-5-4 Pre-Scan 
#define CMD_SIE   0x00454953L
#define CMD_SIR   0x00534953L
#define CMD_SOR   0x00524F53L
#define CMD_SUS   0x00535553L       // PAB 5-5-4 Pre-Scan
#define CMD_SSE   0x00455353L
#define CMD_STQ   CMD('S','T','Q')                                                      // SDH 26-11-04 CREDIT CLAIM
#define CMD_UIS   CMD('U','I','S')                                                      // SDH 26-11-04 CREDIT CLAIM
#define CMD_UIG   CMD('U','I','G')                                                      // SDH 26-11-04 CREDIT CLAIM
#define CMD_UOA   CMD('U','O','A')                                                      // SDH 26-11-04 CREDIT CLAIM
#define CMD_UOD   CMD('U','O','D')                                                      // SDH 26-11-04 CREDIT CLAIM
#define CMD_UOQ   CMD('U','O','Q')                                                      // SDH 26-11-04 CREDIT CLAIM
#define CMD_UOS   CMD('U','O','S')                                                      // SDH 26-11-04 CREDIT CLAIM
#define CMD_UOX   CMD('U','O','X')                                                      // SDH 26-11-04 CREDIT CLAIM
#define CMD_UNK   0x00FFFFFFL
#define CMD_WRF   CMD('W','R','F')                                                      // BMG 03-Jan-2008 10
#define CMD_XXX   0x00585858L       // Low-level handheld transactions - keep alive

//DEALSUM - Used by EQR and ENQUIRY
typedef struct {
    BYTE abNum[4];
    BYTE abQualMsgNum[2];
} DEALSUM;

typedef struct {
    BYTE boots_code[7];         // IRF
    BYTE parent_code[7];        // IDF
    BYTE item_desc[24];         // IDF
    BYTE item_price[6];         // IRF
    BYTE sel_desc[45];          // ISF
    BYTE status[1];             // IDF                            
    BYTE stock_figure[6];       // VARIOUS                             v2.1
    BYTE supply_method[1];      // IDF
    BYTE redeemable[1];         // IRF
    //BYTE deal_num[4];         // IRF                                 v3.0
    BYTE active_deal_flag[1];   // IRF                                 v3.0
    BYTE item_code[13];         // IRF (incl. calculated check digit)  v2.1
    BYTE items_sold_today[6];   // IMSTC (singles, not 1/100ths)       v2.1
    UBYTE idf_bit_flags_2;      // IDF                                 v2.1
    BYTE pcheck_exempt[1];      // PGF YN //PAB 23-10-03
    BYTE date_last_delivery[3]; // STOCK  //PAB 20-10-04
    BYTE cBusCentre;            // IDF    //SDH 17-11-04 OSSR WAN
    BYTE cOssrItem;             // RFHIST/PGF 'Y' or 'N'                    //SDH 17-11-04 OSSR WAN
    BYTE cPgfOssrFlag;          // PGF 'Y' or 'N'                           //SDH 18-03-05 OSSR WAN
    DEALSUM Deal[10];           // Internal deal table                      //SDH 17-11-04 OSSR WAN
    BYTE abCoreCount[3];        // From SRITML                              //SDH 22-Sep-2006 Planners
    BYTE abNonCoreCount[3];     // From SRITML                              //SDH 22-Sep-2006 Planners
    BYTE cRecallFlag[1];        // From IRF                                 //PAB 22-May-2007 Recalls
    BYTE cMarkdown[1];          // From IDF 'Y' or ' '                      //BMG 06-02-2008 1.11
} ENQUIRY;                      // General enquiry block
#define ENQUIRY_LTH sizeof(ENQUIRY)

// Global Return Code Stuff
typedef WORD URC;
#define RC_FATAL_ERR     (-128)  // Serious error - Application must end
#define RC_SERIOUS_ERR   (-100)  // Serious error - Application can continue
#define RC_FILE_ERR       (-40)  // File(s) missing at point of access
#define RC_DATA_ERR       (-30)  // General file error - see appl event logs
#define RC_IGNORE_ERR      (-1)  // Error can be ignored - see appl event logs
#define RC_OK               (0)  // Success

// LRT Application States
#define ST_FREE         0                       // Must be zero
#define ST_LOGGED_ON    1
#define ST_RECEIVING    2
#define ST_CLOSING      3
#define ST_STACKED      4

// Process queue states
#define PST_FREE        0
#define PST_ALLOC       1
#define PST_READY       2
#define PST_ADOPTED     3   //SDH 22-June-2006
#define PST_RUNNING     4   //PAB 26-January-2007
#define PST_STALLED     5   // 11-09-2007 9 BMG

// File close flags
#define CL_SESSION      0
#define CL_ALL          1

// Access conflict parms
#define AC_RETRY_DELAY  10
#define AC_MAX_RETRY    12

// gap system flag settings
#define SYS_LAB         0
#define SYS_GAP         1
#define SYS_ORPHAN      2

// audit file (LRTLG) record types
#define LOG_SOR         0
#define LOG_OFF         1
#define LOG_GAS         2
#define LOG_PCM         3
#define LOG_GAX         4
#define LOG_PLX         5
#define LOG_PCS         6
#define LOG_PCX         7
#define LOG_PRT         8
#define LOG_CSS         9   // <v4.0
#define LOG_CSE        10   // <v4.0
#define LOG_TVR        11   // <v4.0
#define LOG_CRQ        12   // <v4.0
#define LOG_CLS        13   // v4.0
#define LOG_CLC        14   // v4.0
#define LOG_CLX        15   // v4.0
#define LOG_SUS        16   // 5-5-04 PAB
#define LOG_ENQ        17   // 2-7-04 PAB
#define LOG_UOS        18
#define LOG_UOA        19
#define LOG_UOX        20
#define LOG_UOQ        21
#define LOG_DSS        22
#define LOG_DSG        23
#define LOG_STQ        24
#define LOG_DNQ        25
#define LOG_PGS        26
#define LOG_PGX        27
#define LOG_PGF        28
#define LOG_PGQ        29
#define LOG_PGM        30
#define LOG_PPL        31
#define LOG_PSL        32
#define LOG_PGL        33
#define LOG_PRP        34
#define LOG_RCA        35  // 22-5-07 PAB Recalls
#define LOG_RCB        36  // 22-5-07 PAB Recalls
//#define LOG_RCC        37  // 22-5-07 PAB Recalls
#define LOG_RCD        38  // 22-5-07 PAB Recalls
//#define LOG_RCE        39  // 22-5-07 PAB Recalls
//#define LOG_RCF        40  // 22-5-07 PAB Recalls
//#define LOG_RCG        41  // 22-5-07 PAB Recalls
#define LOG_RCH        42  // 22-5-07 PAB Recalls
#define LOG_RCI        43  // 22-5-07 PAB Recalls
#define LOG RCJ        44  // 22-5-07 PAB Recalls
#define LOG_WRF        45  // BMG 03-Jan-2008 10
#define LOG_MSA        46  // BMG 12-Aug-2008 Multi-Sited Counts
#define LOG_MSB        47  // BMG 12-Aug-2008 Multi-Sited Counts

// Stock enquiry types
#define SENQ_BOOTS      0
#define SENQ_DESC       1
#define SENQ_SELD       2
#define SENQ_TSF        3

//////////////////////////////////////////////////////////////////////////////
/// Define log levels.
/// LOG_CRITICAL means log all errors except record not found or EOF
//////////////////////////////////////////////////////////////////////////////
#define LOG_NONE     0
#define LOG_CRITICAL 1
#define LOG_ALL      2

#endif /* RFS_H not defined */
// recall file globals


