#include "transact.h"

#include "trxfile.h"
#include "irf.h"

FILE_CTRL irf;
FILE_CTRL irfdex;
IRF_REC irfrec;
IRFDEX_REC irfdexrec;

void IrfSet(void) {
    irf.sessions   = 0;
    irf.fnum       = -1L;
    irf.pbFileName = "IRF";
    irf.wOpenFlags = 0x2018;
    irf.wReportNum = 7;
    irf.wRecLth    = 50L;
    irf.wKeyLth    = 11;
    irf.pBuffer    = &irfrec;
}

URC IrfOpen(void) {
    return keyed_open(&irf, TRUE);
}

URC IrfClose(WORD type) {
    return close_file(type, &irf);
}

LONG IrfRead(LONG lLineNum) {
    return ReadKeyed(&irf, lLineNum, LOG_CRITICAL);
}

void IrfdexSet(void) {
    irfdex.sessions   = 0;
    irfdex.fnum       = -1L;
    irfdex.pbFileName = "IRFDEX";
    irfdex.wOpenFlags = 0x2018;
    irfdex.wReportNum = 673;
    irfdex.wRecLth    = 17L;
    irfdex.wKeyLth    = 3;
    irfdex.pBuffer    = &irfdexrec;
}

URC IrfdexOpen(void) {
    return keyed_open(&irfdex, TRUE);
}

URC IrfdexClose(WORD type) {
    return close_file(type, &irfdex);
}

LONG IrfdexRead(LONG lLineNum) {
    return ReadKeyed(&irfdex, lLineNum, LOG_ALL);
}

