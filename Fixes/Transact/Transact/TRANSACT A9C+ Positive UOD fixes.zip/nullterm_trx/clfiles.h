#ifndef CLFILES_H
#define CLFILES_H

#include "trxfile.h"


//  record layout
typedef struct CLOLF_Record_Layout {
    BYTE list_id[3];                                                        // ASCII
    BYTE total_items[3];                                                    // ASCII
    BYTE items_shopfloor[3];                                                // ASCII
    BYTE items_backshop[3];                                                 // ASCII
    BYTE list_type[1];                                                      // ASCII - [H]ead office, [R]ectification proc, [N] Negative
    BYTE bus_unit[1];                                                       // ASCII
    BYTE bus_unit_name[15];                                                 // ASCII
    BYTE list_status[1];                                                    // ASCII - [A]ctive, [C]omplete, [ ]Initial
    BYTE head_off_list_id[4];                                               // ASCII
    BYTE cnt_date[8];                                                       // ASCII - Format YYYYMMDD
    BYTE ossr_store;                                                        // marked for OSSR counting Y/N
    BYTE items_ossr[3];                                                     // ASCII
    BYTE abUserID[3];                                                       // ASCII  SDH 11-01-2005 OSSR WAN
} CLOLF_REC;

//  record layout
typedef struct CLILF_Record_Layout {
    BYTE list_id[3];                                                        // ASCII
    BYTE seq[3];                                                            // ASCII
    BYTE boots_code[7];                                                     // ASCII - Format BBBBBBC (C=check digit)
    BYTE item_code[13];                                                     // ASCII
    BYTE sel_desc[45];                                                      // ASCII 3 x 15 charaters
    BYTE active_deal_flag[1];                                               // ASCII [Y]es, [N]o
    BYTE product_group[6];                                                  // ASCII (should be 6)
    BYTE product_group_desc[12];                                            // ASCII
    //The 3 counts                                                          // SDH 10-01-2005
    BYTE count_backshop[4];                                                 // ASCII
    BYTE count_shopfloor[4];                                                // ASCII
    BYTE abOSSRCount[4];                                                    // SDH 10-01-2005
    //The 3 sales figures at the time of counts                             // SDH 10-01-2005
    BYTE sales[4];                                                          // ASCII
    BYTE abAtStockSales[4];                                                 // SDH 10-01-2005
    BYTE abAtOSSRSales[4];                                                  // SDH 10-01-2005
    //Some random field                                                     // SDH 10-01-2005
    BYTE ho_seq_no[2];                                                      // ASCII
    //The three times of counts                                             // SDH 10-01-2005
    BYTE abTimeSalesCntPD[2];                                               // SDH 10-01-2005
    BYTE abTimeStockCntPD[2];                                               // SDH 10-01-2005
    BYTE abTimeOSSRCntPD[2];                                                // SDH 10-01-2005
    BYTE abFiller[3];                                                       // SDH 10-01-2005
} CLILF_REC;                                                                // SDH 10-01-2005

extern FILE_CTRL clolf;
extern FILE_CTRL clilf;
extern CLOLF_REC clolfrec;
extern CLILF_REC clilfrec;

void ClolfSet(void);
URC ClolfOpen(void);
URC ClolfClose(WORD type);
LONG ClolfRead(LONG lRecNum, LONG lLineNum);
LONG ClolfWrite(LONG lRecNum, LONG lLineNum);

void ClilfSet(void);
URC ClilfOpen(void);
URC ClilfClose(WORD type);
LONG ClilfRead(LONG lLineNum);
LONG ClilfReadLock(LONG lLineNum);
LONG ClilfWriteUnlock(LONG lLineNum);

#endif

