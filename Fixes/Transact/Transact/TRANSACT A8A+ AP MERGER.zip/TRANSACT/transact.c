// ------------------------------------------------------------------------
//                     Boots The Chemists Store Systems
//                  Radio Frequency Transaction Processor
// 
// Version 1.0          Steve Wright / Paul Bowers    1994,1995,1996,1997
//
//             Initial Release. 
//
// Version 2.0               Paul Bowers                    28 August 1998
//             Fix Sales Enquiry Bar Code to Boots Bar Code Conversion
//             In ISE request. Debug for pilot
//
// Version 2.1               Paul Bowers                1st September 1998
//             Include the RFSCF control file in all transactions, record
//             price check activity and quota management processing
//
// Version 2.2               Paul Bowers                24th September 1998
//             Move the file open & close for the PSBt and EALTerms and
//             WORKG files from INformation Sign on / Exit to Store Sales
//             request only. These files are only used by this txn, and
//             normally requested at store close, which is also attempting
//             to rename these files for backup. if the HHT is left in any
//             information screen (inc menu) these files are left open 
//             which results in psb52 abending with access conflict.
//             in order to minimise this window of opportunity the files
//             are opened / closed as quick as possible. Timings show
//             this to have no noticable affect on the performance of this
//             transaction.
// Version 2.3               Steve Wright/Paul Bowers      30th October 1998
//    Phase II enhancements
//    Prevent data being sent when dummy (XXX) transaction is transmitted
//    by the sockets server.
//    Add time stamps to message rx/tx debug.
//    Add extra details to PLI record
//    Add extra details to PLE record
//    Remove processing of RFSCF activity flag
//    Add general prep_nak() function to prepare NAK replies (and convert
//    all existing NAK replies) - to simplify code
//    Add extra details to EQR
//    Add Gregorian/Julian date conversion routines
//    Assertions for handling two digit dates:
//        1) Any two digit dates from other files/systems are converted and
//        held internally as four digit dates. The conversion is done by
//        windowing the date such that YY>=85 = 19YY, YY<85 = 20YY.
//        2) When four digit dates have to be written to other files/systems
//        as two digit dates they will be written as YYYY modulo 100 (thus
//        converting YYyy to yy.)
// Version 3.0               Steve Wright                  30th July 2001
//             Phase III enhancements (Symbol Spectrum 24 - DS Spread)
//             Project Envoy - Symbol 1746 / 19xx (Palm OS)
//             Support new PAL/PAR transaction pair - lookup URL info.
// Version 3.2               Steve Wright              30th November 2001
//     Fix PLX transaction. Make list status ' ' if list is exited but
//     not completed.
//     Fix CLI record - parent_code missing
//             
// Version 4.0               Steve Wright/Paul Bowers       28th August 2003
//     2003 Trial
//     Update to cope with new deal system
//
// Version 4.0               Paul Bowers                 26th September 2003
//    Various fixes for 2003 trial
//
// Version 4.02
//    RF Trial Phase 2       Paul Bowers                18th February 2004
//    Changes to introduce proximity printing
//    change to SNR and PRT transactions.
//    Introduce the PRTCTL file
//
// Version 4.03
//    Break fix for dissacociate dfile session numbers
//    Introduce the dynamic session number tracking table.
//                           Paul Bowers                6th April 2004
// Version 5.00 
//     Introducte functionality for Pre-Scan
//                           Paul Bowers                5th May 2004
//
// Version 6.00              Paul Bowers                5th July 2004
// MyStoreNet Changes to ENQ / ISE and introduce SIE/SIR and blind sign on
// support.
//
// Version 7.00              Paul Bowers                31st August 2004
// Offsite Stock Room Support (OSSR)
// extend the length of the CLILF / PLLOL add new fields to PLLDB RFSCF
//
// Version 8.00              Paul Bowers                 20th October 2004
// Fix TSF update logic in PLC transaction to include date of last
// delivery and return a message to the PPC if the product has been
// delivered in the last INVOK.RP.DAYS days.
//
// Version 9.0               Stuart Highley              26th January 2005
// - Added OSSR WAN functionality.
// - Added Promotions functionality.
// - Added Credit Claiming functionality.
// - Removed incorrect handling of lrt_log return codes.
// - Update 'date of last gap' field of RFHIST if a shelf monitor gap
//   comes through.
// - Reduced stack usage of process() by removing local record structures.
//   This can no doubt be inproved further.
// - Used request structure pointers to improve readability.
// - UPWARDS TSF: Always allow the PLC to adjust a +ve item TSF if the
//   adjustment is also +ve.
//
// Version 10               Paul Bowers                27th November 2006
// - Planners to store changes in A7A
//
// Version 11               Paul Bowrts                23rd May 2007
// - Electronic Recalls A7C
//
// Version 12               Brian Greenfield           11th September 2007
// Unstall printer queue every 15 minutes - new function call to 
// unstall_sel_stack().
// Added call to DealEnquiry and moved code to trans03.c because we 
// blew 64K limit.
//
// Version 13               Brian Greenfield           2nd November 2007
// Minor correction for price check counts - now tests for no date in 
// RFHIST record for new lines that have no previous count date.
//
// Version 14               Brian Greenfield           3rd January 2008
// Added WriteToFile call for WRF command.
//
// -----------------------------------------------------------------------

#include "transact.h" //SDH 19-May-2006

/* include files */

#include <string.h>
#include <math.h>
#include "adxsrvfn.h"           /* needed for disp_msg() */
#include "c4680if.h"            // 19-11-2004 SDH
#include "rfs.h"  
#include "rfsfile.h"
#include "wrap.h"
#include "rfglobal.h"           // v4.01
#include "debug.h"              // v4.01
#include "trxpog.h"
#include <time.h>               //11-09-2007 12 BMG

//////////////////////////////////////////////////////////////////////////
///                                                                     //
///   Static (private) variables                                        //
///                                                                     //
//////////////////////////////////////////////////////////////////////////

//static BYTE *look_xxx = {"TRANSACT"};


// process - reply to an inbound transaction
//
// INPUT:
// inbound = transaction request
// nbytes  = length of request
//
// OUTPUT:
// inbound = transaction response
// nbytes  = length of response
//
int process(char *inbound, int *nbytes) {

    static BOOLEAN count_accepted, count_pending, check_accepted;
    static WORD hour, min, rec_cnt;
    static ENQUIRY enqbuf;
    static IMSTC_REC imstcrec;
    static CLOLF_REC clolfrec;                                              // PAB 18-02-04
    static CLILF_REC clilfrec;                                              // PAb 18-02-04
    static PRTCTL_REC prtctlrec;                                            // PAB 18-02-04 4.02
    static PRTLIST_REC prtlistrec;                                          // PAB 17-05-04
    static SUSPT_REC susptrec;                                              // PAB 5-5-04
    static BYTE gapbfrec[32];                                               // PAB 20-02-04 PAB
    static LONG lcmd, list_id, sec, day, month, year,
    new_count, sales_figure, variance, 
    items_sold_today, mismatch_qty, mismatch_val;
    static BYTE tbuf[32], authority[1], username[32], stkmqrec[128],        // 21-10-04 PAB
    sbuf[64], ts[32], item_code[13], txtbuf[256];                           // 20-02-04 PAB
    static TIMEDATE now;
    time_t CurrTime;                                                        //11-09-2007 12 BMG

    static const BYTE dayname[7][4] = { "Sun","Mon","Tue","Wed","Thu","Fri","Sat"};    // 12-11-04 PAB

    static WORD cnt = 0;
    int rc = 0;

    WORD i = 0;
    LONG *cmd;
    LONG rc2 = 0;
    //LONG lne = 0;
    URC usrrc = RC_OK;

    memset( (BYTE *)&enqbuf,    0x00, sizeof(ENQUIRY)    );
    memset( (BYTE *)&selbfrec,  0x00, sizeof(SELBF_REC)  );
    memset( (BYTE *)&pllolrec,  0x00, sizeof(PLLOL_REC)  );
    memset( (BYTE *)&plldbrec,  0x00, sizeof(PLLDB_REC)  );
    memset( (BYTE *)&imstcrec,  0x00, sizeof(IMSTC_REC)  );
    memset( (BYTE *)&rfhistrec, 0x00, sizeof(RFHIST_REC) );
    memset( (BYTE *)&clolfrec,  0x00, sizeof(CLOLF_REC)  );                 // PAB
    memset( (BYTE *)&clilfrec,  0x00, sizeof(CLILF_REC)  );                 // PAB
    memset( (BYTE *)&prtctlrec, 0x00, sizeof(PRTCTL_REC) );                 // PAB 18-02-04
    memset( (BYTE *)&prtlistrec,0x00, sizeof(PRTLIST_REC));                 // PAB 17-05-04
    memset( (BYTE *)&susptrec,  0x00, sizeof(SUSPT_REC)  );                 // PAB 5-5-04
    memset( (BYTE *)&jobokrec,  0x00, sizeof(JOBOK_REC)  );                 // PAB 13-12-04
    //xx memset( (BYTE *)&rfscfrec1,  0x00, sizeof(RFSCF_REC)  );

    hh_unit = (UWORD)CurrentHHT;
    if (lrtp[hh_unit] != NULL) {                                            //11-09-2007 12 BMG
       time(&CurrTime);                                                     //11-09-2007 12 BMG
       pq[lrtp[hh_unit]->pq_sub1].last_access_time = CurrTime;              //11-09-2007 12 BMG
    }

    // Clear output buffer
    memset( out, 0x20, 2048 );
    out_lth = 0;

    // Get a pointer to the command string
    cmd = (LONG *)inbound;
    lcmd = (*cmd) & 0x00FFFFFFL;

    //Dump any received command to the trace file/console
    if (debug && (lcmd != CMD_XXX)) {
        form_timestamp( ts, sizeof(ts) );
        sprintf(msg, "hh_unit = %d", hh_unit);
        disp_msg(msg);
        sprintf(msg, "RX (%s) ", ts);
        disp_msg(msg);
        dump((BYTE *)inbound, 144);                                         //TODO (back to 48)
    }

    // Log shared tracking info
    if ((lcmd != CMD_SOR) && (lcmd != CMD_XXX)) {
        if (lrtp[hh_unit]!=NULL) {
            if (lrtp[hh_unit]->state != ST_FREE) {
                // Log current time
                s_get( T_TD, 0L, (void *)&now, TIMESIZE );
                lrtp[hh_unit]->last_active_time = now.td_time;
                memcpy( (BYTE *)&(lrtp[hh_unit]->txn), (BYTE *)cmd, 3 );
                memset( (BYTE *)&(lrtp[hh_unit]->unique), 0x00, 5 );
            }
        }
    }


    //Do idle stuff: called every n seconds                                 //SDH 9-May-2006
    if (lcmd == CMD_XXX) {                                                  //SDH 9-May-2006

        //Call a non-destructive process orphans                            //SDH 9-May-2006
        //I don't dare do it!!!
        //process_orphans(FALSE);                                             //SDH 9-May-2006
        //We have decided to do this every 15 mins within unstall_sel_stack //11-09-2007 12 BMG
    }                                                                       //SDH 9-May-2006

    // to prevent Priv Except potential
    // from null / corrupt CMDS being
    // received.
    if (lcmd != CMD_NULL) {                                                 // 15-7-2004 PAB 


        switch (lcmd) {

        //-------------------------------------------------------------------------
        case CMD_SOR:                                                       // Master sign on request
            {
                //Working variables                                         // 07-12-04 SDH
                WORD wAppID;                                                // 07-12-04 SDH

                //Setup views                                               // 07-12-04 SDH
                LRT_SOR* pSOR = (LRT_SOR*)inbound;                          // 07-12-04 SDH

                if (IsStoreClosed()) break;                                 // 07-12-04 SDH

                // always ensure the PGF is closed this file is opened on demand in the
                // ENQ function, and always closed, but only is the item update suite is not
                // active. As PSB20 suite does not issue a liCLS to TRANSACT then if a user
                // does attempt to sign on during the night then we should always do our
                // best to make sure that the PSB20/ or PSB26 run does not fail cos of us !
                close_pgf( CL_ALL );                                        // PAB 13-12-04

                // verify that batch suite is not running
                // functionalised the RFOK file open / read / close         // 04-11-04 PAB
                usrrc = process_rfok();                                     // 04-11-04 PAB
                if (usrrc<=RC_DATA_ERR) {                                   // 24-08-04 PAB
                    prep_nak("ERRORUnable to open RFOK file. "              // SDH 23-Aug-2006 Planners
                             "Check appl event logs" );                     // 24-08-04 PAB
                    break;                                                  // 24-08-04 PAB
                }          
                                                                 
                // verify that recallsbatch suite is not running
                // functionalised the RECOK file open / read / close        // 24-05-07 PAB Recalls
                usrrc = process_recok();                                    // 24-05-07 PAB Recalls
                if (usrrc!=RC_OK) {                                         // 24-05-07 PAB Recalls
                    break;                                                  // 24-05-07 PAB Recalls
                }          

                //Convert the application ID to an int                      // 07-12-04 SDH
                wAppID = satoi(pSOR->abAppID, sizeof(pSOR->abAppID));       // 07-12-04 SDH

                //Shelf Management                                          // 07-12-04 SDH
                // RFMAINT will be blocked at report browser level to allow // 04-11-04 PAB
                // the rest of the application to be used                   // 04-11-04 PAB
                if ((wAppID == 0) || (wAppID == 1)) {                       // 24-08-04 PAB
                    if ((rfokrec.rfaudit == 'S') ||                         // 24-08-04 PAB
                        (rfokrec.rfpikmnt == 'S')) {                        // 24-08-04 PAB
                        prep_nak("File Maintenance in progress please try " //SDH 23-Aug-2006 Planners
                                 "again in 10 minutes" );                   // 24-08-04 PAB
                        break;                                              // 24-08-04 PAB
                    }                                                       // 07-12-04 SDH

                //Credit Claim / UOD                                        // 07-12-04 SDH
                } else if (wAppID == 2) {                                   // 07-12-04 SDH
                    if (rfokrec.rfccmnt == 'S') {                           // 07-12-04 SDH
                        prep_nak("File Maintenance in progress please try " //SDH 23-Aug-2006 Planners
                                  "again in 10 minutes" );                  // 24-08-04 PAB
                        break;                                              // 24-08-04 PAB
                    }                                                       // 07-12-04 SDH
                }                                                           // 07-12-04 SDH

               
                // Allocate handheld a table entry
                disp_msg("Allocate lrt table...");
                usrrc = alloc_lrt_table( hh_unit );
                if (usrrc<RC_IGNORE_ERR) {
                    prep_nak("ERROR unable to allocate storage. "           //SDH 23-Aug-2006 Planners
                              "Check appl event logs " );
                    break;
                }

                // Log current time
                if (debug) disp_msg("Log current time...");
                s_get( T_TD, 0L, (void *)&now, TIMESIZE );
                lrtp[hh_unit]->last_active_time = now.td_time;
                memcpy( (BYTE *)&(lrtp[hh_unit]->txn), (BYTE *)cmd, 3 );
                memset( (BYTE *)&(lrtp[hh_unit]->unique), 0x00, 5 );

                // Set state
                lrtp[hh_unit]->state = ST_LOGGED_ON;

                // Reset misc counts (Unused at present)
                lrtp[hh_unit]->count1 = 0;
                lrtp[hh_unit]->count2 = 0;

                ///////////////////////////////////////////////////////////////////////
                // Get RF attributes from control file                               //
                ///////////////////////////////////////////////////////////////////////

                disp_msg("Read RFSCF...");

                //Open RFSCF
                usrrc = open_rfscf();
                if (usrrc!=RC_OK) {
                    prep_nak("ERROR unable to open RFSCF file. "            //SDH 23-Aug-2006 Planners
                              "Please phone help desk." );
                    break;
                }

                disp_msg("SOR read rfscf");

                //Read RFSCF record 1 and 2
                rc2 = s_read( A_BOFOFF, rfscf.fnum,
                              (void *)&rfscfrec1and2, RFSCF_RECL, 0L );     // 16-11-04 SDH

                //Read RFSCF record 3                                       // 16-11-04 SDH
                if (rc2 > 0L) {                                             // 16-11-04 SDH
                    rc2 = s_read( A_BOFOFF, rfscf.fnum, (void *)&rfscfrec3, // 16-11-04 SDH
                                  RFSCF_RECL, RFSCF_RECL * 2 );             // 16-11-04 SDH
                }                                                           // 16-11-04 SDH

                //Handle bad read return codes
                if (rc2<=0L) {
                    log_event101(rc2, RFSCF_REP, __LINE__);
                    //sprintf(msg, "Err-R RFSCF. RC:%08lX", rc2);
                    //disp_msg(msg);
                }


                // Check POG status here after reading is POGs are active from the RFSCF.
                if (rfscfrec1and2.cPlannersActive == 'Y') {                    //PAB 27-Nov-2006
                   //Open, read, close POGOK                                   //SDH 23-Aug-2006 Planners
                   usrrc = open_pogok();                                       //SDH 23-Aug-2006 Planners
                   if (usrrc < RC_OK) {                                        //SDH 23-Aug-2006 Planners
                       prep_nak("ERRORUnable to open POGOK file. "             //SDH 23-Aug-2006 Planners
                                "Please phone help desk.");                    //SDH 23-Aug-2006 Planners
                       break;                                                  //SDH 23-Aug-2006 Planners
                   }                                                           //SDH 23-Aug-2006 Planners
                   rc2 = ReadPogok(0, __LINE__);                               //SDH 23-Aug-2006 Planners
                   close_pogok(CL_SESSION);                                    //SDH 23-Aug-2006 Planners
                   if (rc2 > 0) {                                              //SDH 23-Aug-2006 Planners
                       if (pogokrec.cSRP04 == 'S' ||                           //SDH 23-Aug-2006 Planners
                           pogokrec.cSRP05 == 'S' ||                           //SDH 23-Aug-2006 Planners
                           pogokrec.cSRP06 == 'S' ||                           //SDH 23-Aug-2006 Planners
                           pogokrec.cSRP07 == 'S' ||                           //SDH 23-Aug-2006 Planners
                           pogokrec.cSRP10 == 'S' ) {                         //PAB 21-Sept-2006 Planners
                           //pogokrec.cSRP19 == 'S') {                           //SDH 23-Aug-2006 Planners
                           prep_nak("Planner maintenance in progress. "        //SDH 23-Aug-2006 Planners
                                    "Please try again in 10 minutes" );        //SDH 23-Aug-2006 Planners
                           break;                                              //SDH 23-Aug-2006 Planners
                       }                                                       //SDH 23-Aug-2006 Planners
                   }                                                           //SDH
                }                                                              //PSB 27-Nov-2006

                //If Credit Claiming is active then lock the CCDMY to       // 16-11-04 SDH
                //prevent PDTs from using Credit Claiming                   // 16-11-04 SDH
                //Only call the open routine so that the number of          // 16-11-04 SDH
                //sessions is not continuously incremented                  // 16-11-04 SDH
                if (rfscfrec3.bCCActive == 'Y') {                           // 16-11-04 SDH
                    open_ccdmy_locked();                                    // 16-11-04 SDH
                } else {                                                    // 16-11-04 SDH
                    close_ccdmy();                                          // 16-11-04 SDH
                }                                                           // 16-11-04 SDH

                // Get SEL printer status                                   // 18-02-04 PAB 
                disp_msg("SOR get printer status");                         // 17-05-04 PAB
                write_gap = satol(rfscfrec1and2.phase,1);                   // 16-11-04 SDH
                //lne = 0;                                                  // 18-05-04 PAB
                
                //This code was previously only executed if the gap         // SDH 04-05-06  A6C: Bug fix
                //config was 4 or more.  No longer needed.                  // SDH 04-05-06  A6C: Bug fix
                //One IF statement removed.                                 // SDH 04-05-06  A6C: Bug fix
                usrrc = open_prtctl();                                      // 18-02-04 PAB
                if (usrrc<=RC_DATA_ERR) {                                   // 18-02-04 PAB
                    prep_nak("ERRORUnable to open PRTCTL file. "            //SDH 23-Aug-2006 Planners
                              "Check appl event logs" );                    // 18-02-04 PAB
                    break;                                                  // 18-02-04 PAB
                }                                                           // 18-02-04 PAB
                // read the current status recdord & close the file         // 18-02-04 PAB
                rc = s_read( A_BOFOFF, prtctl.fnum,                         // 18-02-04 PAB
                             (void *)&prtctlrec, PRTCTL_RECL, 0L);          // 18-02-04 PAB
                close_prtctl ( CL_SESSION );                                // 18-02-04 PAB
                if (rc<=0L) {                                               // 18-02-04 PAB
                    log_event101(rc, PRTCTL_REP, __LINE__);                 // 18-02-04 PAB
                    printf("ERR-R PRTCTL. RC:%081X", rc);                   // 18-02-04 PAB
                }                                                           // 18-02-04 PAB 

                usrrc = open_prtlist();                                     // 17-05-04 PAB
                if (usrrc<=RC_DATA_ERR) {                                   // 17-05-04 PAB
                    prep_nak("ERRORUnable to open PRTLIST file. "           //SDH 23-Aug-2006 Planners
                              "Check appl event logs" );                    // 17-05-04 PAB
                    break;                                                  // 17-05-04 PAB
                }                                                           // 17-05-04 PAB
                // 17-05-04 PAB
                memset( (BYTE *)&prtlistrec, 0x00, sizeof(PRTLIST_REC) );   // 17-05-04 PAB
                //memset( txtbuf, 0x00, 256);                               // 17-05-04 PAB
                                                                            // 17-05-04 PAB
                rc = s_read( A_BOFOFF, prtlist.fnum,                        // 17-05-04 PAB
                             (void *)&prtlistrec, PRTLIST_RECL, 0L);        // 17-05-04 PAB

                memcpy(((LRT_SNR*)&out)->snrprtdesc,                        //SDH 10-May-2006
                       (BYTE*)&prtlistrec, 200);                            //SDH 10-May-2006
                close_prtlist ( CL_SESSION );                               // 17-05-04 PAB

                // Authorise user
                usrrc = open_af();
                if (usrrc<=RC_DATA_ERR) {
                    prep_nak("ERRORUnable to open EALAUTH file. "           //SDH 23-Aug-2006 Planners
                              "Check appl event logs" );
                    break;
                }
                usrrc = authorise_user( ((LRT_SOR *)(inbound))->opid,
                                        ((LRT_SOR *)(inbound))->pass,
                                        (BYTE *)&authority,
                                        (BYTE *)&username );
                close_af( CL_SESSION );
                if (usrrc<RC_IGNORE_ERR) {
                    prep_nak("ERRORUser authorisation failed. "             //SDH 23-Aug-2006 Planners
                              "Check appl event logs" );
                    break;
                }

                if (usrrc == RC_OK) {

                    // User authorised
                    // Save user ID & name
                    memcpy(lrtp[hh_unit]->user, ((LRT_SOR *)(inbound))->opid, 3 );
                    memcpy(lrtp[hh_unit]->abOpName, username,               // 16-11-2004 SDH
                           sizeof(lrtp[hh_unit]->abOpName));                // 16-11-2004 SDH

                    // Prepare SNR                                          // 16-11-2004 SDH
                    buildSNR((LRT_SNR *)&out, prtctlrec.prtnum,             // 16-11-2004 SDH
                             ((LRT_SOR *)(inbound))->opid, authority[0],    // 16-11-2004 SDH
                             username, rfscfrec1and2.ossr_store,            // 16-11-2004 SDH
                             rfscfrec1and2.cPlannersActive);                // 25-Sep-2006 SDH Planners

                    out_lth = LRT_SNR_LTH;                                  // 17-10-2006 SDH Bug fix
                    //authorised = TRUE;                                    // 16-11-2004 SDH

                    // Audit                                                // 16-11-2004 SDH
                    ((LRTLG_SOR *)dtls)->authority[0] = 'Y';                // 16-11-2004 SDH
                    memset( ((LRTLG_SOR *)dtls)->resv, 0x00, 11 );          // 16-11-2004 SDH
                    lrt_log( LOG_SOR, hh_unit, dtls );                      // 16-11-2004 SDH

                } else {
                    
                    // User not authorised
                    prep_nak("User ID unknown or incorrect password");

                    //authorised = FALSE;

                    // Audit
                    memcpy( ((LRTLG_SOR *)dtls)->authority, "N", 1);
                    memset( ((LRTLG_SOR *)dtls)->resv, 0x00, 11 );
                    lrt_log( LOG_SOR, hh_unit, dtls );

                    // Deallocate handheld's table entry
                    usrrc = dealloc_lrt_table( hh_unit );
                    break;
                }

                usrrc = open_irf();
                if (usrrc<=RC_DATA_ERR) {
                    prep_nak("ERRORUnable to open EALITEMR file. "          //SDH 23-Aug-2006 Planners
                              "Check appl event logs" );
                    break;
                }

                usrrc = open_irfdex();                                      // SDH 14-01-2005 Promotions
                if (usrrc<=RC_DATA_ERR) {                                   // SDH 14-01-2005 Promotions
                    prep_nak("ERRORUnable to open IRFDEX file. "            //SDH 23-Aug-2006 Planners
                              "Check appl event logs" );                    // SDH 14-01-2005 Promotions
                    close_irf( CL_SESSION );                                // SDH 14-01-2005 Promotions
                    break;                                                  // SDH 14-01-2005 Promotions
                }                                                           // SDH 14-01-2005 Promotions

                usrrc = open_idf();
                if (usrrc<=RC_DATA_ERR) {
                    prep_nak("ERRORUnable to open IDF file. "               //SDH 23-Aug-2006 Planners
                              "Check appl event logs" );
                    close_irf( CL_SESSION );
                    close_irfdex( CL_SESSION );                             // SDH 14-01-2005 Promotions
                    break;
                }
                usrrc = open_isf();
                if (usrrc<=RC_DATA_ERR) {
                    prep_nak("ERRORUnable to open ISF file. "               //SDH 23-Aug-2006 Planners
                              "Check appl event logs" );
                    close_idf( CL_SESSION );
                    close_irf( CL_SESSION );
                    close_irfdex( CL_SESSION );                             // SDH 14-01-2005 Promotions
                    break;
                }

                usrrc = open_rfhist();
                if (usrrc<=RC_DATA_ERR) {
                    prep_nak("ERRORUnable to open RFHIST file. "            //SDH 23-Aug-2006 Planners
                              "Check appl event logs" );
                    close_idf( CL_SESSION );
                    close_irf( CL_SESSION );
                    close_irfdex( CL_SESSION );                             // SDH 14-01-2005 Promotions
                    close_isf( CL_SESSION );
                    close_pgf( CL_SESSION );                                // PAB 23-10-03
                    break;
                }

                //Open planner data (ignore errors)                         // SDH 12-Oct-2006 Planners
                open_srpog();                                               // SDH 12-Oct-2006 Planners
                open_srmod();                                               // SDH 12-Oct-2006 Planners
                open_sritml();                                              // SDH 12-Oct-2006 Planners
                open_sritmp();                                              // SDH 12-Oct-2006 Planners
                open_srpogif();                                             // SDH 12-Oct-2006 Planners
                open_srpogil();                                             // SDH 12-Oct-2006 Planners
                open_srpogip();                                             // SDH 12-Oct-2006 Planners
                open_srcat();                                               // SDH 12-Oct-2006 Planners
                open_srsxf();                                               // SDH 12-Oct-2006 Planners

                //Increment number of sessions
                sess++;

                break;
            }
            //-------------------------------------------------------------------------

        case CMD_OFF:                                                       // Master log off

            if (lrtp[hh_unit] == NULL) {
                // We haven't seen this handheld before
                prep_nak("ERRORForced Sign off in progress. Thank you.");   //SDH 23-Aug-2006 Planners
                break;
            }

            if (strlen( ((LRT_OFF *)(inbound))->opid )==0) {                // 24-8-04 PAB
                // this is a rogue OFF command from a Pocket PC which has   // 24-8-04 PAB
                // been IPLed and is flushing its IP buffer. no user ID.    // 24-8-04 PAB
                // but the unit number may be invalid. IGNORE or you may be // 24-8-04 PAB
                // signing off another unit, which may then appear to lock  // 24-8-04 PAB
                // or hang.                                                 // 24-8-04 PAB
                if (debug) disp_msg("Rogue OFF Flushing");                  // 24-8-04 PAB
                sess--;                                                     // 24-8-04 PAB
                if (sess < 0) sess = 0;                                     // 24-8-04 PAB
                break;                                                      // 24-8-04 PAB
            }                                                               // 24-8-04 PAB

            //Process both just in case                                     // SDH 08-05-2006 Bug fix
            process_workfile( hh_unit, SYS_LAB );                           // SDH 08-05-2006 Bug fix
            process_workfile( hh_unit, SYS_GAP );                           // SDH 08-05-2006 Bug fix

            close_rfhist( CL_SESSION );
            close_isf( CL_SESSION );
            close_idf( CL_SESSION );
            close_irf( CL_SESSION );
            close_irfdex( CL_SESSION );                                     // SDH 14-01-2005 Promotions
            close_rfscf( CL_SESSION );
            close_pgf( CL_SESSION );                                        // PAB 23-10-03

            // Close planner files                                          // SDH 12-Oct-2006 Planners
            close_srpog(CL_SESSION);                                        // SDH 12-Oct-2006 Planners
            close_srmod(CL_SESSION);                                        // SDH 12-Oct-2006 Planners
            close_sritml(CL_SESSION);                                       // SDH 12-Oct-2006 Planners
            close_sritmp(CL_SESSION);                                       // SDH 12-Oct-2006 Planners
            close_srpogif(CL_SESSION);                                      // SDH 12-Oct-2006 Planners
            close_srpogil(CL_SESSION);                                      // SDH 12-Oct-2006 Planners
            close_srpogip(CL_SESSION);                                      // SDH 12-Oct-2006 Planners
            close_srcat(CL_SESSION);                                        // SDH 12-Oct-2006 Planners
            close_srsxf(CL_SESSION);                                        // SDH 12-Oct-2006 Planners

            prep_ack( "" );                                                 //SDH 23-Aug-2006 Planners

            // Deallocate handheld's table entry
            usrrc = dealloc_lrt_table( hh_unit );

            sess--;
            if (sess < 0) sess = 0;                                         // 1-9-2004 PAB

            break;

            //-------------------------------------------------------------------------
        case CMD_GAS:                                                       // Gap monitor sign on

            if (IsHandheldUnknown()) break;                                 // SDH 26-11-04 CREDIT CLAIM
            if (IsStoreClosed()) break;                                     // SDH 26-11-04 CREDIT CLAIM
            UpdateActiveTime();                                             // SDH 26-11-04 CREDIT CLAIM

            usrrc = open_pllol();
            if (usrrc<=RC_DATA_ERR) {
                prep_nak("ERRORUnable to open PLLOL file           "        //SDH 23-Aug-2006 Planners
                          "Check appl event logs" );
                break;
            }
            usrrc = open_plldb();
            if (usrrc<=RC_DATA_ERR) {
                prep_nak("ERRORUnable to open PLLDB file           "        //SDH 23-Aug-2006 Planners
                          "Check appl event logs" );
                break;
            }

            // v4.0 START
            usrrc = prepare_workfile( hh_unit, SYS_LAB );
            if (usrrc<RC_IGNORE_ERR) {
                if (usrrc == RC_DATA_ERR) {
                    prep_nak("ERRORUnable to create workfile. "             //SDH 23-Aug-2006 Planners
                              "Check appl event logs" );
                } else {
                    prep_pq_full_nak();                                     // 22-12-04 SDH
                }
                break;
            }
            // v4.0 END


            // Get RF attributes from control file
            usrrc = open_rfscf();                                           // 12-7-4 PAB
            if (usrrc!=RC_OK) {                                             // 12-7-4 PAB
                prep_nak("ERRORUnable to open RFSCF file. "                 //SDH 23-Aug-2006 Planners
                          "Check appl event logs" );                        // 12-7-4 PAB
                break;                                                      // 12-7-4 PAB
            }                                                               // 12-7-4 PAB
            // 12-7-4 PAB
            rc2 = s_read( A_BOFOFF, rfscf.fnum,                             // 12-7-4 PAB
                          (void *)&rfscfrec1and2, RFSCF_RECL, 0L );         // 16-11-04 SDH
            if (rc2<=0L) {                                                  // 12-7-4 PAB
                log_event101(rc2, RFSCF_REP, __LINE__);           // 12-7-4 PAB
                //sprintf(msg, "Err-R RFSCF. RC:%08lX", rc2);               // 12-7-4 PAB
                //disp_msg(msg);                                            // 12-7-4 PAB
            }                                                               // 12-7-4 PAB
            usrrc = close_rfscf (CL_SESSION );                              // 12-7-4 PAB

            // Prepare GAR  
            memcpy( ((LRT_GAR *)out)->cmd, "GAR", 3 );
            sprintf( sbuf, "%04ld", rfscfrec1and2.pchk_target );            // 16-11-04 SDH
            memcpy( ((LRT_GAR *)out)->pchk_target, sbuf, 4 );               // 12-7-2004 PAB
            sprintf( sbuf, "%04ld", rfscfrec1and2.pchk_done );              // 16-11-04 SDH
            memcpy( ((LRT_GAR *)out)->pchk_done, sbuf, 4 );                 // 12-7-2004 PAB

            // Create a new list (list_id is returned)
            usrrc = create_new_plist( (BYTE *)&(((LRT_GAR *)out)->list_id),
                                      (BYTE *)&(((LRT_GAS *)(inbound))->opid) );
            if (usrrc<RC_IGNORE_ERR) {
                prep_nak("ERRORUnable to create new PLIST. "                //SDH 23-Aug-2006 Planners
                          "Check appl event logs" );
                break;
            }
            out_lth = LRT_GAR_LTH;

            break;
            //-------------------------------------------------------------------------

        case CMD_SIE:                                                       // return current store number                                // 7-7-04 PAB

            {                                                               // 7-7-04 PAB
                hh_unit = 255;                                              // 20-7-2004 PAB

                if (debug) {
                    disp_msg("Process CMD_SIE");
                }

                rc2 = open_invok();                                         // 7-7-04 PAB
                                                                            // 7-7-04 PAB
                rc2 = s_read( A_BOFOFF, invok.fnum,                         // 7-7-04 PAB
                              (void *)&invokrec, INVOK_RECL, 0L );          // 7-7-04 PAB
                if (rc2<=0L) {                                              // 7-7-04 PAB
                    log_event101(rc2, INVOK_REP, __LINE__);       // 7-7-04 PAB
                    //sprintf(msg, "Err-R INVOK. RC:%08lX", rc2);           // 7-7-04 PAB
                    //disp_msg(msg);                                        // 7-7-04 PAB
                    prep_nak("ERRORUnable to READ the INVOK. "              //SDH 23-Aug-2006 Planners
                              "Check appl event logs" );                    // 7-7-04 PAB
                    break;                                                  // 7-7-04 PAB
                }                                                           // 7-7-04 PAB
                // 7-7-04 PAB
                // 7-7-04 PAB
                memcpy( ((LRT_SIR *)&out)->store_number,                    // 7-7-04 PAB
                        invokrec.store_no, 4 );                             // 7-7-04 PAB
                memcpy( ((LRT_SIR *)out)->cmd, "SIR", 3 );                  // 7-7-04 PAB
                out_lth = LRT_SIR_LTH;                                      // 7-7-04 PAB
                rc2 = close_invok( CL_SESSION );                            // 7-7-04 PAB
                                                                            // 7-7-04 PAB
                break;                                                      // 7-7-04 PAB
            }
            // 7-7-04 PAB

            //-------------------------------------------------------------------------
        case CMD_PCM:                                                       // Price mismatch

            time_t CurrTime;                                                // 11-09-2007 12 BMG

            if (IsHandheldUnknown()) break;                                 // SDH 26-11-04 CREDIT CLAIM
            if (IsStoreClosed()) break;                                     // SDH 26-11-04 CREDIT CLAIM
            UpdateActiveTime();                                             // SDH 26-11-04 CREDIT CLAIM

            // Read rfscf record                                            // 11-09-2007 12 BMG 
            rc2 = s_read( A_BOFOFF, rfscf.fnum,                             // 11-09-2007 12 BMG
                        (void *)&rfscfrec1and2, RFSCF_RECL, 0L );           // 11-09-2007 12 BMG
            if (rc2 <= 0L) {                                                // 11-09-2007 12 BMG
                prep_nak("ERRORUnable to read from RFSCF. "                 // 11-09-2007 12 BMG
                          "Check appl event logs" );                        // 11-09-2007 12 BMG
                break;                                                      // 11-09-2007 12 BMG
            }                                                               // 11-09-2007 12 BMG

            // Increment and update price checks done figure on rfscf
            //      sprintf( sbuf, "%04ld", ++(rfscfrec1and2.pchk_errors_c) );

            rfscfrec1and2.pchk_errors_c++;                                  // 16-11-04 SDH
            rfscfrec1and2.pchk_done++;                                      // 16-11-04 SDH

            rc2 = UpdateRfscf(__LINE__);                                    // 03-01-05 SDH
            if (rc2<=0L) {                                                  // 27-10-04 PAB
                prep_nak("ERRORUnable to write to RFSCF. "                  //SDH 23-Aug-2006 Planners
                          "Check appl event logs" );
                break;
            }

            if (((LRT_PCM *)(inbound))->type[0] != 'L') {                       // 10.08.07 PAB Mobile Printing
                // if not printing on a local mobile printer then               // 10.08.07 PAB Mobile Printing
                // Write entry to LAB workfile to trigger price error message   // 28.06.04 PAB
                // 28.06.04 PAB
                memcpy( selbfrec.item_code, "X000000000000", 13 );              // 28.06.04 PAB 
                memcpy( selbfrec.info, lrtp[hh_unit]->user, 3 );                // 28.06.04 PAB
                memcpy( selbfrec.info+3, "000", 3 );                            // 28.06.04 PAB 
                memcpy( selbfrec.printerid, "0", 1 );                           // 28.06.04 PAB
                rc2 = s_write( A_FLUSH | A_FPOFF, lrtp[hh_unit]->fnum1,         // 28.06.04 PAB 
                           (void *)&selbfrec, SELBF_RECL, 0L );                 // 28.06.04 PAB 

                time(&CurrTime);                                                //11-09-2007 12 BMG
                pq[lrtp[hh_unit]->pq_sub1].last_access_time = CurrTime;         //11-09-2007 12 BMG

                if (rc2<=0L) {
                   if (debug) {
                       sprintf(msg, "Err-W SELWF. RC:%08lX", rc2);
                       disp_msg(msg);
                   }
                   prep_nak("ERRORUnable to write to SELWF "                   //SDH 23-Aug-2006 Planners
                            "for PCM Record   " );
                   break;
                }                                                              // 10.08.07 PAB Mobile Printing
            }
            prep_ack("");                                                   //SDH 23-Aug-2006 Planners

            // Audit
            pack( ((LRTLG_PCM *)dtls)->boots_code, 4,
                  ((LRT_PCM *)(inbound))->boots_code, 7, 1 );


            memset( ((LRTLG_PCM *)dtls)->resv, 0x00, 7 );                   // 26-7-2004 PAB
            memcpy( ((LRTLG_PCM *)dtls)->check_type,
                    ((LRT_PCM *)(inbound))->type, 1);                       // 26-7-2004 PAB
            lrt_log( LOG_PCM, hh_unit, dtls );                              // SDH 26-01-2005 SDH

            break;

            //-------------------------------------------------------------------------
        case CMD_GAP:                                                       // Gap monitor - gap notification
            {

                LRT_GAP* pGAP = (LRT_GAP*)inbound;                          // 17-11-04 SDH OSSR WAN

                if (IsHandheldUnknown()) break;                             // SDH 26-11-04 CREDIT CLAIM
                if (IsStoreClosed()) break;                                 // SDH 26-11-04 CREDIT CLAIM
                UpdateActiveTime();                                         // SDH 26-11-04 CREDIT CLAIM

                // write to GAPBF workfile trigger flag
                write_gap = satol(rfscfrec1and2.phase,1);                   // 16-11-04 SDH

                //NAK if creating an OSSR list in a non-OSSR store          // SDH 22-2-2005 EXCESS
                if ((pGAP->gap_flag[0] == 'O') &&                           // SDH 22-2-2005 EXCESS
                    (rfscfrec1and2.ossr_store != 'W')) {                    // SDH 22-2-2005 EXCESS
                    prep_nak("ERRORCannot create "                          //SDH 23-Aug-2006 Planners
                             "an OSSR list in a non-OSSR WAN store.");      // SDH 22-2-2005 EXCESS
                    break;                                                  // SDH 22-2-2005 EXCESS
                }                                                           // SDH 22-2-2005 EXCESS

                // Perform the bulk of the processing                       //SDH 19-01-2005 OSSR WAN
                usrrc = process_gap( pGAP->list_id,                         // 17-11-04 SDH OSSR WAN
                                     pGAP->seq,                             // 17-11-04 SDH OSSR WAN
                                     pGAP->item_code,                       // 17-11-04 SDH OSSR WAN
                                     pGAP->boots_code,                      // 17-11-04 SDH OSSR WAN
                                     pGAP->current,                         // 17-11-04 SDH OSSR WAN
                                     pGAP->fill_qty,                        // 17-11-04 SDH OSSR WAN
                                     pGAP->gap_flag[0],                     // 17-11-04 SDH OSSR WAN
                                     pGAP->cUpdateOssrItem,                 // 17-11-04 SDH OSSR WAN
                                     hh_unit );

                if (usrrc < RC_IGNORE_ERR) {
                    if (usrrc == RC_DATA_ERR) {
                        prep_nak("ERRORRecord not on file. "                //SDH 23-Aug-2006 Planners
                                  "Check appl event logs" );
                    } else {
                         prep_nak("ERRORUndefined 1. Check appl event logs");//SDH 23-Aug-2006 Planners
                    }
                    break;
                }

                prep_ack("");                                               //SDH 23-Aug-2006 Planners
            }

            break;

            //-------------------------------------------------------------------------
        case CMD_GAX:                                                       // General item lookup
            {
                LRT_GAX* pGAX = (LRT_GAX*)inbound;                          // SDH 26-11-04 CREDIT CLAIM
                WORD wListId = satoi(pGAX->list_id, 3);                     // SDH 26-11-04 CREDIT CLAIM
                WORD wPicks = satoi(pGAX->picks, 4);                        // SDH 26-11-04 CREDIT CLAIM

                if (IsHandheldUnknown()) break;                             // SDH 26-11-04 CREDIT CLAIM
                UpdateActiveTime();                                         // SDH 26-11-04 CREDIT CLAIM

                close_plldb( CL_SESSION );

                // Read pllol record                                        // SDH 22-02-2005 EXCESS
                rc2 = ReadPllol(wListId, __LINE__);                         // SDH 22-02-2005 EXCESS
                if (rc2 <= 0L) {
                    prep_nak("ERRORUnable to read from PLLOL. "             //SDH 23-Aug-2006 Planners
                              "Check appl event logs" );
                    break;
                }

                // Update pllol record
                if (wPicks > 0) {                                           // SDH 22-02-2005 EXCESS
                    *(pllolrec.list_status) = 'U';                          // Status : Uncounted
                } else {
                    *(pllolrec.list_status) = 'X';                          // Status : Cancelled
                }
                memcpy(pllolrec.item_count, pGAX->picks,                    // SDH 22-02-2005 EXCESS
                       sizeof(pllolrec.item_count));                        // SDH 22-02-2005 EXCESS

                //Write the PLLOL record back                               // SDH 22-02-2005 EXCESS
                rc2 = WritePllol(wListId, __LINE__);                        // SDH 22-02-2005 EXCESS
                if (rc2<=0L) {
                    prep_nak("ERRORUnable to write to PLLOL. "              //SDH 23-Aug-2006 Planners
                              "Check appl event logs" );
                    close_pllol( CL_SESSION );
                    break;
                }

                //Close PLLOL
                close_pllol( CL_SESSION );

                //Process both just in case                                     // SDH 08-05-2006 Bug fix
                process_workfile( hh_unit, SYS_LAB );                           // SDH 08-05-2006 Bug fix
                process_workfile( hh_unit, SYS_GAP );                           // SDH 08-05-2006 Bug fix

                prep_ack("");                                                   //SDH 23-Aug-2006 Planners

                //Update location: assume handheld is in shop as that's where   //SDH 19-01-2005 OSSR WAN
                //Shelf Monitor and fast fill is done                           //SDH 19-01-2005 OSSR WAN
                lrtp[hh_unit]->bLocation = 'S';                                 //SDH 19-01-2005 OSSR WAN

                // Audit
                ((LRTLG_GAX *)dtls)->gaps_identified = wPicks;              //SDH 26-11-04 CREDIT CLAIM
                memset( ((LRTLG_GAX *)dtls)->resv, 0x00, 8 );
                lrt_log( LOG_GAX, hh_unit, dtls );                          //SDH 19-01-2005 OSSR WAN
            }
            break;

            //-------------------------------------------------------------------------
        case CMD_ENQ:                                                       // General - item lookup
            {

                //Create an ENQ view of the input buffer and an EQR view of // 17-11-04 SDH OSSR WAN
                //the ouput buffer                                          // 17-11-04 SDH OSSR WAN
                LRT_ENQ* pENQ = (LRT_ENQ*)inbound;                          // 17-11-04 SDH OSSR WAN
                LRT_EQR* pEQR = (LRT_EQR*)out;                              // 17-11-04 SDH OSSR WAN

                BOOLEAN fUpdateRfhist = FALSE;                              // 17-11-04 SDH OSSR WAN
                DOUBLE  dLastPriceCheckDate;                                // 17-11-04 SDH OSSR WAN
                DOUBLE  dTodayDate;                                         // 17-11-04 SDH OSSR WAN
                check_accepted = FALSE;                                     // 12-05-05 SDH EXCESS

                //Set up current date and time
                B_DATE nowDate;
                B_TIME nowTime;
                GetSystemDate(&nowTime, &nowDate);

                // if this is not a My StoreNet blind Sign On and
                // We haven't seen this handheld before
                if (satoi(pENQ->opid, sizeof(pENQ->opid)) != 0) {           // SDH 26-11-04 CREDIT CLAIM
                    if (IsHandheldUnknown()) break;                         // SDH 26-11-04 CREDIT CLAIM
                    // if this request has come from StoreNet USerID 000 then simulate
                    // operator sign on processing - allocate hht table entry// 5-7-2004 PAB
                } else {
                    hh_unit = 255;                                          // 20-7-2004 PAB
                    usrrc = alloc_lrt_table( hh_unit );                     // 5-7-2004 PAB
                    if (usrrc<RC_IGNORE_ERR) {                              // 5-7-2004 PAB
                        prep_nak("ERRORUnable to allocate storage. "        //SDH 23-Aug-2006 Planners
                                  "Check appl event logs" );                // 5-7-2004 PAB
                        break;                                              // 5-7-2004 PAB
                    }                                                       // 5-7-2004 PAB
                    // Log current time                                     // 5-7-2004 PAB
                    s_get( T_TD, 0L, (void *)&now, TIMESIZE );              // 5-7-2004 PAB
                    lrtp[hh_unit]->last_active_time = now.td_time;          // 5-7-2004 PAB
                    memcpy( (BYTE *)&(lrtp[hh_unit]->txn), (BYTE *)cmd, 3 );    // 5-7-2004 PAB
                    memset( (BYTE *)&(lrtp[hh_unit]->unique), 0x00, 5 );    // 5-7-2004 PAB
                                                                            // 5-7-2004 PAB
                    // Set state                                            // 5-7-2004 PAB
                    lrtp[hh_unit]->state = ST_LOGGED_ON;                    // 5-7-2004 PAB
                    // Reset misc counts (Unused at present)                // 5-7-2004 PAB
                    lrtp[hh_unit]->count1 = 0;                              // 5-7-2004 PAB
                    lrtp[hh_unit]->count2 = 0;                              // 5-7-2004 PAB
                    if (usrrc!=RC_OK) {                                     // 5-7-2004 PAB
                        prep_nak("ERRORUnable to open RFSCF file. "         //SDH 23-Aug-2006 Planners
                                  "Check appl event logs" );                // 5-7-2004 PAB
                        break;                                              // 5-7-2004 PAB
                    }                                                       // 5-7-2004 PAB

                    usrrc = open_irf();                                     // 5-7-2004 PAB
                    if (usrrc<=RC_DATA_ERR) {                               // 5-7-2004 PAB
                        prep_nak("ERRORUnable to open EALITEMR file. "      //SDH 23-Aug-2006 Planners
                                  "Check appl event logs" );                // 5-7-2004 PAB
                        //close_rfscf( CL_SESSION );                        // 5-7-2004 pab
                        break;                                              // 5-7-2004 PAB
                    }                                                       // 5-7-2004 PAB

                    usrrc = open_irfdex();                                  // SDH 14-01-2005 Promotions
                    if (usrrc<=RC_DATA_ERR) {                               // SDH 14-01-2005 Promotions
                        prep_nak("ERRORUnable to open IRFDEX file. "        //SDH 23-Aug-2006 Planners
                                  "Check appl event logs" );                // SDH 14-01-2005 Promotions
                        close_irf( CL_SESSION );                            // SDH 14-01-2005 Promotions
                        break;                                              // SDH 14-01-2005 Promotions
                    }                                                       // SDH 14-01-2005 Promotions

                    usrrc = open_idf();                                     // 5-7-2004 PAB
                    if (usrrc<=RC_DATA_ERR) {                               // 5-7-2004 PAB
                        prep_nak("ERRORUnable to open IDF file. "           //SDH 23-Aug-2006 Planners
                                  "Check appl event logs" );                // 5-7-2004 PAB
                        close_irf( CL_SESSION );                            // 5-7-2004 PAB
                        close_irfdex( CL_SESSION );                         // SDH 14-01-2005 Promtions
                        //close_rfscf( CL_SESSION );                        // 5-7-2004 pab
                        break;                                              // 5-7-2004 PAB
                    }                                                       // 5-7-2004 PAB
                    usrrc = open_isf();                                     // 5-7-2004 PAB
                    if (usrrc<=RC_DATA_ERR) {                               // 5-7-2004 PAB
                        prep_nak("ERRORUnable to open ISF file. "           //SDH 23-Aug-2006 Planners
                                  "Check appl event logs" );                // 5-7-2004 PAB
                        close_idf( CL_SESSION );                            // 5-7-2004 PAB
                        close_irf( CL_SESSION );                            // 5-7-2004 PAB
                        close_irfdex( CL_SESSION );                         // SDH 14-01-2005 Promtions
                        //close_rfscf( CL_SESSION );                        // 5-7-2004 pab
                        break;                                              // 5-7-2004 PAB
                    }                                                       // 5-7-2004 PAB
                    usrrc = open_rfhist();                                  // 5-7-2004 PAB
                    if (usrrc<=RC_DATA_ERR) {                               // 5-7-2004 PAB
                        prep_nak("ERRORUnable to open RFHIST file. "        //SDH 23-Aug-2006 Planners
                                  "Check appl event logs" );                // 5-7-2004 PAB
                        close_idf( CL_SESSION );                            // 5-7-2004 PAB
                        close_irf( CL_SESSION );                            // 5-7-2004 PAB
                        close_irfdex( CL_SESSION );                         // SDH 14-01-2005 Promtions
                        //close_rfscf( CL_SESSION );                        // 5-7-2004 pab
                        close_isf( CL_SESSION );                            // 5-7-2004 PAB
                        break;                                              // 5-7-2004 PAB
                    }                                                       // 5-7-2004 PAB

                    //Open planner data (ignore errors)                     // SDH 12-Oct-2006 Planners
                    open_srpog();                                           // SDH 12-Oct-2006 Planners
                    open_srmod();                                           // SDH 12-Oct-2006 Planners
                    open_sritml();                                          // SDH 12-Oct-2006 Planners
                    open_sritmp();                                          // SDH 12-Oct-2006 Planners
                    open_srpogif();                                         // SDH 12-Oct-2006 Planners
                    open_srpogil();                                         // SDH 12-Oct-2006 Planners
                    open_srpogip();                                         // SDH 12-Oct-2006 Planners
                    open_srcat();                                           // SDH 12-Oct-2006 Planners
                    open_srsxf();                                           // SDH 12-Oct-2006 Planners

                }                                                           // 5-7-2004 PAB

                if (IsStoreClosed()) break;                                 // SDH 07-12-2004

                // verify that item update batch suite is not running
                // functionalised the JOBOK file open / read / close        // 13-12-04 PAB
                usrrc = process_jobok();                                    // 13-12-04 PAB
                // if the jobok not there then ok to continue               // 13-12-04 PAB   
                // process nullifies the record space                       // 13-12-04 PAB
                // 13-12-04 PAB
                if (debug) {                                                // 13-12-04 PAB
                    sprintf(msg, "RD JOBOK :");                             // 13-12-04 PAB
                    disp_msg(msg);                                          // 13-12-04 PAB
                    dump( jobokrec.psb21, 5 );                              // 13-12-04 PAB
                }                                                           // 13-12-04 PAB  
                // 13-12-04 PAB
                if (jobokrec.psb21[0] == 'S' ||                             // 13-12-04 PAB
                    jobokrec.psb22[0] == 'S' ||                             // 13-12-04 PAB
                    jobokrec.psb23[0] == 'S' ||                             // 13-12-04 PAB
                    jobokrec.psb24[0] == 'S' ||                             // 13-12-04 PAB
                    jobokrec.psb25[0] == 'S') {                             // 13-12-04 PAB
                    if (debug) {                                            // 13-12-04 PAB
                        sprintf(msg, "Item Update Suite is Active");        // 13-12-04 PAB
                        disp_msg(msg);                                      // 13-12-04 PAB
                    }                                                       // 13-12-04 PAB
                } else {                                                    // 13-12-04 PAB
                    if (debug) {                                            // 13-12-04 PAB
                        sprintf(msg, "Item Update Suite is not Active");    // 13-12-04 PAB
                        disp_msg(msg);                                      // 13-12-04 PAB
                    }                                                       // 13-12-04 PAB
                    usrrc = open_pgf();                                     // PAB 23-10-03
                    if (usrrc<=RC_DATA_ERR) {                               // PAB 23-10-03
                        prep_nak("ERRORUnable to open PGF file. "           //SDH 23-Aug-2006 Planners
                                  "Check appl event logs" );                // PAB 23-10-03
                        close_pgf( CL_SESSION );                            // PAB 23-10-03
                        //close_idf( CL_SESSION );                          // PAB 23-10-03
                        //close_irf( CL_SESSION );                          // PAB 23-10-03
                        break;                                              // PAB 23-10-03
                    }
                }                                                           // 13-12-04 PAB

                usrrc = open_rfscf();                                       // 11-09-2007 12 BMG
                if (usrrc!=RC_OK) {                                         // 11-09-2007 12 BMG
                    prep_nak("ERRORUnable to open RFSCF file. "             // 11-09-2007 12 BMG
                              "Check appl event logs" );                    // 11-09-2007 12 BMG
                    break;                                                  // 11-09-2007 12 BMG
                }                                                           // 11-09-2007 12 BMG
                // Read rfscf record                                        // 11-09-2007 12 BMG 
                rc2 = s_read( A_BOFOFF, rfscf.fnum,                         // 11-09-2007 12 BMG
                            (void *)&rfscfrec1and2, RFSCF_RECL, 0L );       // 11-09-2007 12 BMG
                if (rc2 <= 0L) {                                            // 11-09-2007 12 BMG
                    prep_nak("ERRORUnable to read from RFSCF. "             // 11-09-2007 12 BMG
                              "Check appl event logs" );                    // 11-09-2007 12 BMG
                    break;                                                  // 11-09-2007 12 BMG
                }                                                           // 11-09-2007 12 BMG

                // Get stock details (only get stock figure if absolutely necessary)
                usrrc = stock_enquiry( (pENQ->stock_req_flag[0] == 'Y') ?   // 17-11-04 SDH OSSR WAN
                                       SENQ_TSF:SENQ_SELD,                  // 17-11-04 SDH OSSR WAN
                                       pENQ->item_code, &enqbuf );          // PAB 25-10-04

                close_pgf ( CL_SESSION );                                   // PAB 23-10-03 
                if (usrrc < RC_IGNORE_ERR) {                                // PAB 23-10-03
                    if (usrrc==RC_FILE_ERR) {                               // PAB 23-10-03
                        prep_nak("ERROROne or more   files are not open   " //SDH 23-Aug-2006 Planners
                                  "Check appl event logs" );                // PAB 23-10-03
                    } else if (usrrc==RC_DATA_ERR) {                        // PAB 23-10-03
                        prep_nak("ERRORUnable to access data. "             //SDH 23-Aug-2006 Planners
                                  "Check appl event logs" );                // PAB 23-10-03
                    } else {                                                // PAB 23-10-03
                        prep_nak("ERRORUndefined 4                        " //SDH 23-Aug-2006 Planners
                                  "Check appl event logs" );                // PAB 23-10-03
                    }                                                       // PAB 23-10-03
                    break;                                                  // PAB 23-10-03
                }                                                           // PAB 23-10-03
                if (usrrc!=RC_OK) {                                         // PAB 23-10-03
                    // Prepare NAK                                          // PAB 23-10-03
                    prep_nak("  Item not on file" );                        //SDH 23-Aug-2006 Planners
                    break;                                                  // PAB 23-10-03
                }                                                           // PAB 23-10-03

                // PAB 23-10-03
                // Read RFHIST
                memset( rfhistrec.boots_code, 0x00, RFHIST_KEYL );
                pack( rfhistrec.boots_code, 4, enqbuf.boots_code, 7, 1 );
                if (debug) {
                    sprintf(msg, "RD RFHIST :");
                    disp_msg(msg);
                    dump( rfhistrec.boots_code, RFHIST_KEYL );
                }
                rc2 = s_read( 0, rfhist.fnum, (void *)&rfhistrec,
                              RFHIST_RECL, RFHIST_KEYL );

                //If error reading RFHIST
                if (rc2<=0L) {
                    if ((rc2&0xFFFF)==0x06C8 || (rc2&0xFFFF)==0x06CD) {
                        rfhist.present=FALSE;
                    } else {
                        log_event101(rc2, RFHIST_REP, __LINE__);
                        if (debug) {
                            sprintf(msg, "Err-R RFHIST. RC:%08lX", rc2);
                            disp_msg(msg);
                        }
                        prep_nak("ERRORUnable to read from RFHIST. "        //SDH 23-Aug-2006 Planners
                                  "Check appl event logs" );
                        break;
                    }

                    //Else there is a RFHIST record
                } else {

                    rfhist.present=TRUE;

                    // return the date even if this is not a price check 6-7-2004 PAB
                    sprintf( msg, "%s %02d/%02d/%04d",
                             dayname[nowDate.wDOW], nowDate.wDay, nowDate.wMonth, nowDate.wYear );
                    memcpy( pEQR->reject_msg, msg, 14 );

                    if (debug) {
                        sprintf(msg, "OK, REC :");
                        disp_msg(msg);
                        dump( (BYTE *)&rfhistrec, RFHIST_RECL );       
                    }

                }       

                // Prepare EQR
                memcpy( pEQR->cmd, "EQR", 3 );
                memcpy( pEQR->boots_code, enqbuf.boots_code, 7 );
                memcpy( pEQR->parent_code, enqbuf.parent_code, 7 );
                memcpy( pEQR->item_desc, enqbuf.item_desc, 20 );      
                memcpy( pEQR->item_price, enqbuf.item_price, 6 ); 
                memcpy( pEQR->price_emu, enqbuf.item_price,6 );             // 13-08-07 PAB mobile printing
                memcpy( pEQR->cRecallItem, enqbuf.cRecallFlag,1);           // 23-5-07 PAB Recalls
                pEQR->prim_curr[0] = rfscfrec1and2.prim_curr[0];            // 13-08-07 PAB mobile Printing
                
                pEQR->cBusCentre = enqbuf.cBusCentre;                       // 23-11-04 SDH
                memcpy(pEQR->Deal, enqbuf.Deal, sizeof(pEQR->Deal));        // 23-11-04 SDH

                // Obtain bus centre description                            // 17-11-04 SDH OSSR WAN
                usrrc = open_bcsmf();                                       // 17-11-04 SDH OSSR WAN
                if (usrrc<=RC_DATA_ERR) {                                   // 17-11-04 SDH OSSR WAN
                    prep_nak("ERRORUnable to open BCSMF file. "             // SDH 23-Aug-2006 Planners
                              "Check appl event logs" );                    // 17-11-04 SDH OSSR WAN
                    close_bcsmf( CL_SESSION );                              // 17-11-04 SDH OSSR WAN
                    break;                                                  // 17-11-04 SDH OSSR WAN
                }                                                           // 17-11-04 SDH OSSR WAN
                //Set up key to read                                        // 17-11-04 SDH OSSR WAN
                bcsmfrec.cBusCentre = enqbuf.cBusCentre;                    // 17-11-04 SDH OSSR WAN
                //If the read is successful then use the desc on file       // 17-11-04 SDH OSSR WAN
                //otherwise use UNKNOWN                                     // 17-11-04 SDH OSSR WAN
                if (ReadBcsmf(__LINE__) < 0L) {                             // 17-11-04 SDH OSSR WAN
                    memcpy(pEQR->abBusCentreDesc, "UNKNOWN       ",         // 17-11-04 SDH OSSR WAN
                           sizeof(pEQR->abBusCentreDesc));                  // 17-11-04 SDH OSSR WAN
                } else {                                                    // 17-11-04 SDH OSSR WAN
                    memcpy(pEQR->abBusCentreDesc, bcsmfrec.abDesc,          // 17-11-04 SDH OSSR WAN
                           sizeof(pEQR->abBusCentreDesc));                  // 17-11-04 SDH OSSR WAN
                }                                                           // 17-11-04 SDH OSSR WAN
                close_bcsmf(CL_SESSION);                                    // 14-03-05 SDH OSSR WAN

                //Copy relevant SEL description into place
                //If the first two chars of the SEL desc are "X " then 
                //replace it with the IDF description
                if (strncmp( enqbuf.sel_desc, "X ", 2 )!=0) {
                    memcpy( pEQR->sel_desc, enqbuf.sel_desc, 45 );
                } else {
                    memset( txtbuf, 0x20, 45 );
                    format_text( enqbuf.item_desc, 24, txtbuf, 45, 15 );
                    memcpy( pEQR->sel_desc, txtbuf, 45 );             
                }

                //If the status is 'B' or 'C' then force it to ' '.
                if (enqbuf.status[0] == 'B' || enqbuf.status[0] == 'C') {   // 16-7-2004 PAB
                    enqbuf.status[0] = 0x20;                                // 16-7-2004 PAB
                }                                                           // 16-7-2004 PAB

                //Build various fields into the EQR response
                pEQR->status[0] = enqbuf.status[0];
                pEQR->supply_method[0] = enqbuf.supply_method[0];
                pEQR->redeemable[0] = enqbuf.redeemable[0];

                // Return stock figures if required
                if (pENQ->stock_req_flag[0] == 'Y') {
                    memcpy(pEQR->stock_figure, enqbuf.stock_figure, 6 );
                } else {
                    memset(pEQR->stock_figure, 0x20, 6 );
                }

                //If the RFHIST record was not present then initialise one  // SDH 12-05-2005 EXCESS
                if (!rfhist.present) {                                      // SDH 12-05-2005 EXCESS

                    fUpdateRfhist = TRUE;                                   // SDH 12-05-2005 EXCESS

                    //Initialise certain fields.                            // SDH 07-01-2005
                    //We now ALWAYS add a RFHIST record if it was absent    // SDH 07-01-2005
                    memset(rfhistrec.date_last_gap, 0x00,                   // SDH 07-01-2005
                           sizeof(rfhistrec.date_last_gap));                // SDH 07-01-2005
                    memset(rfhistrec.date_last_pchk, 0x00,                  // SDH 07-01-2005
                           sizeof(rfhistrec.date_last_pchk));               // SDH 07-01-2005
                    memset(rfhistrec.price_last_pchk, 0x00,                 // SDH 07-01-2005
                           sizeof(rfhistrec.price_last_pchk));              // SDH 07-01-2005
                    rfhistrec.bUnused = 0;                                  // SDH 28-04-2005
                    memset(rfhistrec.resrv, 0xFF, sizeof(rfhistrec.resrv)); // SDH 07-01-2005

                    //Set the OSSR item flags as appropriate                // SDH 22-12-2004
                    if (rfscfrec1and2.ossr_store != 'W') {                  // SDH 22-12-2004
                        pEQR->cOssrItem = 'N';                              // SDH 22-12-2004
                        rfhistrec.ubPgfOssrFlag = FALSE;                    // SDH 18-03-2005
                        rfhistrec.ubItemOssrFlag = FALSE;                   // SDH 18-03-2005
                    } else if (pENQ->cUpdateOssrItem != ' ') {              // SDH 22-12-2004
                        pEQR->cOssrItem =                                   // SDH 22-12-2004
                            (pENQ->cUpdateOssrItem == 'O' ? 'O':'N');       // SDH 22-12-2004
                        rfhistrec.ubPgfOssrFlag =                           // SDH 18-03-2005
                            (enqbuf.cPgfOssrFlag == 'Y');                   // SDH 18-03-2005
                        rfhistrec.ubItemOssrFlag =                          // SDH 18-03-2005
                            (pENQ->cUpdateOssrItem == 'O');                 // SDH 22-12-2004
                    } else {                                                // SDH 22-12-2004
                        pEQR->cOssrItem =                                   // SDH 22-12-2004
                            (enqbuf.cOssrItem == 'Y' ? 'O':'N');            // SDH 22-12-2004
                        rfhistrec.ubPgfOssrFlag =                           // SDH 18-03-2005
                            (enqbuf.cPgfOssrFlag == 'Y');                   // SDH 18-03-2005
                        rfhistrec.ubItemOssrFlag = (enqbuf.cOssrItem == 'Y');// SDH 18-03-2005
                    }                                                       // SDH 22-12-2004

                    // Item is on RFHIST file (item seen before)                // SDH 12-05-2005 EXCESS
                } else {                                                    // SDH 12-05-2005 EXCESS

                    //Set the OSSR item flags as appropriate                // SDH 22-12-2004
                    if (rfscfrec1and2.ossr_store != 'W') {                  // SDH 22-12-2004
                        pEQR->cOssrItem = 'N';                              // SDH 22-12-2004
                    } else if (pENQ->cUpdateOssrItem != ' ') {              // SDH 22-12-2004
                        pEQR->cOssrItem =                                   // SDH 22-12-2004
                            (pENQ->cUpdateOssrItem == 'O' ? 'O':'N');       // SDH 22-12-2004
                        rfhistrec.ubItemOssrFlag =                          // SDH 22-12-2004
                            (pENQ->cUpdateOssrItem == 'O');                 // SDH 22-12-2004
                        fUpdateRfhist = TRUE;                               // SDH 22-12-2004
                    } else {                                                // SDH 22-12-2004
                        pEQR->cOssrItem =                                   // SDH 22-12-2004
                            (rfhistrec.ubItemOssrFlag ? 'O':'N');           // SDH 22-12-2004
                    }                                                       // SDH 22-12-2004

                }

                // Determine whether item has recently been counted for
                // '[P]rice Check' or '[C]ount and Assemble/Routine Inspection'
                if (pENQ->function[0] == 'P' ||
                    pENQ->function[0] == 'C') {

                    // Compare current price with last pchk price and determine
                    // whether item has been recently counted
                    unpack( sbuf, 6, rfhistrec.price_last_pchk, 3, 0 );
                    if (satol(sbuf, 6) != satol(enqbuf.item_price, 10)) {
                        check_accepted = TRUE;
                        rfscfrec1and2.pchk_done++;                      // 12-1-07 PAB
                        // dont count it if price ok. count is <28days
                        // PCM will count it if error.
                    } else {
                        sysdate( &day, &month, &year, &hour, &min, &sec );
                        dTodayDate = ConvGJ( day, month, year );
                        unpack( sbuf, 8, rfhistrec.date_last_pchk, 4, 0 );
                        day   = satol( sbuf+6, 2 );
                        month = satol( sbuf+4, 2 );
                        year  = satol( sbuf,   4 );
                        dLastPriceCheckDate = ConvGJ( day, month, year );
                        memset(sbuf,0x00,sizeof(rfhistrec.date_last_pchk));                                   // 02-11-07 13 BMG
                        if (((LONG)(dTodayDate - dLastPriceCheckDate) >     // 16-11-04 SDH                   // 02-11-07 13 BMG
                            (LONG)rfscfrec1and2.recheck_days) ||            // 16-11-04 SDH                   // 02-11-07 13 BMG
                            memcmp(rfhistrec.date_last_pchk, sbuf, sizeof(rfhistrec.date_last_pchk)) == 0 ) { // 02-11-07 13 BMG  
                            check_accepted = TRUE;
                            // only count if > 28day check and price is correct
                            // PPC will send PCM is price incorrect and count it
                            rfscfrec1and2.pchk_done++;                      // 07-04-07 SDH
                        }
                    }

                    //If price check is allowed...
                    if (check_accepted) {
                        // Increment and update price checks done figure on RFSCF
                        // update the RFSCF 
                        // rfscfrec1and2.pchk_done++;                          // 16-11-04 SDH
                        rc2 = UpdateRfscf(__LINE__);                        // 03-01-05 SDH
                        if (rc2<=0L) {
                            prep_nak("ERRORUnable to write to RFSCF. "      //SDH 23-Aug-2006 Planners
                                      "Check appl event logs" );
                            break;
                        }

                        // Update RFHIST record
                        sysdate( &day, &month, &year, &hour, &min, &sec );
                        sprintf( sbuf, "%04ld%02ld%02ld", year, month, day );
                        pack( rfhistrec.date_last_pchk, 4, sbuf, 8, 0 );
                        pack( rfhistrec.price_last_pchk, 3, enqbuf.item_price, 6, 0 );
                        fUpdateRfhist = TRUE;

                        //This should NOT be reset
                        //memset( rfhistrec.date_last_gap, 0x00, 4 );

                        pEQR->check_accepted[0] = (check_accepted?'Y':'N');
                        memset(pEQR->reject_msg, 0x20, 14);

                        // Recount not allowed
                    } else {

                        pEQR->check_accepted[0] = (check_accepted?'Y':'N');
                        sprintf( msg, "%s %02ld/%02ld/%04ld",
                                 dayname[ConvDOW(dLastPriceCheckDate)], day, month, year );
                        memcpy( ((LRT_EQR *)out)->reject_msg, msg, 14 );
                    }
                }

                //Update the RFHIST file if a price check was accepted OR
                //an update of the OSSR item status was requested
                if (fUpdateRfhist) {
                    rc2 = WriteRfhist(__LINE__);                            // SDH 18-03-2005
                    if (rc2<=0L) {
                        prep_nak("ERRORUnable to write to RFHIST. "         //SDH 23-Aug-2006 Planners
                                  "Check appl event logs" );
                        break;
                    }
                }

                if (enqbuf.pcheck_exempt[0] == 'N') {

                    disp_msg("Price Check is blocked");

                    // if we decide to send a message to say exempt from
                    // price check then modify the code below.
                    //
                    // sprintf( msg, "%s %02ld/%02ld/%04ld",
                    // dayname[ConvDOW(dLastPriceCheckDate)], day, month, year );
                    // memcpy( ((LRT_EQR *)out)->reject_msg, msg, 14 );

                    check_accepted = FALSE;       
                    pEQR->check_accepted[0] = (check_accepted?'Y':'N');     // 17-11-04 SDH OSSR WAN
                    memset(pEQR->reject_msg, 0x20, sizeof(pEQR->reject_msg));    // 17-11-04 SDH OSSR WAN
                }

                //If price check or fast fill
                if ((pENQ->function[0] == 'P') || (pENQ->function[0] == 'C')) {
                    sprintf( sbuf, "%04ld", rfscfrec1and2.pchk_target );    // 17-11-04 SDH OSSR WAN
                    memcpy( pEQR->pchk_target, sbuf, 4 );                   // 17-11-04 SDH OSSR WAN
                    sprintf( sbuf, "%04ld", rfscfrec1and2.pchk_done );      // 17-11-04 SDH OSSR WAN
                    memcpy( pEQR->pchk_done, sbuf, 4 );                     // 17-11-04 SDH OSSR WAN

                    //Else
                } else {
                    memset( pEQR->pchk_target, 0x20, sizeof(pEQR->pchk_target));
                    memset( pEQR->pchk_done, 0x20, sizeof(pEQR->pchk_done));
                    pEQR->check_accepted[0] = ' ';
                    memset( pEQR->reject_msg, 0x20, sizeof(pEQR->reject_msg));
                }

                //Add currency info to response
                sprintf(sbuf, "%06.f", emu_round((DOUBLE)                   // 16-11-04 SDH
                  (rfscfrec1and2.emu_conv_fact * satol(enqbuf.item_price, 6)) / 1000000.0));    // 16-11-04 SDH
                memcpy(pEQR->price_emu, sbuf, sizeof(pEQR->price_emu));     // 16-11-04 SDH
                pEQR->prim_curr[0] = rfscfrec1and2.prim_curr[0];
                // 16-11-04 SDH
                //      memcpy( ((LRT_EQR *)out)->item_code,                        // v4.0
                //              ((LRT_ENQ *)(inbound))->item_code, 13 );            // v4.0
                memcpy( pEQR->item_code, enqbuf.item_code, 13 );            // v4.0

                //*(((LRT_EQR *)out)->active_deal_flag) =                       // v4.0
                //   ((satoi( enqbuf.deal_num, 4 )!=0) ? 'Y' : 'N');            // v4.0
                pEQR->active_deal_flag[0] = enqbuf.active_deal_flag[0];     // v4.0
                
                // Populate planner fields
                MEMCPY(pEQR->abCoreCount, enqbuf.abCoreCount);              // SDH 12-Oct-2006 Planners
                MEMCPY(pEQR->abNonCoreCount, enqbuf.abNonCoreCount);        // SDH 12-Oct-2006 Planners
                     
                //Format log file details
                //Write to log file
                ((LRTLG_ENQ*)dtls)->enqpc[0] = 0x00;                        // 2-7-04 PAB
                if (pEQR->check_accepted[0] == 'Y') {
                    ((LRTLG_ENQ*)dtls)->enqpc[0] = 0xFF;                    // 2-7-04 PAB
                }
                memset( ((LRTLG_ENQ *)dtls)->resv, 0x00, 11 );              // 2-7-04 PAB
                lrt_log( LOG_ENQ, hh_unit, dtls );                          // SDH 26-01-2005

                if (strncmp(((LRT_ENQ *)(inbound))->opid, "000", 3)==0) {   // 5-7-2004 PAB
                    // IF BLIND ACCESS FROM STORENET THEN SIMULATE A CMD_OFF    // 5-7-2004 pab
                    close_rfhist( CL_SESSION );                             // 5-7-2004 PAB
                    close_isf( CL_SESSION );                                // 5-7-2004 PAB
                    close_idf( CL_SESSION );                                // 5-7-2004 PAB
                    //close_rfscf( CL_SESSION );                                // 5-7-2004 pab
                    close_irf( CL_SESSION );                                // 5-7-2004 PAB
                    close_irfdex( CL_SESSION );                             // SDH 14-01-2005 Promtions

                    // Close planner files                                  // SDH 12-Oct-2006 Planners
                    close_srpog(CL_SESSION);                                // SDH 12-Oct-2006 Planners
                    close_srmod(CL_SESSION);                                // SDH 12-Oct-2006 Planners
                    close_sritml(CL_SESSION);                               // SDH 12-Oct-2006 Planners
                    close_sritmp(CL_SESSION);                               // SDH 12-Oct-2006 Planners
                    close_srpogif(CL_SESSION);                              // SDH 12-Oct-2006 Planners
                    close_srpogil(CL_SESSION);                              // SDH 12-Oct-2006 Planners
                    close_srpogip(CL_SESSION);                              // SDH 12-Oct-2006 Planners
                    close_srcat(CL_SESSION);                                // SDH 12-Oct-2006 Planners
                    close_srsxf(CL_SESSION);                                // SDH 12-Oct-2006 Planners

                    // Deallocate handheld's table entry                        // 5-7-2004 PAB
                    usrrc = dealloc_lrt_table( hh_unit );                   // 5-7-2004 PAB
                }                                                           // 5-7-2004 PAB

                out_lth = LRT_EQR_LTH;

            }

            break;

            //-------------------------------------------------------------------------
        case CMD_PRT:                                                       // General - print shelf-edge label
            {
                //Static (permanent) data
                static BYTE abLastItemCode[13] = "";
                LRT_PRT* pPRT = (LRT_PRT*)inbound;                          // SDH 12-Oct-2006
                time_t CurrTime;                                            //11-09-2007 12 BMG

                if (IsHandheldUnknown()) break;                             // SDH 26-11-04 CREDIT CLAIM
                // If local type print the the PPC needs extra info.        // 07-08-07 PAB Mobile Printing
                if (strncmp(pPRT->type,"L",1)== 0) {                        // 07-08-07 PAB Mobile Printing
                    usrrc = BuildLPR(inbound);                              // 07-08-07 PAB Mobile Printing
                    if (usrrc==1) {                                         // 08-08-07 PAB
                        prep_nak("ERRORItem not on file"                    // 08-08-07 PAB
                                 "Check appl event logs" );                 // 08-08-07 PAB
                        break;                                              // 08-08-07 PAB
                    }    
                    break;                                                  // 07-08-07 PAB Mobile Printing
                }
                
                // if barcode is zeros then get update on printer status    // 19-02-04 PAB
                // new functionality Phase 2 Proximity printing             // 19-02-04 PAB
                if (strncmp(pPRT->item_code, "0000000000000", 13 ) == 0) {  // 19-02-04 PAB
                    // Get SEL printer status                               // 19-02-04 PAB
                    usrrc = open_prtctl();                                  // 19-02-04 PAB
                    if (usrrc<=RC_DATA_ERR) {                               // 19-02-04 PAB
                        prep_nak("ERRORUnable to open PRTCTL file. "        //SDH 23-Aug-2006 Planners
                                  "Check appl event logs" );                // 19-02-04 PAB
                        break;                                              // 19-02-04 PAB
                    }                                                       // 19-02-04 PAB
                    // read the current status record & close the file      // 19-02-04 PAB
                    rc = s_read( A_BOFOFF, prtctl.fnum,                     // 19-02-04 PAB
                                 (void *)&prtctlrec, PRTCTL_RECL, 0L);      // 19-02-04 PAB
                    if (rc<=0L) {                                           // 19-02-04 PAB
                        log_event101(rc, PRTCTL_REP, __LINE__);             // 19-02-04 PAB
                        printf("ERR-R PRTCTL. RC:%081X", rc);               // 19-02-04 PAB
                    }                                                       // 19-02-04 PAB
                    // 19-02-04 PAB
                    usrrc = close_prtctl(CL_SESSION);                       // 19-02-04 PAB
                    // Prep SNR tx and Break;                               // 19-02-04 PAB
                    // Authorise user                                       // 19-02-04 PAB
                    // 19-02-04 PAB
                    usrrc = open_af();                                      // 19-02-04 PAB
                    if (usrrc<=RC_DATA_ERR) {                               // 19-02-04 PAB
                        prep_nak("ERRORUnable to open EALAUTH file. "       //SDH 23-Aug-2006 Planners
                                  "Check appl event logs" );                // 19-02-04 PAB
                        break;                                              // 19-02-04 PAB
                    }                                                       // 19-02-04 PAB
                    usrrc = authorise_user( ((LRT_SOR *)(inbound))->opid,   // 19-02-04 PAB
                                            ((LRT_SOR *)(inbound))->pass,   // 19-02-04 PAB
                                            (BYTE *)&authority,             // 19-02-04 PAB
                                            (BYTE *)&username );            // 19-02-04 PAB
                    close_af( CL_SESSION );                                 // 19-02-04 PAB
                    if (usrrc<RC_IGNORE_ERR) {                              // 19-02-04 PAB
                        prep_nak("ERRORauthorise_user failed"               //SDH 23-Aug-2006 Planners
                                  "Check appl event logs" );                // 19-02-04 PAB
                        break;                                              // 19-02-04 PAB
                    }                                                       // 19-02-04 PAB
                    // 19-02-04 PAB
                    // Save user ID                                         // 19-02-04 PAB
                    MEMCPY(lrtp[hh_unit]->user, ((LRT_SOR *)(inbound))->opid);// 19-02-04 PAB
                    // Get time                                             // 19-02-04 PAB
                    sysdate( &day, &month, &year, &hour, &min, &sec );      // 19-02-04 PAB

                    // Prepare SNR                                          // 19-02-04 PAB
                    buildSNR((LRT_SNR *)&out, prtctlrec.prtnum,             // 16-11-2004 SDH
                             ((LRT_SOR *)(inbound))->opid, authority[0],    // 16-11-2004 SDH
                             username, rfscfrec1and2.ossr_store,            // 25-Sep-2006 SDH Planners
                             rfscfrec1and2.cPlannersActive);                // 25-Sep-2006 SDH Planners

                    out_lth = LRT_SNR_LTH;                                  // 19-02-04 PAB
                    //authorised = TRUE;                                    // 19-02-04 PAB
                    ((LRTLG_SOR *)dtls)->authority[0] = 'Y';                // 17-11-04 SDH
                    memset( ((LRTLG_SOR *)dtls)->resv, 0x00, 11 );          // 19-02-04 PAB
                                                                            // 19-02-04 PAB
                    break;                                                  // 19-02-04 PAB
                }                                                           // 19-02-04 PAB

                if (IsStoreClosed()) break;                                 // SDH 26-11-04 CREDIT CLAIM

                //Check that item is on file, if it wasn't the last item    // SDH 26-11-04 CREDIT CLAIM
                //checked                                                   // SDH 26-11-04 CREDIT CLAIM
                if (strncmp(pPRT->item_code,                                // SDH 26-11-04 CREDIT CLAIM
                            abLastItemCode, sizeof(abLastItemCode)) != 0) { // SDH 26-11-04 CREDIT CLAIM
                    usrrc = stock_enquiry(SENQ_BOOTS, pPRT->item_code,      // SDH 26-11-04 CREDIT CLAIM
                                          &enqbuf);                         // SDH 26-11-04 CREDIT CLAIM
                    if (usrrc != RC_OK) {                                   // SDH 26-11-04 CREDIT CLAIM
                        prep_nak("Item is not on file.");                   // SDH 23-Aug-2006 Planners
                        break;                                              // SDH 26-11-04 CREDIT CLAIM
                    }                                                       // SDH 26-11-04 CREDIT CLAIM
                }                                                           // SDH 26-11-04 CREDIT CLAIM

                //Save away last item                                       // SDH 26-11-04 CREDIT CLAIM
                MEMCPY(abLastItemCode, pPRT->item_code);                    // SDH 26-11-04 CREDIT CLAIM

                // Write entry to LAB workfile (#1)
                MEMCPY(selbfrec.item_code, pPRT->item_code);
                MEMCPY(selbfrec.info, lrtp[hh_unit]->user);
                MEMCPY(selbfrec.info + 3, "000");
                selbfrec.printerid[0] = pPRT->type[0];                        // 18-02-04 PAB
                LONG rc2 = s_write( A_FLUSH | A_FPOFF, lrtp[hh_unit]->fnum1,
                               (void *)&selbfrec, SELBF_RECL, 0L );

                //sprintf(msg, "RC= :, %d",rc2);
                //disp_msg(msg);

                time(&CurrTime);                                            //11-09-2007 12 BMG
                pq[lrtp[hh_unit]->pq_sub1].last_access_time = CurrTime;     //11-09-2007 12 BMG
                
                if (rc2 >= 0) {                                             //PAB 28-NOv-2006
                    prep_ack("");                                           //SDH 23-Aug-2006 Planners
                } else {
                    rc2 = prepare_workfile( hh_unit, SYS_LAB );   
                    // Write entry to LAB workfile (#1)
                    MEMCPY(selbfrec.item_code, pPRT->item_code);
                    MEMCPY(selbfrec.info, lrtp[hh_unit]->user);
                    MEMCPY(selbfrec.info + 3, "000");
                    selbfrec.printerid[0] = pPRT->type[0];                  // 18-02-04 PAB
                    rc2 = s_write( A_FLUSH | A_FPOFF, lrtp[hh_unit]->fnum1,
                                   (void *)&selbfrec, SELBF_RECL, 0L );
                    pPRT->type[0] = '0';                                    // 24-02-04 PAB
                    if (rc2>=0) {                                           //PAB 28-Nov-2006
                        prep_ack("");                                       //SDH 23-Aug-2006 Planners
                    } else {
                        log_event101(rc, SELBF_REP, __LINE__);
                        prep_nak("ERRORUnable to write to temp SELBF. "     //SDH 23-Aug-2006 Planners
                                  "Check appl event logs" );
                        break; 
                    } 
                }


                // Audit
                //  memset( ((LRTLG_PRT *)dtls)->resv, 0x00, 11 );                             // 25-8-2004 PAB
                memcpy(((LRTLG_PRT *)dtls)->resv, ((LRT_PRT *)(inbound))->item_code, 12 );    // 25-8-2004 PAB
                lrt_log( LOG_PRT, hh_unit, dtls );
            }

            break;

            //-------------------------------------------------------------------------
        case CMD_PLO:                                                       // Picking list log on

            if (IsHandheldUnknown()) break;                                 // SDH 26-11-04 CREDIT CLAIM
            if (IsStoreClosed()) break;                                     // SDH 26-11-04 CREDIT CLAIM
            UpdateActiveTime();                                             // SDH 26-11-04 CREDIT CLAIM

            usrrc = open_pllol();
            if (usrrc<=RC_DATA_ERR) {
                prep_nak("ERRORUnable to open PLLOL file. "                 //SDH 23-Aug-2006 Planners
                          "Check appl event logs" );
                break;
            }
            usrrc = open_plldb();
            if (usrrc<=RC_DATA_ERR) {
                close_pllol(CL_SESSION);                                    // SDH 14-03-2005 EXCESS
                prep_nak("ERRORUnable to open PLLDB file. "                 //SDH 23-Aug-2006 Planners
                          "Check appl event logs" );
                break;
            }

            usrrc = open_minls();
            if (usrrc<=RC_DATA_ERR) {
                close_pllol(CL_SESSION);                                    // SDH 14-03-2005 EXCESS
                close_plldb(CL_SESSION);                                    // SDH 14-03-2005 EXCESS
                prep_nak("ERRORUnable to open MINLS file. "                 //SDH 23-Aug-2006 Planners
                          "Check appl event logs" );
                break;
            }

            usrrc = prepare_workfile( hh_unit, SYS_LAB );
            if (usrrc<RC_IGNORE_ERR) {
                if (usrrc == RC_DATA_ERR) {
                    prep_nak("ERRORUnable to create workfile. "             //SDH 23-Aug-2006 Planners
                              "Check appl event logs" );
                } else {
                    prep_pq_full_nak();                                     // 22-12-04 SDH
                }
                close_pllol(CL_SESSION);                                    // SDH 14-03-2005 EXCESS
                close_plldb(CL_SESSION);                                    // SDH 14-03-2005 EXCESS
                close_minls(CL_SESSION);                                    // SDH 14-03-2005 EXCESS
                break;
            }

            prep_ack("");                                                   //SDH 23-Aug-2006 Planners

            break;

            //-------------------------------------------------------------------------
        case CMD_PLR:                                                       // Picking list get list of lists

            if (IsHandheldUnknown()) break;                                 // SDH 26-11-04 CREDIT CLAIM
            UpdateActiveTime();                                             // SDH 26-11-04 CREDIT CLAIM

            // Get next record from PLLOL
            usrrc = pllol_get_next( /*hh_unit,*/
                                    (BYTE *)((LRT_PLR *)(inbound))->list_id,
                                    (LRT_PLL *)out );
            if (usrrc<RC_IGNORE_ERR) {
                if (usrrc == RC_DATA_ERR) {
                    prep_nak("ERRORI/O error. Check appl event logs" );     //SDH 23-Aug-2006 Planners
                } else {
                    prep_nak("ERRORUndefined 6. Check appl event logs" );   //SDH 23-Aug-2006 Planners
                }
                break;
            }
            if (usrrc==1) {
                // Record available - Prepare PLL
                memcpy( ((LRT_PLL *)out)->cmd, "PLL", 3 );
                out_lth = LRT_PLL_LTH;
            } else {
                // Record not available - Prepare PLE
                memcpy( ((LRT_PLE *)out)->cmd, "PLE", 3 );
                memcpy( ((LRT_PLE *)out)->list_id,
                        ((LRT_PLR *)(inbound))->list_id, 3);                // v2.3
                out_lth = LRT_PLE_LTH;
            }

            break;

            //-------------------------------------------------------------------------
        case CMD_PLS:                                                       // Picking list get List
            {

                //Setup specific view of input                              // SDH 26-11-04 CREDIT CLAIM
                LRT_PLS* pPLS = (LRT_PLS*)inbound;                          // SDH 26-11-04 CREDIT CLAIM
                list_id = satol(pPLS->list_id, 3);                          // SDH 26-11-04 CREDIT CLAIM

                if (IsHandheldUnknown()) break;                             // SDH 26-11-04 CREDIT CLAIM
                if (IsStoreClosed()) break;                                 // SDH 26-11-04 CREDIT CLAIM

                pack((BYTE *)&(lrtp[hh_unit]->unique), 2, pPLS->seq, 3, 1); // SDH 22-02-2005 EXCESS

                // Update PLLOL status and picker details for 1st item in list
                if (strncmp(pPLS->seq, "001", 3) == 0) {                    // SDH 26-11-04 CREDIT CLAIM

                    // Read pllol record                                    // SDH 22-02-2005 EXCESS
                    rc2 = ReadPllol(list_id, __LINE__);                     // SDH 22-02-2005 EXCESS
                    if (rc2 <= 0L) {
                        prep_nak("ERRORUnable to read from PLLOL. "         //SDH 23-Aug-2006 Planners
                                  "Check appl event logs" );
                        break;
                    }

                    if (pllolrec.list_status[0] == 'P') {                   // SDH 10-1-2005 OSSR WAN
                        prep_nak("This list has already been picked and is "//SDH 23-Aug-2006 Planners
                                  "no longer available." );                 // 27-10-04 PAB
                        break;                                              // 27-10-04 PAB

                        //Prevent anyone except the person who was last in the      // SDH 10-1-2005 OSSR WAN
                        //list from accessing it.                                   // SDH 10-1-2005 OSSR WAN
                    } else if (pllolrec.list_status[0] == 'A') {            // SDH 10-1-2005 OSSR WAN
                        WORD wLastPicker = satoi(pllolrec.picker, 3);       // SDH 10-1-2005 OSSR WAN
                        WORD wNewPicker = satoi(pPLS->opid, 3);             // SDH 10-1-2005 OSSR WAN
                        if ((wLastPicker != wNewPicker) &&                  // SDH 10-1-2005 OSSR WAN
                            (wLastPicker != 0)) {                           // SDH 10-1-2005 OSSR WAN
                            sprintf(sbuf, "List already active.\nOnly user ID "    // SDH 10-1-2005 OSSR WAN
                                    "%.3d can open this list.",             // SDH 10-1-2005 OSSR WAN
                                    wLastPicker);                           // SDH 10-1-2005 OSSR WAN
                            prep_nak(sbuf);                                 //SDH 23-Aug-2006 Planners
                            break;                                          // SDH 10-1-2005 OSSR WAN
                        }                                                   // SDH 10-1-2005 OSSR WAN
                    }                                                       // SDH 10-1-2005 OSSR WAN

                    //Update handheld's location                            // SDH 10-1-2005 OSSR WAN
                    if ((pllolrec.cLocation == 'O') ||                      // SDH 22-02-2005 EXCESS
                        (pllolrec.cLocation == 'C')) {                      // SDH 22-02-2005 EXCESS
                        lrtp[hh_unit]->bLocation = 'O';                     // SDH 22-02-2005 EXCESS
                    } else {                                                // SDH 22-02-2005 EXCESS
                        lrtp[hh_unit]->bLocation = 'S';                     // SDH 22-02-2005 EXCESS
                    }                                                       // SDH 22-02-2005 EXCESS

                    //Create SEL workfile                                   // SDH 08-05-2006 Bug fix
                    prepare_workfile(hh_unit, SYS_LAB);                     // SDH 08-05-2006 Bug fix
                    prepare_workfile(hh_unit, SYS_GAP);                     // SDH 30-07-2006 Bug fix

                    // Update pllol record
                    *(pllolrec.list_status) = 'A';                          // Status : Active
                    memcpy( pllolrec.picker, (((LRT_PLS *)(inbound))->opid), 3 );
                    sysdate( &day, &month, &year, &hour, &min, &sec );
                    sprintf( sbuf, "%02d%02d", hour, min );
                    memcpy( pllolrec.pick_start_time, sbuf, 4 );
                    rc2 = WritePllol(list_id, __LINE__);
                    if (rc2 <= 0L) {
                        prep_nak("ERRORUnable to write to PLLOL. "          //SDH 23-Aug-2006 Planners
                                  "Check appl event logs" );
                        break;
                    }
                }

                // Get next record from PLLDB
                usrrc = plldb_get_next( /*hh_unit,*/
                                        (BYTE *)((LRT_PLS *)(inbound))->list_id,
                                        (BYTE *)((LRT_PLS *)(inbound))->seq,
                                        (LRT_PLI *)out );
                if (debug) {
                    sprintf(msg, "plldb_get_next() rc=%d", usrrc);
                    disp_msg(msg);
                }
                if (usrrc<RC_IGNORE_ERR) {
                    if (usrrc == RC_DATA_ERR) {
                        prep_nak("ERRORUnable to read from PLLDB. "         //SDH 23-Aug-2006 Planners
                                  "Check appl event logs" );
                    } else {
                        prep_nak("ERRORUndefined 7. "                       //SDH 23-Aug-2006 Planners
                                  "Check appl event logs" );
                    }
                    break;
                }


                if (usrrc==1) {
                    // Record available - Prepare PLI
                    memcpy( ((LRT_PLI *)out)->cmd, "PLI", 3 );
                    out_lth = LRT_PLI_LTH;
                } else {
                    if (strncmp( (((LRT_PLS *)(inbound))->seq), "001", 3 ) == 0) {
                        prep_nak("This list has already been picked and is "//SDH 23-Aug-2006 Planners
                                  "no longer available." );
                    } else {
                        // Record not available - Prepare PLE
                        memcpy( ((LRT_PLE *)out)->cmd, "PLE", 3 );
                        out_lth = LRT_PLE_LTH;
                    }
                }
            }
            break;

            //-------------------------------------------------------------------------
        case CMD_PLC:                                                       // Picking list update item
            {
                B_DATE nowDate;                                             // SDH 26-11-04 CREDIT CLAIM
                B_TIME nowTime;                                             // SDH 26-11-04 CREDIT CLAIM
                DOUBLE dTodayJul;                                           // SDH 26-11-04 CREDIT CLAIM
                DOUBLE dLastDeliveryJul;                                    // SDH 26-11-04 CREDIT CLAIM
                DOUBLE dMinlsRecountJul;                                    // SDH 26-11-04 CREDIT CLAIM
                LRT_PLC* pPLC = (LRT_PLC*)inbound;                          // SDH 26-11-04 CREDIT CLAIM
                BOOLEAN fDecrementItemCount = TRUE;                         // SDH 26-11-04 CREDIT CLAIM
                WORD wTemp;                                                 // SDH 26-11-04 CREDIT CLAIM
                WORD wListId = satoi(pPLC->list_id, sizeof(pPLC->list_id)); // SDH 26-11-04 CREDIT CLAIM
                WORD wDeliveryAdj = 0;                                      // SDH 26-11-04 CREDIT CLAIM
                WORD wOssrCount;                                            // SDH 22-02-05 EXCESS
                WORD wShelfCount;                                           // SDH 22-02-05 EXCESS
                WORD wBackCount;                                            // SDH 22-02-05 EXCESS
                LONG lStockFigure;                                          // SDH 22-02-05 EXCESS
                BOOLEAN fExcessList;                                        // SDH 07-07-05 EXCESS

                //Get today's date as a Julian                              // SDH 22-02-05 EXCESS
                GetSystemDate(&nowTime, &nowDate);                          // SDH 22-02-05 EXCESS
                dTodayJul = ConvGJ(nowDate.wDay, nowDate.wMonth,            // SDH 22-02-05 EXCESS
                                   nowDate.wYear);                          // SDH 22-02-05 EXCESS
                if (debug) {                                                // SDH 22-02-05 EXCESS
                    sprintf(msg, "Today is %s %02d/%02d/%04d %16ld",        // SDH 22-02-05 EXCESS
                            dayname[nowDate.wDOW], nowDate.wDay,            // SDH 22-02-05 EXCESS
                            nowDate.wMonth, nowDate.wYear, dTodayJul);      // SDH 22-02-05 EXCESS
                    disp_msg(msg);                                          // SDH 22-02-05 EXCESS
                }                                                           // SDH 22-02-05 EXCESS

                //Initial checks                                            // SDH 26-11-04 CREDIT CLAIM
                if (IsHandheldUnknown()) break;                             // SDH 26-11-04 CREDIT CLAIM
                if (IsStoreClosed()) break;                                 // SDH 26-11-04 CREDIT CLAIM
                UpdateActiveTime();                                         // SDH 26-11-04 CREDIT CLAIM

                //NAK a location of OSSR for non-OSSR stores                // SDH 22-02-05 EXCESS
                if ((pPLC->cPickLocation == 'O') &&                         // SDH 22-02-05 EXCESS
                    (rfscfrec1and2.ossr_store != 'W')) {                    // SDH 22-02-05 EXCESS
                    prep_nak("ERRORCannot count an OSSR "                   //SDH 23-Aug-2006 Planners
                              "location in a non-OSSR WAN store. ");        // SDH 22-02-05 EXCESS
                    break;                                                  // SDH 22-02-05 EXCESS
                }                                                           // SDH 22-02-05 EXCESS

                //Set up PLLDB key                                          // SDH 26-11-04 CREDIT CLAIM
                memcpy( plldbrec.list_id, pPLC->list_id, 3 );               // SDH 26-11-04 CREDIT CLAIM
                memcpy( plldbrec.seq, pPLC->seq, 3 );                       // SDH 26-11-04 CREDIT CLAIM

                //Default is not accepted                                   // 15-9-04 PAB
                count_accepted = FALSE;                                     // 15-9-04 PAB

                // move the stock enquiry up in the transaction so          // 2-9-2004 PAB OSSR
                // enable the sales figure at time of backshop count        // 2-9-2004 PAB OSSR
                // to be stored on the plldb record. - can then be used     // 2-9-2004 PAB OSSR
                // for future reporting and full OSSR solution.             // 2-9-2004 PAB OSSR
                // Do stock enquiry for counted item.                       // 2-9-2004 PAB OSSR
                // Made read independent of whether gap flag set to ensure  // 2-9-2004 PAB OSSR
                // we have the item details regardless                      // 2-9-2004 PAB OSSR
                memset( item_code, '0', 13 );                               // 2-9-2004 PAB OSSR
                memcpy( item_code+6, pPLC->boots_code, 7 );                 // 2-9-2004 PAB OSSR
                usrrc = stock_enquiry( SENQ_TSF, item_code, &enqbuf );      // 2-9-2004 PAB OSSR
                if (usrrc!=RC_OK) {                                         // 2-9-2004 PAB OSSR
                    log_event101(usrrc, 0, __LINE__);             // 2-9-2004 PAB OSSR
                    if (debug) {                                            // 2-9-2004 PAB OSSR
                        sprintf(msg, "Error - stock_enquiry(). RC:%d",      // 2-9-2004 PAB OSSR
                                usrrc);                                     // 2-9-2004 PAB OSSR
                        disp_msg(msg);                                      // 2-9-2004 PAB OSSR
                    }                                                       // 2-9-2004 PAB OSSR
                    prep_nak("ERRORStock enquiry failed. "                  //SDH 23-Aug-2006 Planners
                             "Check appl event logs");                      // 2-9-2004 PAB OSSR
                    break;                                                  // 2-9-2004 PAB OSSR
                }                                                           // 2-9-2004 PAB OSSR

                //Reformat certain fields from the stock enquiry            // SDH 22-02-05 EXCESS
                lStockFigure = satol( enqbuf.stock_figure, 6 );             // SDH 22-02-05 EXCESS

                // if list id is zero then this is a Theo Stock Figure change   // SDH 26-11-04 UPWARDS TSF
                if (wListId == 0) {                                         // SDH 26-11-04 UPWARDS TSF

                    // compute date of last delivery as Julian date             // 21-10-04 PAB
                    unpack( sbuf, 6, enqbuf.date_last_delivery, 3, 0 );     // 21-10-04 PAB
                    day   = satol( sbuf+4, 2 );                             // 21-10-04 PAB
                    month = satol( sbuf+2, 2 );                             // 21-10-04 PAB
                    year  = satol( sbuf,   2 )+2000L;                       // 21-10-04 PAB
                    dLastDeliveryJul = ConvGJ(day, month, year);            // 21-10-04 PAB
                    if (debug) {                                            // 21-10-04 PAB
                        sprintf(msg, "Item had a delivery on %s "           // 21-10-04 PAB
                                "%02ld/%02ld/%04ld %16ld",                  // 21-10-04 PAB
                                dayname[ConvDOW(dLastDeliveryJul)], day, month,    // 21-10-04 PAB
                                year, dLastDeliveryJul);                    // 21-10-04 PAB
                        disp_msg(msg);                                      // 21-10-04 PAB
                    }                                                       // 21-10-04 PAB

                    // if date of last delivery is less/equal INVOK.RP.days then// 21-10-04 PAB
                    //    nak the update with a message                         // 21-10-04 PAB
                    //    and break                                             // 21-10-04 PAB
                    // if today is Thur,Fri,Sat,Sun at 2 to rpdays to allow for // 21-10-04 PAB
                    //    for 5 day delivery week                               // 21-10-04 PAB
                    if (nowDate.wDOW >= 1 && nowDate.wDOW <= 3) {           //Mon to Wed  // SDH 22-02-05 EXCESS
                        wDeliveryAdj = 2;                                   // 21-10-04 PAB
                        if (debug) {                                        // 21-10-04 PAB
                            sprintf(msg, "Adjust Delivery days for 5 day cycle");    //21-10-04 PAB
                            disp_msg(msg);                                  // 21-10-04 PAB
                        }                                                   // 21-10-04 PAB
                    }                                                       // 21-10-04 PAB

                    //Open, read, close INVOK                                   // 21-10-04 PAB
                    open_invok();                                           // 21-10-04 PAB
                    rc2 = s_read( A_BOFOFF, invok.fnum,                     // 21-10-04 PAB
                                  (void *)&invokrec, INVOK_RECL, 0L );      // 21-10-04 PAB
                    close_invok(CL_SESSION);                                // 10-03-05 SDH EXCESS
                    if (rc2<=0L) {                                          // 21-10-04 PAB
                        log_event101(rc2, INVOK_REP, __LINE__);   // 21-10-04 PAB
                        prep_nak("ERRORUnable to READ the INVOK. "          //SDH 23-Aug-2006 Planners
                                  "Check appl event logs" );                // 21-10-04 PAB
                        break;                                              // 21-10-04 PAB
                    }                                                       // 21-10-04 PAB

                    //Extract the current stock figure and the new stock figure
                    wBackCount = satoi(pPLC->count, 4);                     // SDH 22-02-05 EXCESS

                    //Alway allow TSF adjustments for +ve stock adj         // SDH 03-02-2005 UPWARDS TSF
                    if (wBackCount < lStockFigure) {                        // SDH 12-09-2005 UPWARDS TSF
                        //Reject deliv dt if stk might not have arrived yet // SDH 03-02-2005 UPWARDS TSF
                        LONG daysSinceDelivery = dTodayJul - dLastDeliveryJul;    // SDH 03-02-2005 UPWARDS TSF
                        LONG deliveryLeadDays = satol(invokrec.rp_days,1) + // SDH 03-02-2005 UPWARDS TSF
                                                wDeliveryAdj;               // SDH 03-02-2005 UPWARDS TSF
                        if (daysSinceDelivery < deliveryLeadDays) {         // SDH 03-02-2005 UPWARDS TSF
                            count_accepted = FALSE;                         // 21-10-04 PAB
                            if (debug) {                                    // 21-10-04 PAB
                                sprintf(msg, "TSF Rejected delivery date "  // 21-10-04 PAB
                                        "%08ld/%08ld %8ld",                 // 21-10-04 PAB
                                        dTodayJul, dLastDeliveryJul,        // 21-10-04 PAB
                                        invokrec.rp_days );                 // 21-10-04 PAB
                                disp_msg(msg);                              // 21-10-04 PAB
                            }                                               // 21-10-04 PAB
                            sprintf( msg,                                   // 21-10-04 PAB
                                     "Count Rejected. Item had a delivery " // 21-10-04 PAB
                                     "on %s %02ld/%02ld/%04ld",             // 21-10-04 PAB
                                     dayname[ConvDOW(dLastDeliveryJul)],    // 10-01-05 SDH OSSR WAN
                                     day, month, year );                    // 10-01-05 SDH OSSR WAN
                            prep_nak(msg);                                  //SDH 23-Aug-2006 Planners
                            break;                                          // 21-10-04 PAB
                        }                                                   // 21-10-04 PAB
                    }                                                       // SDH 03-02-2005 UPWARDS TSF

                }                                                           // 21-10-04 PAB

                //If NOT a Theo Stock Figure update                         // SDH 03-02-2005 UPWARDS TSF
                if (wListId != 0) {                                         // SDH 03-02-2005 UPWARDS TSF

                    //Auto-set the OSSR item flag if stock has been counted // SDH 09-03-05 OSSR WAN
                    //in the OSSR                                           // SDH 09-03-05 OSSR WAN
                    if (pPLC->cPickLocation == 'O') {                       // SDH 09-03-05 OSSR WAN
                        WORD wOSCnt = satoi(pPLC->abOssrCount,              // SDH 09-03-05 OSSR WAN
                                            sizeof(pPLC->abOssrCount));     // SDH 09-03-05 OSSR WAN
                        if (wOSCnt > 0) pPLC->cUpdateOssrItem = 'O';        // SDH 09-03-05 OSSR WAN
                    }                                                       // SDH 09-03-05 OSSR WAN

                    //Attempt to read the PLLOL                             // SDH 22-02-05 EXCESS
                    //We need to know what the current list location flag   // SDH 22-02-05 EXCESS
                    //is in order to determine whether to flag the item     // SDH 22-02-05 EXCESS
                    //as picked.                                            // SDH 22-02-05 EXCESS
                    rc2 = ReadPllol(wListId, __LINE__);                     // SDH 22-02-05 EXCESS
                    if (rc2<=0L) {                                          // SDH 22-02-05 EXCESS
                        prep_nak("ERRORUnable to read from PLLOL. "         //SDH 23-Aug-2006 Planners
                                  "Check appl event logs" );                // SDH 22-02-05 EXCESS
                        break;                                              // SDH 22-02-05 EXCESS
                    }                                                       // SDH 22-02-05 EXCESS

                    //Set flag if Excess Stock list location                // SDH 07-07-05 EXCESS
                    if (pllolrec.cLocation == 'E' ||                        // SDH 07-07-05 EXCESS
                        pllolrec.cLocation == 'C' ||                        // SDH 07-07-05 EXCESS
                        pllolrec.cLocation == 'D' ||                        // SDH 07-07-05 EXCESS
                        pllolrec.cLocation == 'B') {                        // SDH 07-07-05 EXCESS
                        fExcessList = TRUE;                                 // SDH 07-07-05 EXCESS
                    } else {                                                // SDH 07-07-05 EXCESS
                        fExcessList = FALSE;                                // SDH 07-07-05 EXCESS
                    }                                                       // SDH 07-07-05 EXCESS

                    //Picking lists counts are never NAKed                  // 15-9-04 PAB
                    count_accepted = TRUE;                                  // 15-9-04 PAB

                    //Attempt to read the PLLDB locked                      // SDH 22-02-05 EXCESS
                    rc2 = ReadPlldbLock(__LINE__);                          // SDH 22-02-05 EXCESS
                    if (rc2 <= 0L) {                                        // SDH 22-02-05 EXCESS
                        prep_nak("ERRORUnable to read (lock) PLLDB. "       //SDH 23-Aug-2006 Planners
                                 "Check appl event logs" );                 // SDH 22-02-05 EXCESS
                        break;                                              // SDH 22-02-05 EXCESS
                    }                                                       // SDH 22-02-05 EXCESS

                    if (debug) {                                            // PAB 31-10-03
                        disp_msg( "PLLDB item status" );                    // PAB 31-10-03
                        dump ( plldbrec.item_status, 1);                    // PAB 31-10-03
                    }                                                       // PAB 31-10-03
                    if (plldbrec.item_status[0] == 'P') {                   // PAB 31-10-03
                        fDecrementItemCount = FALSE;                        // PAB 31-10-03
                        if (debug) disp_msg("Already picked");              // PAB 31-10-03
                    }                                                       // PAB 31-10-03

                    //Read, update or create RFHIST record                  // SDH 17-11-04 OSSR WAN
                    //if the OSSR item status needs updating                // SDH 17-11-04 OSSR WAN
                    //We only need the RFHIST record if OSSR WAN is active  // SDH 17-11-04 OSSR WAN
                    //to compare the picking location with the 'home'       // SDH 17-11-04 OSSR WAN
                    //location of the item                                  // SDH 17-11-04 OSSR WAN
                    if ((rfscfrec1and2.ossr_store == 'W') &&                // SDH 17-11-04 OSSR WAN
                        (pPLC->cUpdateOssrItem != ' ')) {                   // SDH 17-11-04 OSSR WAN
                        usrrc = ProcessRfhist(plldbrec.boots_code,          // SDH 17-11-04 OSSR WAN
                                              pPLC->cUpdateOssrItem,        // SDH 17-11-04 OSSR WAN
                                              __LINE__);                    // SDH 17-11-04 OSSR WAN
                        if (usrrc > RC_OK) {                                // SDH 17-11-04 OSSR WAN
                            prep_nak("ERRORUnable to process RFHIST. "      //SDH 23-Aug-2006 Planners
                                      "Check appl event logs" );            // SDH 17-11-04 OSSR WAN
                        }                                                   // SDH 17-11-04 OSSR WAN
                    }                                                       // SDH 17-11-04 OSSR WAN

                    //Get the current date/time for writing to PLLDB        // SDH 22-02-05 EXCESS
                    sprintf(sbuf, "%02d%02d", nowTime.wHour, nowTime.wMin); // SDH 22-02-05 EXCESS

                    //Update appropriate location fields                    // SDH 22-02-05 EXCESS
                    if (pPLC->cPickLocation == 'S') {                       // SDH 22-02-05 EXCESS
                        lrtp[hh_unit]->bLocation = 'S';                     // SDH 22-02-05 EXCESS
                        memcpy(plldbrec.qty_on_shelf, pPLC->count,          // SDH 22-02-05 EXCESS
                               sizeof(plldbrec.qty_on_shelf));              // SDH 22-02-05 EXCESS
                        pack(plldbrec.time_sf_count, 2, sbuf, 4, 0);        // SDH 22-02-05 EXCESS
                        memcpy(plldbrec.sales_figure,                       // SDH 22-02-05 EXCESS
                               enqbuf.items_sold_today+2,                   // SDH 22-02-05 EXCESS
                               sizeof(plldbrec.sales_figure));              // SDH 22-02-05 EXCESS
                    } else if (pPLC->cPickLocation == 'B') {                // SDH 22-02-05 EXCESS
                        lrtp[hh_unit]->bLocation = 'S';                     // SDH 22-02-05 EXCESS
                        memcpy(plldbrec.stock_room_count, pPLC->count,      // SDH 22-02-05 EXCESS
                               sizeof(plldbrec.stock_room_count));          // SDH 22-02-05 EXCESS
                        pack( plldbrec.time_bs_count, 2, sbuf, 4, 0);       // SDH 22-02-05 EXCESS
                        memcpy(plldbrec.sales_bs_count,                     // SDH 22-02-05 EXCESS
                               enqbuf.items_sold_today+2,                   // SDH 22-02-05 EXCESS
                               sizeof(plldbrec.sales_figure));              // SDH 22-02-05 EXCESS
                    } else if (pPLC->cPickLocation == 'O') {                // SDH 22-02-05 EXCESS
                        lrtp[hh_unit]->bLocation = 'O';                     // SDH 22-02-05 EXCESS
                        memcpy(plldbrec.ossr_count, pPLC->abOssrCount,      // SDH 22-02-05 EXCESS
                               sizeof(plldbrec.ossr_count));                // SDH 22-02-05 EXCESS
                        pack( plldbrec.time_ossr_count, 2, sbuf, 4, 0);     // SDH 22-02-05 EXCESS
                        memcpy(plldbrec.sales_ossr_count,                   // SDH 22-02-05 EXCESS
                               enqbuf.items_sold_today+2,                   // SDH 22-02-05 EXCESS
                               sizeof(plldbrec.sales_figure));              // SDH 22-02-05 EXCESS
                    }                                                       // SDH 22-02-05 EXCESS

                    //Flag as picked if counted on shop floor and home      // SDH 22-02-05 EXCESS
                    //location. If it's determined not to have              // SDH 22-02-05 EXCESS
                    //been picked yet then don't decrement the PLLOL count  // SDH 22-02-05 EXCESS
                    if ((rfscfrec1and2.ossr_store == 'W') &&                // SDH 22-02-05 EXCESS
                        (enqbuf.cOssrItem == 'Y')) {                        // SDH 22-02-05 EXCESS
                        if ((plldbrec.time_sf_count[0] != 0xff) &&          // SDH 22-02-05 EXCESS
                            (plldbrec.time_ossr_count[0] != 0xff)) {        // SDH 22-02-05 EXCESS
                            plldbrec.item_status[0] = 'P';                  // SDH 22-02-05 EXCESS
                        }                                                   // SDH 22-02-05 EXCESS
                    } else if ((plldbrec.time_sf_count[0] != 0xff) &&       // SDH 22-02-05 EXCESS
                               (plldbrec.time_bs_count[0] != 0xff)) {       // SDH 22-02-05 EXCESS
                        plldbrec.item_status[0] = 'P';                      // SDH 22-02-05 EXCESS
                        //Also set the item as picked if we're in the final     // SDH 22-02-05 EXCESS
                        //location as we'll not get another chance to flag it   // SDH 22-02-05 EXCESS
                        //pllolrec.cLocation field shown in brackets            // SDH 22-02-05 EXCESS
                        //       GAP         PLC         PLC                    // SDH 22-02-05 EXCESS
                        //       ---         ---         ---                    // SDH 22-02-05 EXCESS
                        // SM/FF SF(S/F)->  BS(S/F) -->   OS (O)                // SDH 07-07-05 EXCESS
                        // EXC    BS(E)-->    SF(E) -->   OS (C)                // SDH 07-07-05 EXCESS
                        // EXC    OS(D)-->    SF(D) -->   BS (B)                // SDH 07-07-05 EXCESS
                    } else if ((pllolrec.cLocation == 'B') ||               // SDH 22-02-05 EXCESS
                               (pllolrec.cLocation == 'C') ||               // SDH 22-02-05 EXCESS
                               (pllolrec.cLocation == 'O')) {               // SDH 22-02-05 EXCESS
                        plldbrec.item_status[0] = 'P';                      // SDH 22-02-05 EXCESS
                    }                                                       // SDH 22-02-05 EXCESS

                    if (plldbrec.item_status[0] != 'P') {                   // SDH 22-02-05 EXCESS
                        fDecrementItemCount = FALSE;                        // SDH 22-02-05 EXCESS
                    }                                                       // SDH 22-02-05 EXCESS

                    //Write PLLDB unlock                                    // SDH 22-02-05 EXCESS
                    rc2 = WritePlldbUnlock(__LINE__);                       // SDH 22-02-05 EXCESS
                    if (rc2 <= 0L) {                                        // SDH 22-02-05 EXCESS
                        prep_nak("ERRORUnable to write (unlock) PLLDB. "    //SDH 23-Aug-2006 Planners
                                  "Check appl event logs" );                // SDH 22-02-05 EXCESS
                        break;                                              // SDH 22-02-05 EXCESS
                    }                                                       // SDH 22-02-05 EXCESS

                    //Save these for later                                  // SDH 22-02-05 EXCESS
                    wOssrCount = satoi(plldbrec.ossr_count,                 // SDH 22-02-05 EXCESS
                                       sizeof(plldbrec.ossr_count));        // SDH 22-02-05 EXCESS
                    wShelfCount = satoi(plldbrec.qty_on_shelf,              // SDH 22-02-05 EXCESS
                                        sizeof(plldbrec.qty_on_shelf));     // SDH 22-02-05 EXCESS
                    wBackCount = satoi(plldbrec.stock_room_count,           // SDH 22-02-05 EXCESS
                                       sizeof(plldbrec.stock_room_count));  // SDH 22-02-05 EXCESS

                    // Update PLLOL record if the item has just been picked // SDH 11-01-2005 OSSR WAN
                    // for the first time, by decrementing the item count   // SDH 11-01-2005 OSSR WAN
                    if (fDecrementItemCount) {                              // SDH 11-01-2005 OSSR WAN

                        // Decrement the count (ensure doesn't go negative) // SDH 11-01-2005 OSSR WAN
                        wTemp = _max(satoi(pllolrec.item_count, 4) - 1, 0); // SDH 11-01-2005 OSSR WAN
                        sprintf(sbuf, "%04d", wTemp);                       // SDH 11-01-2005 OSSR WAN
                        memcpy(pllolrec.item_count, sbuf, 4);               // SDH 11-01-2005 OSSR WAN

                        //We read the PLLOL earlier                         // SDH 22-02-05 EXCESS
                        rc2 = WritePllol(wListId, __LINE__);                // SDH 11-01-2005 OSSR WAN
                        if (rc2 <= 0L) {
                            prep_nak("ERRORUnable to write to PLLOL. "      //SDH 23-Aug-2006 Planners
                                      "Check appl event logs" );
                            break;
                        }

                    }
                }                                                           // 19-02-04 PAB

                //Start of STKMQ update processing                          // SDH 22-02-2005 EXCESS
                //If Shelf Monitor or Excess Stock then                     // SDH 07-07-2005 EXCESS
                //  If Item Picked or Fast Count then                       // SDH 07-07-2005 EXCESS
                if ((pPLC->gap_flag[0] == 'Y') || fExcessList) {            // SDH 07-07-2005 EXCESS
                    if ((plldbrec.item_status[0] == 'P') || (wListId == 0)) {// SDH 07-07-2005 EXCESS

                        //Only use the saved sales figures if the shop
                        //floor has been counted
                        if ((wListId != 0) &&                               // SDH 22-02-2005 EXCESS
                            (plldbrec.time_sf_count[0] != 0xFF)) {          // SDH 22-02-2005 EXCESS
                            sales_figure = satol(plldbrec.sales_figure, 4);       
                            items_sold_today = satol(enqbuf.items_sold_today, 6);
                            // if this is a fast count there is no sales    // 19-02-04 PAB
                            // history nullify the variable for the variance// 19-02-04 PAB
                            //calc is correct                               // 19-02-04 PAB
                        } else {                                            // 19-02-04 PAB
                            sales_figure = 0;                               // 19-02-04 PAB
                            items_sold_today = 0;                           // 19-02-04 PAB
                            wShelfCount = 0;                                // 19-02-04 PAB
                            wBackCount = satoi(pPLC->count,                 // SDH 22-02-2005 EXCESS
                                               sizeof(pPLC->count));        // SDH 22-02-2005 EXCESS
                            wOssrCount = 0;                                 // SDH 22-02-2005 EXCESS
                        }                                                   // 19-02-04 PAB

                        if (debug) {
                            sprintf(msg, "1 - Current Stock Figure : %ld",
                                    lStockFigure);                          // SDH 22-02-2005 EXCESS
                            disp_msg(msg);
                            sprintf(msg, "2 - Shop Floor Count     : %d",
                                    wShelfCount);                    
                            disp_msg(msg);
                            sprintf(msg, "3 - Back Shop Count      : %d",
                                    wBackCount);
                            disp_msg(msg);
                            sprintf(msg, "4 - OSSR Count           : %d",
                                    wOssrCount);
                            disp_msg(msg);
                            sprintf(msg, "5 - Sales at Shop Count  : %ld",
                                    sales_figure );
                            disp_msg(msg);
                            sprintf(msg, "6 - items_sold_today     : %ld",
                                    items_sold_today );
                            disp_msg(msg);
                        }

                        variance = items_sold_today - sales_figure;
                        new_count = wShelfCount + wBackCount + wOssrCount - variance;
                        mismatch_qty = abs(lStockFigure - new_count);
                        mismatch_val = abs(mismatch_qty * satol( enqbuf.item_price, 6 ));

                        if (debug) {
                            sprintf( msg, "6 - variance     : %ld",
                                     variance );
                            disp_msg(msg);
                            sprintf( msg, "7 - new count    : %ld",
                                     new_count );
                            disp_msg(msg);
                            sprintf( msg, "8 - mismatch_qty : %ld",
                                     mismatch_qty );
                            disp_msg(msg);
                            sprintf( msg, "9 - mismatch_val : %ld",
                                     mismatch_val );
                            disp_msg(msg);
                        }

                        if (wListId == 0) {                                 // SDH 03-02-2005 UPWARDS TSF
                            usrrc = open_minls();                           // 24-02-04 PAB
                            if (usrrc<=RC_DATA_ERR) {                       // 24-02-04 PAB
                                prep_nak("ERRORUnable to open MINLS file. " //SDH 23-Aug-2006 Planners
                                          "Check appl event logs" );        // 24-02-04 PAB
                                break;                                      // 24-02-04 PAB
                            }
                        }

                        //Read the MINLS and handle any errors
                        pack( minlsrec.boots_code, 4, pPLC->boots_code, 7, 1 );
                        rc2 = ReadMinls(__LINE__);                          // SDH 14-03-2005 EXCESS
                        if (rc2<=0L) {
                            if ((rc2&0xFFFF)==0x06C8 || (rc2&0xFFFF)==0x06CD) {
                                minls.present=FALSE;
                            } else {
                                prep_nak("ERRORUnable to read from MINLS. " //SDH 23-Aug-2006 Planners
                                          "Check appl event logs" );
                                //Close MINLS if a fast count
                                if (wListId == 0) close_minls(CL_SESSION);  // 24-02-04 PAB
                                break;
                            }
                        } else {
                            minls.present=TRUE;
                        }

                        //Is there a count pending -- as shown on the IDF?
                        count_pending = ((enqbuf.idf_bit_flags_2 & 0x04)!=0);
                        if (debug) {
                            sprintf(msg, "count pending : %d", count_pending);
                            disp_msg(msg);
                        }

                        //Ignore the count pending flag for picks           // 09-03-05 SDH OSSR WAN
                        if (wListId != 0) count_pending = 0;                // 09-03-05 SDH OSSR WAN

                        //Get the recount date as a Julian
                        if (minls.present) {
                            unpack( sbuf, 6, minlsrec.recount_date, 3, 0 );
                            day   = satol( sbuf+4, 2 );
                            month = satol( sbuf+2, 2 );
                            year  = satol( sbuf,   2 );
                            year += ((year>84L)?1900L:2000L);
                            dMinlsRecountJul = ConvGJ( day, month, year );  // 15-9-04 PAB
                        } else {
                            dMinlsRecountJul = dTodayJul;
                        }

                        if (debug) {
                            ConvJG( dMinlsRecountJul, &day, &month, &year );
                            sprintf( msg, "Recount for item expected on %02ld/%02ld/%04ld (jd:%9.2f)",
                                     day, month, year, dMinlsRecountJul );
                            disp_msg(msg);
                        }

                        if ((!minls.present && !count_pending) ||
                            (minls.present                 &&
                             minlsrec.count_status[0]=='2' &&
                             dMinlsRecountJul <= dTodayJul   ) ||
                            (lStockFigure <= -1 )              ||           // 10-3-2005 SDH EXCESS
                            (new_count == 0)) {                             //  5-7-2004 PAB new count is zero

                            // Write record to MINLS
                            if (!minls.present) {
                                memset( minlsrec.boots_code, 0x00, 4 );
                                pack( minlsrec.boots_code, 4,
                                      ((LRT_PLC *)(inbound))->boots_code, 7, 1 );
                                memset( minlsrec.recount_date, 0x00, 3);    // 15-9-04 PAB
                                sprintf( sbuf, "%06ld", mismatch_qty );
                                pack( minlsrec.discrepancy, 3, sbuf, 6, 0 );
                                //Always set the MINLS rec                  //SDH 09-02-2005 UPWARDS TSF
                                //type to 3, unless its an item with no     //SDH 09-02-2005 UPWARDS TSF
                                //count pending, a +ve TSF, a -ve adj.      //SDH 09-02-2005 UPWARDS TSF
                                //(We also ASSUME that the item is NOT      //SDH 09-02-2005 UPWARDS TSF
                                // on the NEGSC)                            //SDH 09-02-2005 UPWARDS TSF
                                if ((count_pending)      ||                 //SDH 09-02-2005 UPWARDS TSF
                                    (lStockFigure <= -1) ||                 //SDH 09-02-2005 UPWARDS TSF
                                    (new_count >= lStockFigure)) {          //SDH 09-02-2005 UPWARDS TSF
                                    minlsrec.count_status[0] = '3';         //SDH 09-02-2005 UPWARDS TSF
                                } else {                                    //SDH 09-02-2005 UPWARDS TSF
                                    minlsrec.count_status[0] = '1';         //SDH 09-02-2005 UPWARDS TSF
                                }                                           //SDH 09-02-2005 UPWARDS TSF
                            }                                               //SDH 09-02-2005 UPWARDS TSF

                            // minls status 1 = initial count
                            // minls status 2 = pending recount
                            // minls status 3 = recount
                            // minls status 4 = count complete

                            //*minlsrec.count_status = 
                            //    ( (!minls.present && !count_pending) ?'1':'3');


                            //Force the record type to '3' for a fast count // SDH 03-02-2005 UPWARDS TSF
                            if (*minlsrec.count_status == '2') {            // SDH 03-02-2005 UPWARDS TSF
                                *minlsrec.count_status = '3';               // 16-9-04 PAB
                            }

                            if ((*minlsrec.count_status == '3') && 
                                (minlsrec.recount_date[1] == 0x00 )) {      // 16-9-04 PAB
                                //we have a recount with no date. Set       // 16-9-04 PAB
                                //recount date to today                     // 16-9-04 PAB
                                ConvJG(dTodayJul, &day, &month, &year);     // 16-9-04 PAB
                                sprintf(sbuf, "%02d", (UBYTE)(year%100L));  // 16-9-04 PAB
                                pack(minlsrec.recount_date, 1, sbuf, 2, 0); // 16-9-04 PAB
                                sprintf(sbuf, "%02d", (UBYTE)(month));      // 16-9-04 PAB
                                pack(minlsrec.recount_date+1, 1, sbuf, 2, 0);//16-9-04 PAB
                                sprintf(sbuf, "%02d", (UBYTE)(day));        // 16-9-04 PAB
                                pack(minlsrec.recount_date+2, 1, sbuf, 2, 0);//16-9-04 PAB                                
                            }

                            //Should we check the result?                   // SDH 14-03-2005 EXCESS
                            WriteMinls(__LINE__);                           // SDH 14-03-2005 EXCESS

                            usrrc = open_stkmq();
                            if (usrrc<=RC_DATA_ERR) {
                                prep_nak("ERRORUnable to open STKMQ file. " //SDH 23-Aug-2006 Planners
                                          "Check appl event logs" );
                                //Close MINLS if a fast count               // SDH 03-02-2005 UPWARDS TSF
                                if (wListId == 0) {                         // SDH 03-02-2005 UPWARDS TSF
                                    usrrc = close_minls( CL_SESSION);       // SDH 03-02-2005 UPWARDS TSF
                                }                                           // SDH 03-02-2005 UPWARDS TSF
                                break;
                            }

                            BYTE cStkmqType;                                // SDH 06-04-2005 UPWARDS TSF
                            if (minlsrec.count_status[0] == '1') {          // SDH 03-02-2005 UPWARDS TSF
                                cStkmqType = 'C';                           // SDH 03-02-2005 UPWARDS TSF
                            } else {                                        // SDH 03-02-2005 UPWARDS TSF
                                cStkmqType = 'R';                           // SDH 03-02-2005 UPWARDS TSF
                            }                                               // SDH 03-02-2005 UPWARDS TSF

                            // Write type 13 record to STKMQ
                            count_accepted = TRUE;                          // 15-9-04 PAB
                            stkmqrec[0] = 0x22;                             // SDH 03-02-2005 UPWARDS TSF
                            stkmqrec[1] = 0x13;                             // SDH 03-02-2005 UPWARDS TSF
                            stkmqrec[2] = 0x3B;                             // SDH 03-02-2005 UPWARDS TSF
                            sysdate( &day, &month, &year, &hour, &min, &sec );            
                            sprintf( sbuf, "%02ld%02ld%02ld", year%100, month, day );
                            pack( stkmqrec+3, 3, sbuf, 6, 0 );

                            sprintf( sbuf, "%02d%02d%02d", hour, min, (WORD)sec );
                            pack( stkmqrec+6, 3, sbuf, 6, 0 );
                            pack( stkmqrec+23, 2, sbuf, 4, 0 );             // SDH 03-02-2005 UPWARDS TSF

                            memcpy( stkmqrec+9, "000000", 6 ); 
                            stkmqrec[15] = cStkmqType;                      // SDH 03-02-2005 UPWARDS TSF
                            pack( stkmqrec+16, 4,
                                  ((LRT_PLC *)(inbound))->boots_code, 7, 1 );
                            sprintf( sbuf, "%02ld%02ld%02ld", day, month, year%100 );
                            pack( stkmqrec+20, 3, sbuf, 6, 0 );

                            memset( stkmqrec+25, 0x00, 5);
                            pack( stkmqrec+25+2, 3, enqbuf.item_price, 6, 0 );
                            memset( stkmqrec+31-1, 0x3B, 1 );
                            sprintf( sbuf, "%04ld%cXXXX%c%c%c",
                                     new_count, 0x3B, 0x22, 0x0D, 0x0A );
                            memcpy( stkmqrec+31, sbuf, 16 );

                            if (debug) {
                                sprintf(msg, "WR STKMQ :");
                                disp_msg(msg);
                                dump( (BYTE *)&stkmqrec, STKMQ_T13_LTH );
                            }
                            rc2 = s_write( A_EOFOFF, stkmq.fnum, (void *)&stkmqrec,
                                           STKMQ_T13_LTH, 0L );
                            if (rc2<=0) {
                                log_event101(rc2, STKMQ_REP, __LINE__);
                                if (debug) {
                                    sprintf(msg, "Err-W to STKMQ. RC:%08lX", rc2);
                                    disp_msg(msg);
                                }
                                prep_nak("ERRORUnable to "
                                          "write to STKMQ. "
                                          "Check appl event logs" );
                                break;
                            }
                            if (debug) disp_msg("Write STKMQ OK");
                            close_stkmq( CL_SESSION );

                        }                                                   // endif - write STKMQ & MINLS record
                    }                                                       //SDH 07-07-05 EXCESS STOCK
                }                                                           //SDH 07-07-05 EXCESS STOCK

                //Get counts as integers                                    //SDH 25-01-2005 OSSR WAN
                //Belt & braces: force the item to non-OSSR                 //SDH 25-01-2005 OSSR WAN
                //if not an OSSR store                                      //SDH 25-01-2005 OSSR WAN
                wOssrCount = satoi(plldbrec.ossr_count,                     //SDH 25-01-2005 OSSR WAN
                                   sizeof(plldbrec.ossr_count));            //SDH 25-01-2005 OSSR WAN
                wShelfCount = satoi(plldbrec.qty_on_shelf,                  //SDH 25-01-2005 OSSR WAN
                                    sizeof(plldbrec.qty_on_shelf));         //SDH 25-01-2005 OSSR WAN
                wBackCount = satoi(plldbrec.stock_room_count,               //SDH 25-01-2005 OSSR WAN
                                   sizeof(plldbrec.stock_room_count));      //SDH 25-01-2005 OSSR WAN
                BOOLEAN fTrueGap = FALSE;                                   //SDH 25-01-2005 OSSR WAN
                if (rfscfrec1and2.ossr_store != 'W') enqbuf.cOssrItem = 'N';    //SDH 25-01-2005 OSSR WAN

                //Determine whether the gap is a true gap.                  //SDH 25-01-2005 OSSR WAN
                //Don't gap excess stock lists                              //SDH 07-07-2005 EXCESS
                if ((plldbrec.gap_flag[0] == 'Y') &&                        //SDH 25-01-2005 OSSR WAN
                    (!fExcessList)                &&                        //SDH 07-07-2005 EXCESS
                    (wShelfCount == 0)            &&                        //SDH 25-01-2005 OSSR WAN
                    (wBackCount  == 0)            &&                        //SDH 25-01-2005 OSSR WAN
                    (wOssrCount  == 0)) {                                   //SDH 25-01-2005 OSSR WAN
                    //Its gotta be a gap everywhere if its not an OSSR item,//SDH 25-01-2005 OSSR WAN
                    //or if its been counted in the OSSR                    //SDH 25-01-2005 OSSR WAN
                    if ((enqbuf.cOssrItem != 'Y') ||                        //SDH 25-01-2005 OSSR WAN
                        (plldbrec.time_ossr_count[0] != 0xff)) {            //SDH 25-01-2005 OSSR WAN
                        fTrueGap = TRUE;                                    //SDH 25-01-2005 OSSR WAN
                    }                                                       //SDH 25-01-2005 OSSR WAN
                }                                                           //SDH 25-01-2005 OSSR WAN

                //Build GAPBF record if it's a true gap                     //SDH 25-01-2005 OSSR WAN
                if (fTrueGap) {                                             //SDH 25-01-2005 OSSR WAN
                    memcpy(gapbfrec, "\"000000000000\"\r\n", 16);           //SDH 25-01-2005 OSSR WAN
                    memcpy(gapbfrec + 7, pPLC->boots_code, 6);              //SDH 25-01-2005 OSSR WAN
                    if (debug) {                                            //SDH 25-01-2005 OSSR WAN
                        disp_msg( "WR GAPBF IN PLC:" );                     //SDH 25-01-2005 OSSR WAN
                        dump(gapbfrec, 16);                                 //SDH 25-01-2005 OSSR WAN
                    }                                                       //SDH 25-01-2005 OSSR WAN
                    rc2 = s_write( A_FLUSH | A_FPOFF, lrtp[hh_unit]->fnum2, //SDH 25-01-2005 OSSR WAN
                                   (void *)&gapbfrec, 16L, 0L );            //SDH 25-01-2005 OSSR WAN
                    if (rc2<0L) {                                           //SDH 25-01-2005 OSSR WAN
                        if (debug) {                                        //SDH 25-01-2005 OSSR WAN
                            sprintf(msg, "Err-W to %s. RC:%08lX",           //SDH 25-01-2005 OSSR WAN
                                    pq[lrtp[hh_unit]->pq_sub2].fname, rc2); //SDH 25-01-2005 OSSR WAN 
                            disp_msg(msg);                                  //SDH 25-01-2005 OSSR WAN
                        }                                                   //SDH 25-01-2005 OSSR WAN
                        prep_nak("ERRORUnable to "                          //SDH 25-Aug-2006 Planners
                                  "write to GAPBF. "                        //SDH 25-01-2005 OSSR WAN
                                  "Check appl event logs" );                //SDH 25-01-2005 OSSR WAN
                        //Close MINLS if a fast count                       //SDH 25-01-2005 OSSR WAN
                        if (wListId == 0) usrrc = close_minls(CL_SESSION);  //SDH 25-01-2005 OSSR WAN
                        break;                                              //SDH 25-01-2005 OSSR WAN
                    }                                                       //SDH 25-01-2005 OSSR WAN
                }                                                           //SDH 25-01-2005 OSSR WAN

                // 15-9-04 PAB                                              // 15-9-04 PAB
                if (count_accepted == TRUE) {                               // 15-9-04 PAB
                    prep_ack("");                                           //SDH 23-Aug-2006 Planners
                } else {                                                    // 15-9-04 PAB

                    //Count not accepted.  If a count was pending then      // SDH 16-02-2005 UPWARDS TSF
                    //delete any MINLS record                               // SDH 16-02-2005 UPWARDS TSF
                    if (count_pending) {                                    // SDH 16-02-2005 UPWARDS TSF
                        pack(minlsrec.boots_code, 4,                        // SDH 16-02-2005 UPWARDS TSF
                             pPLC->boots_code, 7, 1);                       // SDH 16-02-2005 UPWARDS TSF
                        rc2 = s_special(0x74, 0, minls.fnum,                // SDH 16-02-2005 UPWARDS TSF
                                        minlsrec.boots_code, MINLS_KEYL,    // SDH 16-02-2005 UPWARDS TSF
                                        0L, 0L);                            // SDH 16-02-2005 UPWARDS TSF
                        if (debug) {                                        // SDH 16-02-2005 UPWARDS TSF
                            if (rc2 < 0L) {                                 // SDH 16-02-2005 UPWARDS TSF
                                sprintf(msg, "MINLS record delete error.  " // SDH 16-02-2005 UPWARDS TSF
                                        "RC:%08lX", rc2);                   // SDH 16-02-2005 UPWARDS TSF
                            } else {                                        // SDH 16-02-2005 UPWARDS TSF
                                strcpy(msg, "MINLS record deleted.");       // SDH 16-02-2005 UPWARDS TSF
                            }                                               // SDH 16-02-2005 UPWARDS TSF
                            disp_msg(msg);                                  // SDH 16-02-2005 UPWARDS TSF
                        }                                                   // SDH 16-02-2005 UPWARDS TSF
                    }                                                       // SDH 16-02-2005 UPWARDS TSF

                    if ((dMinlsRecountJul > dTodayJul) &&                   // 15-9-04 PAB
                        (new_count != lStockFigure)) {                      // 15-9-04 PAB
                        //Don't assume that day/month/year still contain    // SDH 16-02-2005 UPWARDS TSF
                        //the expected vars                                 // SDH 16-02-2005 UPWARDS TSF
                        ConvJG(dMinlsRecountJul, &day, &month, &year);      // SDH 16-02-2005 UPWARDS TSF
                        sprintf( msg, "Count rejected. Recount for item "   // 15-9-04 PAB
                                 "not expected until %02ld/%02ld/%04ld",    // 15-9-04 PAB
                                 day, month, year );                        // SDH 16-02-2005 UPWARDS TSF
                    } else if ((minls.present) &&                           // 15-9-04 PAB
                               (*minlsrec.count_status == '1')) {           // 15-9-04 PAB
                        sprintf (msg, "A previous count is still "          // 15-9-04 PAB
                                 "being processed for this item");          // 15-9-04 PAB
                    } else if (count_pending) {                             // SDH 09-03-2005 OSSR WAN
                        sprintf ( msg, "Count rejected: head office "       // SDH 09-03-2005 OSSR WAN
                                  "count pending.\nCheck HO count list.");  // SDH 09-03-2005 OSSR WAN
                    } else {                                                // 15-9-04 PAB
                        sprintf ( msg, "Count rejected. Could not be "      // 15-9-04 PAB
                                  "processed at this time.");               // 15-9-04 PAB
                    }                                                       // 15-9-04 PAB
                    prep_nak(msg );                                         //SDH 25-Aug-2006 Planners
                }                                                           // 15-9-04 PAB

                //Close MINLS if a fast count                               // SDH 26-11-04 CREDIT CLAIM
                if (wListId == 0) usrrc = close_minls( CL_SESSION);         // SDH 26-11-04 CREDIT CLAIM

            }                                                               // SDH 26-11-04 CREDIT CLAIM

            break;

            //-------------------------------------------------------------------------
        case CMD_PLX:                                                       // Picking list sign off
            {                                                               // SDH 22-02-2005 EXCESS

                LRT_PLX* pPLX = (LRT_PLX*)inbound;                          // SDH 22-02-2005 EXCESS

                if (IsHandheldUnknown()) break;                             // SDH 26-11-04 CREDIT CLAIM
                UpdateActiveTime();                                         // SDH 26-11-04 CREDIT CLAIM

                // Read pllol record                                        
                list_id = satol(pPLX->list_id, 3);                          // SDH 22-02-2005 EXCESS
                rc2 = ReadPllol(list_id, __LINE__);                         // SDH 26-11-04 CREDIT CLAIM
                if (rc2<=0L) {
                    prep_nak("ERRORUnable to "                              //SDH 25-Aug-2006 Planners
                              "read from PLLOL. "
                              "Check appl event logs" );
                    break;
                }

                //Update current location for logging                       // SDH 12-01-2005 OSSR WAN
                if ((pllolrec.cLocation == 'O') ||                          // SDH 22-02-2005 EXCESS
                    (pllolrec.cLocation == 'C')) {                          // SDH 22-02-2005 EXCESS
                    lrtp[hh_unit]->bLocation = 'O';                         // SDH 22-02-2005 EXCESS
                } else {                                                    // SDH 22-02-2005 EXCESS
                    lrtp[hh_unit]->bLocation = 'S';                         // SDH 22-02-2005 EXCESS
                }                                                           // SDH 22-02-2005 EXCESS

                // Update pllol record                                     
                if (pPLX->complete[0] == 'Y') {
                    pllolrec.list_status[0] = 'P';                          // Status : Picked
                    sysdate( &day, &month, &year, &hour, &min, &sec );     
                    sprintf( sbuf, "%02d%02d", hour, min );                
                    memcpy( pllolrec.pick_end_time, sbuf, 4 );             
                    //Assigned to OSSR, set back to unpicked                    // SDH 12-01-2005 OSSR WAN
                } else if (pPLX->complete[0] == 'O') {                      // SDH 12-01-2005 OSSR WAN
                    pllolrec.cLocation = 'O';                               // SDH 12-01-2005 OSSR WAN
                    pllolrec.list_status[0] = 'U';                          // SDH 12-01-2005 OSSR WAN
                } else if (pPLX->complete[0] == 'B') {                      // SDH 23-02-2005 EXCESS
                    pllolrec.cLocation = 'B';                               // SDH 23-02-2005 EXCESS
                    pllolrec.list_status[0] = 'U';                          // SDH 23-02-2005 EXCESS
                    usrrc = SetListUnpicked(list_id);                       // SDH 23-05-2005 EXCESS
                    if (usrrc!=RC_OK) {                                     // SDH 23-05-2005 EXCESS
                        prep_nak("ERRORCannot access PLLDB. "//SDH 25-Aug-2006 Planners
                                 "Check appl event logs" );                 // SDH 23-05-2005 EXCESS
                        break;                                              // SDH 23-05-2005 EXCESS
                    }                                                       // SDH 23-05-2005 EXCESS
                } else if (pPLX->complete[0] == 'C') {                      // SDH 23-02-2005 EXCESS
                    pllolrec.cLocation = 'C';                               // SDH 23-02-2005 EXCESS
                    pllolrec.list_status[0] = 'U';                          // SDH 23-02-2005 EXCESS
                    usrrc = SetListUnpicked(list_id);                       // SDH 23-05-2005 EXCESS
                    if (usrrc!=RC_OK) {                                     // SDH 23-05-2005 EXCESS
                        prep_nak("ERRORCannot access PLLDB. "//SDH 25-Aug-2006 Planners
                                 "Check appl event logs" );                 // SDH 23-05-2005 EXCESS
                        break;                                              // SDH 23-05-2005 EXCESS
                    }                                                       // SDH 23-05-2005 EXCESS
                } else {                                                    // New
                    pllolrec.list_status[0] = ' ';                          // Status : Inactive
                }                                                           // New

                // Following section made unconditional
                rc2 = WritePllol(list_id, __LINE__);                        // SDH 26-11-04 CREDIT CLAIM
                if (rc2 <= 0L) {
                    prep_nak("ERRORUnable to "
                              "write to PLLOL. "
                              "Check appl event logs" );
                    break;
                }

                //Do both just in case                                      // SDH 08-05-2006 Bug fix
                process_workfile( hh_unit, SYS_LAB );                       // SDH 08-05-2006 Bug fix
                process_workfile( hh_unit, SYS_GAP );                       // SDH 08-05-2006 Bug fix
                
                prep_ack("");                                               //SDH 23-Aug-2006 Planners

                // Audit                                                     
                memset( ((LRTLG_PLX *)dtls)->resv, 0x00, 11 );
                lrt_log(LOG_PLX, hh_unit, dtls);                            // SDH 19-01-2005 OSSR WAN
            }

            break;

            //-------------------------------------------------------------------------
        case CMD_PLF:                                                       // Picking list sign off

            if (IsHandheldUnknown()) break;                                 // SDH 26-11-04 CREDIT CLAIM
            UpdateActiveTime();                                             // SDH 26-11-04 CREDIT CLAIM

            close_minls( CL_SESSION );
            close_plldb( CL_SESSION );
            close_pllol( CL_SESSION );

            //Process both just in case                                     // SDH 08-05-2006 Bug fix
            process_workfile( hh_unit, SYS_LAB );                           // SDH 08-05-2006 Bug fix
            process_workfile( hh_unit, SYS_GAP );                           // SDH 08-05-2006 Bug fix

            prep_ack("");                                                   //SDH 23-Aug-2006 Planners


            break;

            //-------------------------------------------------------------------------
        case CMD_PCS:                                                       // Price Check sign on

            if (IsHandheldUnknown()) break;                                 // SDH 26-11-04 CREDIT CLAIM
            if (IsStoreClosed()) break;                                     // SDH 26-11-04 CREDIT CLAIM
            UpdateActiveTime();                                             // SDH 26-11-04 CREDIT CLAIM

            usrrc = prepare_workfile( hh_unit, SYS_LAB );
            if (usrrc<RC_IGNORE_ERR) {
                if (usrrc == RC_DATA_ERR) {
                    prep_nak("ERRORUnable to "
                              "create workfile. "
                              "Check appl event logs" );
                } else {
                    prep_pq_full_nak();                                     // 22-12-04 SDH
                }
                break;
            }

            // Prepare PCR
            memcpy( ((LRT_PCR *)out)->cmd, "PCR", 3 );
            sprintf( sbuf, "%04ld", rfscfrec1and2.pchk_target );            // 16-11-04 SDH
            memcpy( ((LRT_PCR *)out)->pchk_target, sbuf, 4 );
            sprintf( sbuf, "%04ld", rfscfrec1and2.pchk_done );              // 16-11-04 SDH
            memcpy( ((LRT_PCR *)out)->pchk_done, sbuf, 4 );
            out_lth = LRT_PCR_LTH;

            break;

            //-------------------------------------------------------------------------
        case CMD_PCX:                                                       // Price check exit

            if (IsHandheldUnknown()) break;                                 // SDH 26-11-04 CREDIT CLAIM
            UpdateActiveTime();                                             // SDH 26-11-04 CREDIT CLAIM

            //Do both just in case                                          // SDH 08-05-2006 Bug fix
            process_workfile( hh_unit, SYS_LAB );                           // SDH 08-05-2006 Bug fix
            process_workfile( hh_unit, SYS_GAP );                           // SDH 08-05-2006 Bug fix

            prep_ack("");                                                   //SDH 23-Aug-2006 Planners

            // Audit
            ((LRTLG_PCX *)dtls)->items_checked =
            ((LONG)satol( (((LRT_PCX *)(inbound))->items), 4 ));
            ((LRTLG_PCX *)dtls)->sels_printed =
            ((LONG)satol( (((LRT_PCX *)(inbound))->sels), 4 ));
            memset( ((LRTLG_PCX *)dtls)->resv, 0x00, 4 );
            lrt_log( LOG_PCX, hh_unit, dtls );                              // SDH 26-01-2005 

            break;

            //-------------------------------------------------------------------------
        case CMD_INS:                                                       // Information sign on

            if (IsHandheldUnknown()) break;                                 // SDH 26-11-04 CREDIT CLAIM
            if (IsStoreClosed()) break;                                     // SDH 26-11-04 CREDIT CLAIM
            UpdateActiveTime();                                             // SDH 26-11-04 CREDIT CLAIM

            usrrc = prepare_workfile( hh_unit, SYS_LAB );
            if (usrrc<RC_IGNORE_ERR) {
                if (usrrc == RC_DATA_ERR) {
                    prep_nak("ERRORUnable to "
                              "create workfile. "
                              "Check appl event logs" );
                } else {
                    prep_pq_full_nak();                                     // 22-12-04 SDH
                }
                close_wrf( CL_SESSION );
                close_psbt( CL_SESSION );
                break;
            }

            prep_ack("");                                                   //SDH 23-Aug-2006 Planners


            break;

            //-------------------------------------------------------------------------
        case CMD_INX:                                                       // Information exit

            if (IsHandheldUnknown()) break;                                 // SDH 26-11-04 CREDIT CLAIM
            UpdateActiveTime();                                             // SDH 26-11-04 CREDIT CLAIM

            //Do both just in case                                          // SDH 08-05-2006 Bug fix
            process_workfile( hh_unit, SYS_LAB );                           // SDH 08-05-2006 Bug fix
            process_workfile( hh_unit, SYS_GAP );                           // SDH 08-05-2006 Bug fix

            prep_ack("");                                                   //SDH 23-Aug-2006 Planners

            break;

            //-------------------------------------------------------------------------
        case CMD_SSE:                                                       // Information - store sales


            if (strncmp(((LRT_SSE *)(inbound))->opid, "000", 3)==0) {       // 5-7-2004 PAB
                hh_unit = 255;                                              // 20-7-2004 PAB
                // if this request has come from StoreNet USerID 000 then simulate
                // operator sign on processing - allocate hht table entry // 5-7-2004 PAB
                usrrc = alloc_lrt_table( hh_unit );                         // 5-7-2004 PAB
                if (usrrc<RC_IGNORE_ERR) {                                  // 5-7-2004 PAB
                    prep_nak("ERRORUnable to "                              //SDH 23-Aug-2006 Planners
                              "allocate storage. "                          // 5-7-2004 PAB
                              "Check appl event logs" );                    // 5-7-2004 PAB
                    break;                                                  // 5-7-2004 PAB
                }                                                           // 5-7-2004 PAB
                // Log current time                                         // 5-7-2004 PAB
                s_get( T_TD, 0L, (void *)&now, TIMESIZE );                  // 5-7-2004 PAB
                lrtp[hh_unit]->last_active_time = now.td_time;              // 5-7-2004 PAB
                memcpy( (BYTE *)&(lrtp[hh_unit]->txn), (BYTE *)cmd, 3 );    // 5-7-2004 PAB
                memset( (BYTE *)&(lrtp[hh_unit]->unique), 0x00, 5 );        // 5-7-2004 PAB
                                                                            // 5-7-2004 PAB
                // Set state                                                // 5-7-2004 PAB
                lrtp[hh_unit]->state = ST_LOGGED_ON;                        // 5-7-2004 PAB
                // Reset misc counts (Unused at present)                    // 5-7-2004 PAB
                lrtp[hh_unit]->count1 = 0;                                  // 5-7-2004 PAB
                lrtp[hh_unit]->count2 = 0;  
            }


            if (strncmp(((LRT_SSE *)(inbound))->opid, "000", 3)!=0) {       // 5-7-2004 PAB
                if (IsHandheldUnknown()) break;                             // SDH 26-11-04 CREDIT CLAIM
            }


            if (IsStoreClosed()) break;                                     // SDH 26-11-04 CREDIT CLAIM

            // Log current time
            if (strncmp(((LRT_SSE *)(inbound))->opid, "000", 3)!=0) {       // 15-7-2004 PAB
                UpdateActiveTime();                                         // SDH 26-11-04 CREDIT CLAIM
            }
            // 15-7-2004 PAB
            usrrc = open_tsfD();
            if (usrrc<=RC_DATA_ERR) {
                prep_nak("ERRORUnable to open "
                          "EALTERMS file. "
                          "Check appl event logs" );
                break;
            }

            usrrc = open_psbtD();
            if (usrrc<=RC_DATA_ERR) {
                prep_nak("ERRORUnable to open"
                          " PSBTERMS file        "
                          "Check appl event logs" );
                break;
            }

            usrrc = open_wrfD();
            if (usrrc<=RC_DATA_ERR) {
                prep_nak("ERRORUnable to open "
                          "EALWORKG file. "
                          "Check appl event logs" );
                close_psbt( CL_SESSION );
                break;
            }

            usrrc = store_sales_enquiry( (LRT_SSR *)&out );
            if (usrrc < RC_IGNORE_ERR) {
                if (usrrc==RC_FILE_ERR) {
                    prep_nak("ERROROne or more "
                              "files are not open. "
                              "Check appl event logs" );
                } else if (usrrc==RC_DATA_ERR) {
                    prep_nak("ERRORUnable to "
                              "access data. "
                              "Check appl event logs" );
                } else {
                    prep_nak("ERRORUndefined 16. "
                              "Check appl event logs" );
                }
                break;
            }

            // Prepare SSR
            memcpy( ((LRT_SSR *)out)->cmd, "SSR", 3 );
            out_lth = LRT_SSR_LTH;

            close_wrf( CL_SESSION );
            close_psbt( CL_SESSION );
            close_tsf( CL_SESSION );

            if (strncmp(((LRT_SSE *)(inbound))->opid, "000", 3)==0) {         // 5-7-2004 PAB
                // IF BLIND ACCESS FROM STORENET THEN SIMULATE A off COMMAND  // 5-7-4 pab
                // Deallocate handheld's table entry                          // 5-7-2004 PAB
                usrrc = dealloc_lrt_table( hh_unit );                         // 5-7-2004 PAB
            }


            break;

            //-------------------------------------------------------------------------
        case CMD_ISE:                                                       // Information - item sales

            if (strncmp(((LRT_ISE *)(inbound))->opid, "000", 3)!=0) {       // 5-7-2004 PAB
                if (IsHandheldUnknown()) break;                             // SDH 26-11-04 CREDIT CLAIM
            }

            if (strncmp(((LRT_ISE *)(inbound))->opid, "000", 3)==0) {       // 5-7-2004 PAB
                hh_unit = 255;                                              // 20-7-2004 PAB
                // if this request has come from StoreNet USerID 000 then simulate
                // operator sign on processing - allocate hht table entry // 5-7-2004 PAB
                usrrc = alloc_lrt_table( hh_unit );                         // 5-7-2004 PAB
                if (usrrc<RC_IGNORE_ERR) {                                  // 5-7-2004 PAB
                    prep_nak("ERRORUnable to "                              //SDH 23-Aug-2006 Planners
                              "allocate storage. "                          // 5-7-2004 PAB
                              "Check appl event logs" );                    // 5-7-2004 PAB
                    break;                                                  // 5-7-2004 PAB
                }                                                           // 5-7-2004 PAB
                // Log current time                                         // 5-7-2004 PAB
                s_get( T_TD, 0L, (void *)&now, TIMESIZE );                  // 5-7-2004 PAB
                lrtp[hh_unit]->last_active_time = now.td_time;              // 5-7-2004 PAB
                memcpy( (BYTE *)&(lrtp[hh_unit]->txn), (BYTE *)cmd, 3 );    // 5-7-2004 PAB
                memset( (BYTE *)&(lrtp[hh_unit]->unique), 0x00, 5 );        // 5-7-2004 PAB
                                                                            // 5-7-2004 PAB
                // Set state                                                // 5-7-2004 PAB
                lrtp[hh_unit]->state = ST_LOGGED_ON;                        // 5-7-2004 PAB
                // Reset misc counts (Unused at present)                    // 5-7-2004 PAB
                lrtp[hh_unit]->count1 = 0;                                  // 5-7-2004 PAB
                lrtp[hh_unit]->count2 = 0;                                  // 5-7-2004 PAB
                
                //Open IRF
                usrrc = open_irf();                                         // 5-7-2004 PAB
                if (usrrc<=RC_DATA_ERR) {                                   // 5-7-2004 PAB
                    prep_nak("ERRORUnable to open "                         //SDH 23-Aug-2006 Planners
                              "EALITEMR file. "                             // 5-7-2004 PAB
                              "Check appl event logs" );                    // 5-7-2004 PAB
                    break;                                                  // 5-7-2004 PAB
                }                                                           // 5-7-2004 PAB

                //Open IRFDEX
                usrrc = open_irfdex();                                      //SDH 15-01-2005 Promotions
                if (usrrc<=RC_DATA_ERR) {                                   //SDH 15-01-2005 Promotions
                    prep_nak("ERRORUnable to open "                         //SDH 23-Aug-2006 Planners
                              "IRFDEX file. "                               //SDH 15-01-2005 Promotions
                              "Check appl event logs" );                    //SDH 15-01-2005 Promotions
                    close_irf( CL_SESSION );                                //SDH 15-01-2005 Promotions
                    break;                                                  //SDH 15-01-2005 Promotions
                }                                                           //SDH 15-01-2005 Promotions

                //Open IDF
                usrrc = open_idf();                                         // 5-7-2004 PAB
                if (usrrc<=RC_DATA_ERR) {                                   // 5-7-2004 PAB
                    prep_nak("ERRORUnable to open "                         //SDH 23-Aug-2006 Planners
                              "IDF file. "                                  // 5-7-2004 PAB
                              "Check appl event logs" );                    // 5-7-2004 PAB
                    close_irf( CL_SESSION );                                // 5-7-2004 PAB
                    close_irfdex( CL_SESSION );                             // SDH 14-01-2005 Promtions
                    break;                                                  // 5-7-2004 PAB
                }                                                           // 5-7-2004 PAB
                
                //Open ISF
                usrrc = open_isf();                                         // 5-7-2004 PAB
                if (usrrc<=RC_DATA_ERR) {                                   // 5-7-2004 PAB
                    prep_nak("ERRORUnable to open "                         //SDH 23-Aug-2006 Planners
                              "ISF file. "                                  // 5-7-2004 PAB
                              "Check appl event logs" );                    // 5-7-2004 PAB
                    close_idf( CL_SESSION );                                // 5-7-2004 PAB
                    close_irf( CL_SESSION );                                // 5-7-2004 PAB
                    close_irfdex( CL_SESSION );                             // SDH 14-01-2005 Promtions
                    //close_rfscf( CL_SESSION );                             // 5-7-2004 pab
                    break;                                                  // 5-7-2004 PAB
                }                                                           // 5-7-2004 PAB
                
                //Open RFHIST
                usrrc = open_rfhist();                                      // 5-7-2004 PAB
                if (usrrc<=RC_DATA_ERR) {                                   // 5-7-2004 PAB
                    prep_nak("ERROR unable to open "                        //SDH 23-Aug-2006 Planners
                              "RFHIST file. "                               // 5-7-2004 PAB
                              "Check appl event logs" );                    // 5-7-2004 PAB
                    close_idf( CL_SESSION );                                // 5-7-2004 PAB
                    close_irf( CL_SESSION );                                // 5-7-2004 PAB
                    close_irfdex( CL_SESSION );                             // SDH 14-01-2005 Promtions
                    //close_rfscf( CL_SESSION );                             // 5-7-2004 pab
                    close_isf( CL_SESSION );                                // 5-7-2004 PAB
                    break;                                                  // 5-7-2004 PAB
                }                                                           // 5-7-2004 PAB
                
                //Open planner data (ignore errors)                         // SDH 12-Oct-2006 Planners
                open_srpog();                                               // SDH 12-Oct-2006 Planners
                open_srmod();                                               // SDH 12-Oct-2006 Planners
                open_sritml();                                              // SDH 12-Oct-2006 Planners
                open_sritmp();                                              // SDH 12-Oct-2006 Planners
                open_srpogif();                                             // SDH 12-Oct-2006 Planners
                open_srpogil();                                             // SDH 12-Oct-2006 Planners
                open_srpogip();                                             // SDH 12-Oct-2006 Planners
                open_srcat();                                               // SDH 12-Oct-2006 Planners
                open_srsxf();                                               // SDH 12-Oct-2006 Planners

            }

            if (IsStoreClosed()) break;                                     // SDH 26-11-04 CREDIT CLAIM
            UpdateActiveTime();                                             // SDH 26-11-04 CREDIT CLAIM

            usrrc = stock_enquiry( SENQ_DESC,
                                   ((LRT_ISE *)(inbound))->item_code,
                                   &enqbuf );
            if (usrrc < RC_IGNORE_ERR) {
                if (usrrc==RC_FILE_ERR) {
                    prep_nak("ERROROne or more "
                              "files are not open. "
                              "Check appl event logs" );
                } else if (usrrc==RC_DATA_ERR) {
                    prep_nak("ERRORUnable to "
                              "access data. "
                              "Check appl event logs" );
                } else {
                    prep_nak("ERRORUndefined 11. "
                              "Check appl event logs" );
                }
                break;
            }

            if (usrrc==1) {
                // Prepare NAK
                prep_nak("  Item not on file   "
                          "                     "
                          "                     " );
                break;
            }

            memcpy( ((LRT_ISR *)out)->item_desc, enqbuf.item_desc , 20 );

            usrrc = sales_enquiry( enqbuf.boots_code,
                                   (LONG)satol( enqbuf.item_price, 6 ),
                                   (LRT_ISR *)&out );


            if (usrrc<RC_IGNORE_ERR) {
                prep_nak("ERRORUnable to "
                          "action sales enquiry. "
                          "Check appl event logs" );
                break;
            }

            if (strncmp(((LRT_ISE *)(inbound))->opid, "000", 3)==0) {       // 5-7-2004 PAB
                // IF BLIND ACCESS FROM STORENET THEN SIMULATE A off COMMAND// 5-7-4 pab
                close_rfhist( CL_SESSION );                                 // 5-7-2004 PAB
                close_isf( CL_SESSION );                                    // 5-7-2004 PAB
                close_idf( CL_SESSION );                                    // 5-7-2004 PAB
                //close_rfscf( CL_SESSION );                                // 5-7-2004 pab
                close_irf( CL_SESSION );                                    // 5-7-2004 PAB
                close_irfdex( CL_SESSION );                                 // SDH 14-01-2005 Promtions
                
                // Close planner files                                      // SDH 12-Oct-2006 Planners
                close_srpog(CL_SESSION);                                    // SDH 12-Oct-2006 Planners
                close_srmod(CL_SESSION);                                    // SDH 12-Oct-2006 Planners
                close_sritml(CL_SESSION);                                   // SDH 12-Oct-2006 Planners
                close_sritmp(CL_SESSION);                                   // SDH 12-Oct-2006 Planners
                close_srpogif(CL_SESSION);                                  // SDH 12-Oct-2006 Planners
                close_srpogil(CL_SESSION);                                  // SDH 12-Oct-2006 Planners
                close_srpogip(CL_SESSION);                                  // SDH 12-Oct-2006 Planners
                close_srcat(CL_SESSION);                                    // SDH 12-Oct-2006 Planners
                close_srsxf(CL_SESSION);                                    // SDH 12-Oct-2006 Planners
                
                // Deallocate handheld's table entry                        // 5-7-2004 PAB
                usrrc = dealloc_lrt_table( hh_unit );                       // 5-7-2004 PAB
            }

            // Prepare ISR
            memcpy( ((LRT_ISR *)out)->cmd, "ISR", 3 );
            out_lth = LRT_ISR_LTH;

            break;

            //-------------------------------------------------------------------------
        case CMD_RPO:                                                       // Reports - sign on

            if (IsHandheldUnknown()) break;                                 // SDH 26-11-04 CREDIT CLAIM
            if (IsStoreClosed()) break;                                     // SDH 26-11-04 CREDIT CLAIM

            // verify that batch suite is not running
            if (IsReportMntActive()) break;                                 // 4-11-04 PAB

            UpdateActiveTime();                                             // SDH 26-11-04 CREDIT CLAIM

            usrrc = open_rfrdesc();
            if (usrrc<=RC_DATA_ERR) {
                prep_nak("ERRORUnable to open "
                          "RFRDESC file. "
                          "Check appl event logs" );
                break;
            }

            usrrc = prepare_workfile( hh_unit, SYS_LAB );
            if (usrrc<RC_IGNORE_ERR) {
                if (usrrc == RC_DATA_ERR) {
                    prep_nak("ERRORUnable to "
                              "create workfile. "
                              "Check appl event logs" );
                } else {
                    prep_pq_full_nak();                                     // 22-12-04 SDH
                }
                break;
            }

            // Prepare for reporting  
            lrtp[hh_unit]->fnum3 = 0L;                                      // current report file fnum
            if (debug) {
                sprintf(msg, "Allocating report buffer");
                disp_msg(msg);
            }
            usrrc = alloc_report_buffer( (RBUF **)&lrtp[hh_unit]->rbufp );
            if (usrrc<RC_IGNORE_ERR) {
                prep_nak("ERRORUnable to "
                          "allocate storage. "
                          "Check appl event logs" );
                lrtp[hh_unit]->rbufp = NULL;
                break;
            }

            prep_ack("");                                                   //SDH 23-Aug-2006 Planners

            break;

            //-------------------------------------------------------------------------
        case CMD_RLE:                                                       // Reports - get reports

            if (IsHandheldUnknown()) break;                                 // SDH 26-11-04 CREDIT CLAIM
            if (IsStoreClosed()) break;                                     // SDH 26-11-04 CREDIT CLAIM

            // verify that batch suite is not running
            if (IsReportMntActive()) break;                                 // 4-11-04 PAB

            UpdateActiveTime();                                             // SDH 26-11-04 CREDIT CLAIM

            if (lrtp[hh_unit]->rbufp == NULL) {
                prep_nak("ERRORNo report "
                          "buffer allocated. "
                          "Check appl event logs" );
                break;
            }

            // Get next record from RFRDESC
            usrrc = rfrdesc_get_next( /*hh_unit,*/
                                      (BYTE *)((LRT_RLE *)(inbound))->seq,
                                      (LRT_RLR *)out );
            if (usrrc<RC_IGNORE_ERR) {
                if (usrrc == RC_DATA_ERR) {
                    prep_nak("ERRORUnable to "
                              "read from RFRDESC. "
                              "Check appl event logs" );
                } else {
                    prep_nak("ERRORUndefined 12. "
                              "Check appl event logs" );
                }
                break;
            }

            if (usrrc==1) {
                // Record available - Prepare RLR
                memcpy( ((LRT_RLR *)out)->cmd, "RLR", 3 );
                out_lth = LRT_RLR_LTH;
            } else {
                // Record not available - Prepare RLF
                memcpy( ((LRT_RLF *)out)->cmd, "RLF", 3 );
                out_lth = LRT_RLF_LTH;
            }

            break;

            //-------------------------------------------------------------------------
        case CMD_RLS:                                                       // Reports - get level 0s

            if (IsHandheldUnknown()) break;                                 // SDH 26-11-04 CREDIT CLAIM
            if (IsStoreClosed()) break;                                     // SDH 26-11-04 CREDIT CLAIM

            // verify that batch suite is not running
            if (IsReportMntActive()) break;                                 // 4-11-04 PAB

            UpdateActiveTime();                                             // SDH 26-11-04 CREDIT CLAIM

            if (lrtp[hh_unit]->rbufp == NULL) {
                prep_nak("ERRORNo report "
                          "buffer allocated. "
                          "Check appl event logs" );
                break;
            }

            if (satoi(((LRT_RLS *)(inbound))->seq, REPORT_SEQ_SIZE)==0) {
                memcpy( sbuf, ((LRT_RLS *)(inbound))->fname, 12 );
                *(sbuf+12) = 0x00;
                sprintf( tbuf, "RFREP:%12s", sbuf );
                for (i=17;i>0;i--) {
                    if (*(tbuf+i)==0x20) {
                        *(tbuf+i)=0x00;
                    } else {
                        break;
                    }
                }
                // Open file


                if (lrtp[hh_unit]->fnum3!=0L) {
                    s_close( 0, lrtp[hh_unit]->fnum3 );
                    log_file_close ( lrtp[hh_unit]->fnum3 );                // 11-11-04 PAB
                    lrtp[hh_unit]->fnum3 = 0L;
                }
                rc2 = s_open( RFREP_OFLAGS, tbuf );
                if (rc2<=0) {
                    log_event101(rc2, RFREP_REP, __LINE__);
                    memcpy( ((LRT_NAK *)out)->cmd, "NAK", 3 );
                    sprintf( ((LRT_NAK *)out)->msg,
                             "No report "                                   // PAB 29-Nov-2006
                             "available. "                                  // PAB 29-Nov-2006
                             "", tbuf );                                    // PAB 29-Nov-2006
                    out_lth = LRT_NAK_LTH;
                    break;
                }
                // save fnum
                lrtp[hh_unit]->fnum3 = rc2;                                 // 11-11-04 PAB
                log_file_open ( rc2,'R' );
            }

            // if seq is zero then this is a new report select. clear down the old buffer and
            // reallocate a new empty one so when the selected report is empty, and this is
            // not the first report we have browsed the cache is certain to be empty.
            // and we do not send wrong report data.

            if (strncmp(((LRT_RLS *)(inbound))->seq, "0000",4) == 0) {      // 09-11-04 PAB
                // Deallocate report buffer                                 // 09-11-04 PAB
                usrrc = dealloc_report_buffer( lrtp[hh_unit]->rbufp );      // 09-11-04 PAB
                lrtp[hh_unit]->rbufp = (void *)NULL;                        // 09-11-04 PAB
                if (usrrc<RC_IGNORE_ERR) {                                  // 09-11-04 PAB
                    prep_nak("ERRORUnable to "                              //SDH 23-Aug-2006 Planners
                              "deallocate rpt buffer. "                     // 09-11-04 PAB
                              "Check appl event logs" );                    // 09-11-04 PAB
                    break;                                                  // 09-11-04 PAB
                }                                                           // 09-11-04 PAB
                usrrc = alloc_report_buffer( (RBUF **)&lrtp[hh_unit]->rbufp );    // 09-11-04 PAB
                if (usrrc<RC_IGNORE_ERR) {                                  // 09-11-04 PAB
                    prep_nak("ERRORUnable to "                              //SDH 23-Aug-2006 Planners
                              "allocate storage. "                          // 09-11-04 PAB
                              "Check appl event logs" );                    // 09-11-04 PAB
                    lrtp[hh_unit]->rbufp = NULL;                            // 09-11-04 PAB
                    break;                                                  // 09-11-04 PAB
                }                                                           // 09-11-04 PAB
            }                                                               // 09-11-04 PAB

            usrrc = rfrep_get_next_lev0( hh_unit,
                                         ((LRT_RLS *)(inbound))->seq,
                                         (LRT_RLD *)out,
                                         (WORD *)&rec_cnt );
            if (usrrc<RC_IGNORE_ERR) {
                memcpy( tbuf, ((LRT_RLS *)(inbound))->fname, 12 );
                *(tbuf+12) = 0x00;
                if (usrrc == RC_DATA_ERR) {
                    memcpy( ((LRT_NAK *)out)->cmd, "NAK", 3 );
                    sprintf( ((LRT_NAK *)out)->msg,
                             "ERRORUnable to "
                             "read %-12s   0"
                             "Check appl event logs"
                             "*****************", tbuf );
                    out_lth = LRT_NAK_LTH;
                } else {
                    prep_nak("ERRORUndefined 13. "
                              "Check appl event logs" );
                }
                break;
            }

            if (usrrc==1) {
                // Prepare RLD
                memcpy( ((LRT_RLD *)out)->cmd, "RLD", 3 );
                sprintf( sbuf , "%03d", rec_cnt );
                memcpy( ((LRT_RLD *)out)->rpt , sbuf, 3 );
                out_lth = RLD_REP_OFFSET + (rec_cnt * LRT_RLD_REP_LTH);
            } else {
                // Prepare RLF
                memcpy( ((LRT_RLF *)out)->cmd, "RLF", 3 );
                out_lth = LRT_RLF_LTH;
            }

            break;

            //-------------------------------------------------------------------------
        case CMD_RPS:                                                       // Reports - get level 1+

            if (IsHandheldUnknown()) break;                                 // SDH 26-11-04 CREDIT CLAIM
            if (IsStoreClosed()) break;                                     // SDH 26-11-04 CREDIT CLAIM

            // verify that RFMAINT is not running
            if (IsReportMntActive()) break;                                 // 4-11-04 PAB

            UpdateActiveTime();                                             // SDH 26-11-04 CREDIT CLAIM

            usrrc = rfrep_get_next( hh_unit,
                                    ((LRT_RLS *)(inbound))->seq,
                                    (LRT_RUP *)out,
                                    (WORD *)&rec_cnt );
            if (usrrc<RC_IGNORE_ERR) {
                memcpy( tbuf, ((LRT_RLS *)(inbound))->fname, 12 );
                *(tbuf+12) = 0x00;
                if (usrrc == RC_DATA_ERR) {
                    memcpy( ((LRT_NAK *)out)->cmd, "NAK", 3 );
                    sprintf( ((LRT_NAK *)out)->msg,
                             "ERRORUnable to "
                             "read %-12s   +"
                             "Check appl event logs"
                             "*****************", tbuf );
                    out_lth = LRT_NAK_LTH;
                } else {
                    prep_nak("ERRORUndefined 14. "
                              "Check appl event logs" );
                }
                break;
            }

            if (usrrc==1) {
                // Prepare RUP
                memcpy( ((LRT_RUP *)out)->cmd, "RUP", 3 );
                sprintf( sbuf , "%03d", rec_cnt );
                memcpy( ((LRT_RUP *)out)->rpt , sbuf, 3 );
                // RBS RFHHT.EXE expects the whole structure to be sent 
                // regardless of if it is only partially populated TH  28/10/97
                // out_lth = RUP_REP_OFFSET + (rec_cnt * LRT_RUP_REP_LTH);
                out_lth = sizeof ( LRT_RUP ) ;
            } else {
                // Prepare RLF
                memcpy( ((LRT_RLF *)out)->cmd, "RLF", 3 );
                out_lth = LRT_RLF_LTH;
            }

            break;

            //-------------------------------------------------------------------------
        case CMD_RPX:                                                       // Reports exit

            if (IsHandheldUnknown()) break;                                 // SDH 26-11-04 CREDIT CLAIM
            if (IsStoreClosed()) break;                                     // SDH 26-11-04 CREDIT CLAIM
            UpdateActiveTime();                                             // SDH 26-11-04 CREDIT CLAIM

            //Do both just in case                                          // SDH 08-05-2006 Bug fix
            process_workfile( hh_unit, SYS_LAB );                           // SDH 08-05-2006 Bug fix
            process_workfile( hh_unit, SYS_GAP );                           // SDH 08-05-2006 Bug fix

            // Close report file if it's open
            if (lrtp[hh_unit]->fnum3!=0) {
                s_close( 0, lrtp[hh_unit]->fnum3);
                log_file_close ( lrtp[hh_unit]->fnum3 );                    // 11-11-04 PAB
            }
            lrtp[hh_unit]->fnum3 = 0L;


            close_rfrdesc( CL_SESSION );

            // Deallocate report buffer
            usrrc = dealloc_report_buffer( lrtp[hh_unit]->rbufp );
            lrtp[hh_unit]->rbufp = (void *)NULL;
            if (usrrc<RC_IGNORE_ERR) {
                prep_nak("ERRORUnable to "
                          "deallocate rpt buffer. "
                          "Check appl event logs" );
                break;
            }

            prep_ack("");                                                   //SDH 23-Aug-2006 Planners

            break;

            //-------------------------------------------------------------------------
        case CMD_CLO:                                                       // Counting list log on

            if (IsHandheldUnknown()) break;                                 // SDH 26-11-04 CREDIT CLAIM
            if (IsStoreClosed()) break;                                     // SDH 26-11-04 CREDIT CLAIM
            UpdateActiveTime();                                             // SDH 26-11-04 CREDIT CLAIM

            usrrc = open_clolf();
            if (usrrc<=RC_DATA_ERR) {
                prep_nak("ERRORUnable to open "
                          "CLOLF file. "
                          "Check appl event logs" );
                break;
            }
            usrrc = open_clilf();
            if (usrrc<=RC_DATA_ERR) {
                prep_nak("ERRORUnable to open "
                          "CLILF file. "
                          "Check appl event logs" );
                break;
            }

            prep_ack("");                                                   //SDH 23-Aug-2006 Planners

            // v4.0 START
            usrrc = prepare_workfile( hh_unit, SYS_LAB );
            if (usrrc<RC_IGNORE_ERR) {
                if (usrrc == RC_DATA_ERR) {
                    prep_nak("ERRORUnable to "
                              "create workfile. "
                              "Check appl event logs" );
                } else {
                    prep_pq_full_nak();                                     // 22-12-04 SDH
                }
                break;
            }
            // v4.0 END


            break;

            //-------------------------------------------------------------------------
        case CMD_CLR:                                                       // Counting - Get List Of Lists

            if (IsHandheldUnknown()) break;                                 // SDH 26-11-04 CREDIT CLAIM
            UpdateActiveTime();                                             // SDH 26-11-04 CREDIT CLAIM

            // Get next record from CLOLF
            usrrc = clolf_get_next( /*hh_unit,*/
                                    ((LRT_CLR *)(inbound))->list_id,
                                    (LRT_CLL *)out );
            if (usrrc<RC_IGNORE_ERR) {
                if (usrrc == RC_DATA_ERR) {
                    prep_nak("ERRORI/O error. "
                              "Check appl event logs" );
                } else {
                    prep_nak("ERRORUndefined 6. "
                              "Check appl event logs" );
                }
                break;
            }
            if (usrrc==1) {
                // Record available - Prepare CLL
                memcpy( ((LRT_CLL *)out)->cmd, "CLL", 3 );
                out_lth = LRT_CLL_LTH;
            } else {
                // Record not available - Prepare CLE
                memcpy( ((LRT_CLE *)out)->cmd, "CLE", 3 );
                memcpy( ((LRT_CLE *)out)->list_id,
                        ((LRT_CLR *)(inbound))->list_id, 3);                // v2.3
                out_lth = LRT_CLE_LTH;
            }

            break;

            //-------------------------------------------------------------------------
        case CMD_CLS:                                                       // Counting - Get List
            {
                //Set up specific view of input
                LRT_CLS* pCLS = (LRT_CLS*)inbound;                          // SDH 26-11-04 CREDIT CLAIM

                if (IsHandheldUnknown()) break;                             // SDH 26-11-04 CREDIT CLAIM
                if (IsStoreClosed()) break;                                 // SDH 26-11-04 CREDIT CLAIM

                pack((BYTE *)&(lrtp[hh_unit]->unique), 2, pCLS->seq, 3, 1); // SDH 26-11-04 CREDIT CLAIM

                // Read clolf record
                list_id = satol(pCLS->list_id, 3);
                rc2 = s_read( A_BOFOFF,
                              clolf.fnum, (void *)&clolfrec, CLOLF_RECL, 
                              (list_id-1L) * CLOLF_RECL );
                if (rc2<=0L) {
                    log_event101(rc2, CLOLF_REP, __LINE__);
                    if (debug) {
                        sprintf(msg, "Err-R CLOLF o/s %ld. RC:%08lX",
                                (list_id-1L) * CLOLF_RECL, rc2);
                        disp_msg(msg);
                    }
                    prep_nak("ERRORUnable to "
                              "read from CLOLF. "
                              "Check appl event logs" );
                    break;
                }

                // if the list has been submitted to RFSBG or completed by RFSBG// 20-5-4 PAB
                // then block updates                                           // 20-5-4 PAB
                // V4.01 PAB                                                    // 20-5-4 PAB
                if ((clolfrec.list_status[0] == 'C') ||                     // 10-3-2005 SDH OSSR WAN
                    (clolfrec.list_status[0] == 'P')) {                     // 20-5-4 PAB
                    prep_nak("This count List "                             //SDH 23-Aug-2006 Planners
                              "has already been "                           // 20-5-4 PAB
                              "closed for today");                          // 20-5-4 PAB
                    break;                                                  // 20-5-4 PAB
                }                                                           // 20-5-4 PAB
                // end block update to closed count lists    PAB                // 20-5-4 PAB

                //Prevent anyone except the person who was last in the list     // SDH 10-1-2005 OSSR WAN
                //from accessing it, if it is active.                           // SDH 10-1-2005 OSSR WAN
                if (clolfrec.list_status[0] == 'A') {                       // SDH 10-1-2005 OSSR WAN
                    WORD wLastUser = satoi(clolfrec.abUserID, 3);           // SDH 10-1-2005 OSSR WAN
                    WORD wThisUser = satoi(pCLS->opid, 3);                  // SDH 10-1-2005 OSSR WAN
                    if ((wLastUser != wThisUser) && (wLastUser != 0)) {     // SDH 10-1-2005 OSSR WAN
                        sprintf(sbuf, "List already active.\nOnly user ID " // SDH 10-1-2005 OSSR WAN
                                "%.3d can open this list.", wLastUser);     // SDH 10-1-2005 OSSR WAN
                        prep_nak(sbuf);                                     //SDH 23-Aug-2006 Planners
                        break;                                              // SDH 10-1-2005 OSSR WAN
                    }                                                       // SDH 10-1-2005 OSSR WAN
                }                                                           // SDH 10-1-2005 OSSR WAN

                // Update CLOLF status for 1st count sent                       // SDH 10-1-2005 OSSR WAN
                //Also update the user ID                                       // SDH 10-1-2005 OSSR WAN
                if (clolfrec.list_status[0] != 'A') {                       // 20-5-4 PAB
                    clolfrec.list_status[0] = 'A';                          // Status : Active      // 20-5-4 PAB
                    memcpy(clolfrec.abUserID, pCLS->opid,                   // SDH 10-1-2005 OSSR WAN
                           sizeof(clolfrec.abUserID));                      // SDH 10-1-2005 OSSR WAN
                    rc2 = s_write( A_FLUSH | A_BOFOFF, clolf.fnum,
                                   (void *)&clolfrec, CLOLF_RECL,
                                   (list_id-1L) * CLOLF_RECL );
                    if (rc2<=0) {
                        log_event101(rc2, CLOLF_REP, __LINE__);
                        if (debug) {
                            sprintf(msg, "Err-W CLOLF o/s %ld. RC:%08lX",
                                    (list_id-1L) * CLOLF_RECL, rc2);
                            disp_msg(msg);
                        }
                        prep_nak("ERRORUnable to "
                                  "write to CLOLF. "
                                  "Check appl event logs" );
                        break;
                    }
                }

                // Get next record from CLILF
                usrrc = clilf_get_next( /*hh_unit,*/
                                        ((LRT_CLS *)(inbound))->list_id,
                                        ((LRT_CLS *)(inbound))->seq,
                                        (LRT_CLI *)out );
                if (debug) {
                    sprintf(msg, "clilf_get_next() rc=%d", usrrc);
                    disp_msg(msg);
                }
                if (usrrc<RC_IGNORE_ERR) {
                    if (usrrc == RC_DATA_ERR) {
                        prep_nak("ERRORUnable to "
                                  "read from CLILF. "
                                  "Check appl event logs" );
                    } else {
                        prep_nak("ERRORUndefined 7. "
                                  "Check appl event logs" );
                    }
                    break;
                }

                if (usrrc==1) {
                    // v4.0 START
                    // Audit
                    sprintf( msg, "%04ld", list_id );
                    memcpy( ((LRTLG_CLS *)dtls)->list_id, msg , 4 );
                    memset( ((LRTLG_CLS *)dtls)->resv, 0x00, 8 );
                    lrt_log( LOG_CLS, hh_unit, dtls );
                    // v4.0 END
                    // Record available - Prepare CLI
                    memcpy( ((LRT_CLI *)out)->cmd, "CLI", 3 );
                    out_lth = LRT_CLI_LTH;
                } else {
                    // Record not available - Prepare CLE
                    memcpy( ((LRT_CLE *)out)->cmd, "CLE", 3 );
                    out_lth = LRT_CLE_LTH;
                }
            }
            break;


            //-------------------------------------------------------------------------
        case CMD_CLC:                                                       // Counting - List Update Item
            {
                //Init vars                                                 // SDH 26-11-04 CREDIT CLAIM
                LRT_CLC* pCLC = (LRT_CLC*)inbound;                          // SDH 26-11-04 CREDIT CLAIM

                if (IsHandheldUnknown()) break;                             // SDH 26-11-04 CREDIT CLAIM
                if (IsStoreClosed()) break;                                 // SDH 26-11-04 CREDIT CLAIM
                UpdateActiveTime();                                         // SDH 26-11-04 CREDIT CLAIM

                //If we're in an OSSR WAN store then update the OSSR flag   // SDH 17-11-04 OSSR WAN
                //if required                                               // SDH 17-11-04 OSSR WAN
                if ((rfscfrec1and2.ossr_store == 'W') &&                    // SDH 17-11-04 OSSR WAN
                    (pCLC->cUpdateOssrItem != ' ')) {                       // SDH 17-11-04 OSSR WAN
                    usrrc = ProcessRfhist(pCLC->boots_code,                 // SDH 17-11-04 OSSR WAN
                                          pCLC->cUpdateOssrItem, __LINE__); // SDH 17-11-04 OSSR WAN
                    prep_nak("ERRORUnable to "                              //SDH 23-Aug-2006 Planners
                              "update OSSR flag. "                          // SDH 17-11-04 OSSR WAN
                              "Check appl event logs" );                    // SDH 17-11-04 OSSR WAN
                    break;                                                  // SDH 17-11-04 OSSR WAN
                }                                                           // SDH 17-11-04 OSSR WAN

                // Read CLOLF for list header details
                //Handle errors
                if (debug) disp_msg("RD CLOLF :");
                list_id = satol(pCLC->list_id, 3);
                rc2 = s_read( A_BOFOFF, clolf.fnum, (void *)&clolfrec,
                              CLOLF_RECL, (list_id-1L) * CLOLF_RECL );
                if (rc2<=0L) {
                    log_event101(rc2, CLOLF_REP, __LINE__);
                    if (debug) {
                        sprintf(msg, "Err-R CLOLF o/s %ld. RC:%08lX",
                                (list_id-1L) * CLOLF_RECL, rc2);
                        disp_msg(msg);
                    }
                    prep_nak("ERRORUnable to "
                              "read from CLOLF. "
                              "Check appl event logs" );
                    break;
                }

                // Record found
                if (debug) {
                    disp_msg("OK");
                    dump( (BYTE *)&clolfrec, (WORD)CLOLF_RECL );
                }

                // Open and read current IMSTC sales figure
                usrrc = open_imstc();
                if (usrrc!=RC_OK) {
                    prep_nak("ERRORUnable to "
                              "open IMSTC file. "
                              "Check appl event logs" );
                    break;
                }
                memset(imstcrec.bar_code, 0x00, 11);                        // SDH 26-11-04 CREDIT CLAIM
                pack(imstcrec.bar_code+8, 3, pCLC->boots_code, 6, 0);       // SDH 26-11-04 CREDIT CLAIM
                if (debug) {
                    disp_msg ( "RD IMSTC : " );
                    dump ( imstcrec.bar_code, (WORD)IMSTC_KEYL );
                }
                rc2 = s_read( 0, imstc.fnum, (void *)&imstcrec,
                              IMSTC_RECL, IMSTC_KEYL );
                if (rc2<=0L) {
                    if ((rc2&0xFFFF)==0x06C8 || (rc2&0xFFFF)==0x06CD) {
                        imstc.present=FALSE;
                        if (debug) disp_msg("NOF");
                    } else {
                        log_event101(rc, IMSTC_REP, __LINE__);
                        if (debug) {
                            sprintf(msg, "Err-R IMSTC. RC:%08lX", rc2);
                            disp_msg(msg);
                        }
                    }
                } else {
                    imstc.present=TRUE;
                    if (debug) disp_msg("OK");
                }
                close_imstc( CL_SESSION );

                // Read CLILF item record WITH A LOCK
                // Function waits for 250ms for record to be freed
                memcpy(clilfrec.list_id, pCLC->list_id, 3);                 // SDH 26-11-04 CREDIT CLAIM
                memcpy(clilfrec.seq, pCLC->seq, 3);                         // SDH 26-11-04 CREDIT CLAIM
                if (debug) disp_msg("RD CLILF (LOCK) :");
                rc2 = u_read( 1, 0, clilf.fnum, (void *)&clilfrec,
                              CLILF_RECL, CLILF_KEYL, 250 );                // SDH 17-11-04 OSSR WAN
                if (rc2<=0L) {
                    if ((rc2&0xFFFF)==0x06C8 || (rc2&0xFFFF)==0x06CD) {
                        if (debug) disp_msg("NOF");
                    } else {
                        log_event101(rc2, CLILF_REP, __LINE__);
                        if (debug) {
                            sprintf(msg, "Err-R CLILF. RC:%08lX", rc2);
                            disp_msg(msg);
                        }
                    }
                    prep_nak("ERRORUnable to "
                              "read (lk) from CLILF. "
                              "Check appl event logs" );
                    break;
                }
                if (debug) disp_msg("OK");

                // Check we are dealing with the same boots code
                if (memcmp(pCLC->boots_code, clilfrec.boots_code, 7)==0) {  // SDH 26-11-04 CREDIT CLAIM

                    //Format current time                                   // 01-9-04 PAB OSSR
                    BYTE abTimePD[2];                                       // 10-1-2005 SDH OSSR WAN
                    s_get( T_TD, 0L, (void *)&now, TIMESIZE);               // 31-8-04 PAB OSSR
                    min = now.td_time / 60000;                              // 31-8-04 PAB OSSR
                    hour = min / 60;                                        // 31-8-04 PAB OSSR
                    min %= 60;                                              // 31-8-04 PAB OSSR 
                    sprintf(sbuf, "%02d%02d", hour, min);                   // 10-1-2005 SDH OSSR WAN
                    pack(abTimePD, 2, sbuf, 4,0 );                          // 10-1-2005 SDH OSSR WAN

                    //Format current sales (use 0 if no IMSTC)              // 10-1-2005 SDH OSSR WAN
                    BYTE abSales[5];                                        // 10-1-2005 SDH OSSR WAN
                    sprintf(abSales, "%04ld",                               // 10-1-2005 SDH OSSR WAN
                            (imstc.present ? imstcrec.numitems:0) / 100L);  // 1-9-2004 PAB OSSR

                    //Extract various count fields                          // 10-1-2005 SDH OSSR WAN
                    WORD wCurSFCnt = satoi(clilfrec.count_shopfloor,        // 10-1-2005 SDH OSSR WAN
                                           sizeof(clilfrec.count_shopfloor));    //10-1-2005 SDH OSSR WAN
                    WORD wCurBSCnt = satoi(clilfrec.count_backshop,         // 10-1-2005 SDH OSSR WAN
                                           sizeof(clilfrec.count_backshop));    // 10-1-2005 SDH OSSR WAN
                    WORD wCurOSCnt = satoi(clilfrec.abOSSRCount,            // 10-1-2005 SDH OSSR WAN
                                           sizeof(clilfrec.abOSSRCount));   // 10-1-2005 SDH OSSR WAN
                    WORD wNewSFCnt = satoi(pCLC->count_shopfloor,           // 10-1-2005 SDH OSSR WAN
                                           sizeof(pCLC->count_shopfloor));  // 10-1-2005 SDH OSSR WAN
                    WORD wNewBSCnt = satoi(pCLC->count_backshop,            // 10-1-2005 SDH OSSR WAN
                                           sizeof(pCLC->count_backshop));   // 10-1-2005 SDH OSSR WAN
                    WORD wNewOSCnt = satoi(pCLC->abOssrCount,               // 10-1-2005 SDH OSSR WAN
                                           sizeof(pCLC->abOssrCount));      // 10-1-2005 SDH OSSR WAN

                    //If Shop floor count has changed...                    // 10-1-2005 SDH OSSR WAN
                    if ((wNewSFCnt != wCurSFCnt)) {                         // 10-1-2005 SDH OSSR WAN

                        //Set the location to Shop                          // 10-1-2005 SDH OSSR WAN
                        lrtp[hh_unit]->bLocation = 'S';                     // 10-1-2005 SDH OSSR WAN

                        //If it was previously not counted then             // 10-1-2005 SDH OSSR WAN
                        //decrement items remaining                         // 10-1-2005 SDH OSSR WAN
                        if (wCurSFCnt == -1) {                              // 10-1-2005 SDH OSSR WAN
                            WORD wTemp = satoi(clolfrec.items_shopfloor, 3);    // 10-1-2005 SDH OSSR WAN
                            wTemp = _max(wTemp - 1, 0);                     // 10-1-2005 SDH OSSR WAN
                            sprintf(sbuf, "%03d", wTemp);                   // 10-1-2005 SDH OSSR WAN
                            memcpy(clolfrec.items_shopfloor, sbuf, 3);      // 10-1-2005 SDH OSSR WAN
                        }                                                   // 10-1-2005 SDH OSSR WAN

                        //Update the sales and the time                     // 10-1-2005 SDH OSSR WAN
                        memcpy(clilfrec.abTimeSalesCntPD, abTimePD, 2);     // 10-1-2005 SDH OSSR WAN
                        memcpy(clilfrec.sales, abSales,                     // 10-1-2005 SDH OSSR WAN
                               sizeof(clilfrec.sales));                     // 10-1-2005 SDH OSSR WAN
                        memcpy(clilfrec.count_shopfloor,                    // 10-1-2005 SDH OSSR WAN
                               pCLC->count_shopfloor, 4);                   // 10-1-2005 SDH OSSR WAN

                    }                                                       // 10-1-2005 SDH OSSR WAN

                    //If Back Shop count has changed...                     // 10-1-2005 SDH OSSR WAN
                    if ((wNewBSCnt != wCurBSCnt)) {                         // 10-1-2005 SDH OSSR WAN

                        //Set the location to Shop                          // 10-1-2005 SDH OSSR WAN
                        lrtp[hh_unit]->bLocation = 'S';                     // 10-1-2005 SDH OSSR WAN

                        //If it was previously not counted then             // 10-1-2005 SDH OSSR WAN
                        //decrement items remaining                         // 10-1-2005 SDH OSSR WAN
                        if (wCurBSCnt == -1) {                              // 10-1-2005 SDH OSSR WAN
                            WORD wTemp = satoi(clolfrec.items_backshop, 3); // 10-1-2005 SDH OSSR WAN
                            wTemp = _max(wTemp - 1, 0);                     // 10-1-2005 SDH OSSR WAN
                            sprintf(sbuf, "%03d", wTemp);                   // 10-1-2005 SDH OSSR WAN
                            memcpy(clolfrec.items_backshop, sbuf, 3);       // 10-1-2005 SDH OSSR WAN
                        }                                                   // 10-1-2005 SDH OSSR WAN

                        //Update the sales and the time                     // 10-1-2005 SDH OSSR WAN
                        memcpy(clilfrec.abTimeStockCntPD, abTimePD, 2);     // 10-1-2005 SDH OSSR WAN
                        memcpy(clilfrec.abAtStockSales, abSales,            // 10-1-2005 SDH OSSR WAN
                               sizeof(clilfrec.abAtStockSales));            // 10-1-2005 SDH OSSR WAN
                        memcpy(clilfrec.count_backshop,                     // 10-1-2005 SDH OSSR WAN
                               pCLC->count_backshop, 4);                    // 10-1-2005 SDH OSSR WAN
                    }                                                       // 10-1-2005 SDH OSSR WAN

                    //If OSSR count has changed                             // 10-1-2005 SDH OSSR WAN
                    if (wNewOSCnt != wCurOSCnt) {                           // 10-1-2005 SDH OSSR WAN

                        //Set location to OSSR                              // 10-1-2005 SDH OSSR WAN
                        lrtp[hh_unit]->bLocation = 'O';                     // 10-1-2005 SDH OSSR WAN

                        //If its the first time then decrement remaining    // 10-1-2005 SDH OSSR WAN
                        //count ensure it doesn't go negative for some      // 10-1-2005 SDH OSSR WAN
                        //strange reason                                    // 10-1-2005 SDH OSSR WAN
                        if (wCurOSCnt == -1) {                              // 10-1-2005 SDH OSSR WAN
                            WORD wTemp = satoi(clolfrec.items_ossr,         // 10-1-2005 SDH OSSR WAN
                                               sizeof(clolfrec.items_ossr));    // 10-1-2005 SDH OSSR WAN
                            wTemp = _max(wTemp - 1, 0);                     // 10-1-2005 SDH OSSR WAN
                            sprintf(sbuf, "%03d", wTemp);                   // 10-1-2005 SDH OSSR WAN
                            memcpy(clolfrec.items_ossr, sbuf,               // 10-1-2005 SDH OSSR WAN
                                   sizeof(clolfrec.items_ossr));            // 10-1-2005 SDH OSSR WAN
                        }                                                   // 10-1-2005 SDH OSSR WAN

                        //In any case, update the time, sales, and count    // 10-1-2005 SDH OSSR WAN
                        memcpy(clilfrec.abTimeOSSRCntPD, abTimePD,          // 10-1-2005 SDH OSSR WAN
                               sizeof(clilfrec.abTimeOSSRCntPD));           // 10-1-2005 SDH OSSR WAN
                        memcpy(clilfrec.abAtOSSRSales, abSales,             // 10-1-2005 SDH OSSR WAN
                               sizeof(clilfrec.abAtOSSRSales));             // 10-1-2005 SDH OSSR WAN
                        memcpy(clilfrec.abOSSRCount, pCLC->abOssrCount,     // 10-1-2005 SDH OSSR WAN
                               sizeof(clilfrec.abOSSRCount));               // 10-1-2005 SDH OSSR WAN
                    }                                                       // 10-1-2005 SDH OSSR WAN

                }

                // Update CLILF item record
                if (debug) {
                    disp_msg("WRITE CLILF (UNLOCK) :");
                    dump( (BYTE *)&clilfrec, (WORD)CLILF_KEYL );
                }
                rc = u_write( 1, 0, clilf.fnum,
                              (void *)&clilfrec, CLILF_RECL, 0L );          // WRITE UNLK
                if (rc<=0L) {
                    if (debug) {
                        sprintf(msg, "Err-W (unlk) CLILF. RC:%08lX", rc2);
                        disp_msg(msg);
                    }
                    prep_nak("ERRORUnable to "
                              "update CLILF. "
                              "Check appl event logs" );
                    break;
                }
                if (debug) disp_msg("OK");                                  // SDH 26-11-04 CREDIT CLAIM

                if (memcmp(pCLC->boots_code, clilfrec.boots_code, 7) != 0) {    // SDH 26-11-04 CREDIT CLAIM
                    prep_nak("ERRORCLILF boots "
                              "code has changed. "
                              "Contact service desk" );
                    break;
                }

                // Update CLOLF list header
                if (debug) {
                    disp_msg("WRITE CLOLF :");
                    dump( (BYTE *)&clolfrec, (WORD)CLOLF_RECL );
                }
                rc2 = s_write( A_FLUSH | A_BOFOFF, clolf.fnum,
                               (void *)&clolfrec, CLOLF_RECL,
                               (list_id-1L) * CLOLF_RECL );
                if (rc2<=0L) {
                    log_event101(rc2, CLOLF_REP, __LINE__);
                    if (debug) {
                        sprintf(msg, "Err-W CLOLF o/s %ld. RC:%08lX",
                                (list_id-1L) * CLOLF_RECL, rc2);
                        disp_msg(msg);
                    }
                    prep_nak("ERRORUnable to "
                              "write to CLOLF. "
                              "Check appl event logs" );
                    break;
                }

                // v4.0 START
                // Audit
                sprintf( msg, "%04ld", list_id );
                memcpy( ((LRTLG_CLC *)dtls)->list_id, msg , 4 );
                memcpy( ((LRTLG_CLC *)dtls)->boots_code,
                        ((LRT_CLC *)(inbound))->boots_code, 7 );
                memset( ((LRTLG_CLC *)dtls)->resv, 0x00, 1 );
                lrt_log( LOG_CLC, hh_unit, dtls);                           // SDH 10-01-05 OSSR WAN
                // v4.0 END

                prep_ack("");                                               //SDH 23-Aug-2006 Planners
            }

            break;

            //-------------------------------------------------------------------------
        case CMD_CLX:                                                       // Counting - List Sign Off and Commit
            {

                BYTE* pbDenyMsg = NULL;                                     // SDH 10-01-05 OSSR WAN

                //Set up CLX view of input message                          // SDH 10-01-05 OSSR WAN
                LRT_CLX* pCLX = (LRT_CLX*)inbound;                          // SDH 10-01-05 OSSR WAN

                if (IsHandheldUnknown()) break;                             // SDH 26-11-04 CREDIT CLAIM
                UpdateActiveTime();                                         // SDH 26-11-04 CREDIT CLAIM

                // Read CLOLF list header
                list_id = satol(pCLX->list_id, 3);
                rc2 = s_read( A_BOFOFF, clolf.fnum, (void *)&clolfrec,
                              CLOLF_RECL, (list_id-1L) * CLOLF_RECL );
                if (rc2<=0L) {
                    log_event101(rc2, CLOLF_REP, __LINE__);
                    if (debug) {
                        sprintf(msg, "Err-R CLOLF o/s %ld. RC:%08lX",
                                (list_id-1L) * CLOLF_RECL, rc2);
                        disp_msg(msg);
                    }
                    prep_nak("ERRORUnable to "
                              "read from CLOLF. "
                              "Check appl event logs" );
                    break;
                }

                //If the list is being commited then ensure that            // SDH 10-01-05 OSSR WAN
                //it is complete enough to commit                           // SDH 10-01-05 OSSR WAN
                if (pCLX->commit_flag[0] == 'Y') {                          // SDH 10-01-05 OSSR WAN

                    //If we're not in an OSSR store...                      // SDH 10-01-05 OSSR WAN
                    if ((rfscfrec1and2.ossr_store == 'N') ||                // SDH 04-04-05 OSSR WAN
                        (rfscfrec1and2.ossr_store == ' ')) {                // SDH 04-04-05 OSSR WAN

                        //If nothing has been counted then don't submit it  // SDH 10-01-05 OSSR WAN
                        if ((strncmp(clolfrec.total_items, clolfrec.items_shopfloor, 3)==0) &&    // SDH 10-01-05 OSSR WAN
                            (strncmp(clolfrec.total_items, clolfrec.items_backshop,  3)==0)) {    // SDH 10-01-05 OSSR WAN
                            pbDenyMsg = "No items counted in"               // SDH 10-01-05 OSSR WAN
                                        " this list, List is"               // SDH 10-01-05 OSSR WAN
                                        " not submitted.";                  // SDH 10-01-05 OSSR WAN
                            //Else if one of the locations has not been counted // SDH 10-01-05 OSSR WAN
                        } else if ((strncmp(clolfrec.total_items, clolfrec.items_shopfloor, 3) == 0) ||    // SDH 10-01-05 OSSR WAN
                                   (strncmp(clolfrec.total_items, clolfrec.items_backshop,  3) == 0)) {    // SDH 10-01-05 OSSR WAN
                            pbDenyMsg = "You must count both"               // SDH 10-01-05 OSSR WAN
                                        " backshop and shop"                // SDH 10-01-05 OSSR WAN
                                        " floor locations.";                // SDH 10-01-05 OSSR WAN
                        }                                                   // SDH 10-01-05 OSSR WAN

                        //Else if an offline OSSR store                         // SDH 10-01-05 OSSR WAN
                    } else if (rfscfrec1and2.ossr_store == 'Y') {           // SDH 10-01-05 OSSR WAN
                        //If no shop floor items counted then deny the commit//SDH 10-01-05 OSSR WAN
                        if (strncmp(clolfrec.total_items, clolfrec.items_shopfloor, 3)==0) {    // SDH 10-01-05 OSSR WAN
                            pbDenyMsg = "OSSR Store. You must"              // SDH 10-01-05 OSSR WAN
                                        " count the shopfloor."             // SDH 10-01-05 OSSR WAN
                                        " LIST NOT SUBMITTED.";             // SDH 10-01-05 OSSR WAN
                        }                                                   // SDH 10-01-05 OSSR WAN

                        //Else if an OSSR WAN store                             // SDH 10-01-05 OSSR WAN
                    } else if (rfscfrec1and2.ossr_store == 'W') {           // SDH 10-01-05 OSSR WAN
                        //If no shop floor items OR no back shop locations counted then deny the commit  // SDH 10-01-05 OSSR WAN
                        if ((strncmp(clolfrec.total_items, clolfrec.items_shopfloor, 3)==0)    ||    // SDH 10-01-05 OSSR WAN
                            ((strncmp(clolfrec.total_items, clolfrec.items_backshop, 3)==0) &&    // SDH 08-04-05 OSSR WAN
                             (strncmp(clolfrec.total_items, clolfrec.items_ossr, 3)==0)       )) {    // SDH 08-04-05 OSSR WAN
                            pbDenyMsg = "OSSR Store. You must"              // SDH 10-01-05 OSSR WAN
                                        " count the shopfloor"              // SDH 10-01-05 OSSR WAN
                                        " & a stock location";              // SDH 10-01-05 OSSR WAN
                        }                                                   // SDH 10-01-05 OSSR WAN
                    }                                                       // SDH 10-01-05 OSSR WAN
                }                                                           // SDH 10-01-05 OSSR WAN

                //Update list status as appropriate                         // SDH 04-04-05 OSSR WAN
                if ((pCLX->commit_flag[0] == 'Y') &&                        // SDH 04-04-05 OSSR WAN
                    (pbDenyMsg == NULL)) {                                  // SDH 04-04-05 OSSR WAN
                    *clolfrec.list_status = 'P';
                } else {                                                    // (commit)
                    *clolfrec.list_status = 'N';
                }                                                           // endif (commit)

                // Update CLOLF list header
                if (debug) {
                    disp_msg("WRITE CLOLF :");
                    dump( (BYTE *)&clolfrec, (WORD)CLOLF_RECL );
                }
                rc2 = s_write( A_FLUSH | A_BOFOFF, clolf.fnum,
                               (void *)&clolfrec, CLOLF_RECL,
                               (list_id-1L) * CLOLF_RECL );
                if (rc2<=0L) {
                    log_event101(rc2, CLOLF_REP, __LINE__);
                    if (debug) {
                        sprintf(msg, "Err-W CLOLF o/s %ld. RC:%08lX",
                                (list_id-1L) * CLOLF_RECL, rc2);
                        disp_msg(msg);
                    }
                    prep_nak("ERRORUnable to "
                              "write to CLOLF. "
                              "Check appl event logs" );
                    break;
                }

                //If we're denying the commit then NAK                      // SDH 10-01-05 OSSR WAN
                if (pbDenyMsg != NULL) {                                    // SDH 10-01-05 OSSR WAN
                    prep_nak(pbDenyMsg);                                    //SDH 23-Aug-2006 Planners
                    break;                                                  // SDH 10-01-05 OSSR WAN
                }                                                           // SDH 10-01-05 OSSR WAN

                // Start background stocks processing of current list
                if (pCLX->commit_flag[0] == 'Y') {                          // SDH 04-04-05 OSSR WAN
                    sprintf( sbuf, "%03ld", list_id );
                    rc = start_background_app("ADX_UPGM:RFSBG.286",         // SDH 27-Sep-2006 Bug fix
                                              sbuf, "Processing Counts - Starting");
                    prep_nak("Unable to start RFSBG. Please try again "     // SDH 27-Sep-2006 Bug fix
                             "shortly.");                                   // SDH 27-Sep-2006 Bug fix
                }

                // v4.0 START
                // Audit
                sprintf( msg, "%04ld", list_id );
                memcpy( ((LRTLG_CLX *)dtls)->list_id, msg , 4 );
                memcpy( ((LRTLG_CLX *)dtls)->commit_flag,
                        (((LRT_CLX *)(inbound))->commit_flag), 1 );
                memset( ((LRTLG_CLX *)dtls)->resv, 0x00, 7 );
                lrt_log( LOG_CLX, hh_unit, dtls );
                // v4.0 END

                prep_ack("");                                               //SDH 23-Aug-2006 Planners

            }

            break;

            //-------------------------------------------------------------------------
        case CMD_CLF:                                                       // Counting - Sign Off

            if (IsHandheldUnknown()) break;                                 // SDH 26-11-04 CREDIT CLAIM
            UpdateActiveTime();                                             // SDH 26-11-04 CREDIT CLAIM

            close_clilf( CL_SESSION );
            close_clolf( CL_SESSION );

            //Do both just in case                                          // SDH 08-05-2006 Bug fix
            process_workfile( hh_unit, SYS_LAB );                           // SDH 08-05-2006 Bug fix
            process_workfile( hh_unit, SYS_GAP );                           // SDH 08-05-2006 Bug fix

            prep_ack("");                                                   //SDH 23-Aug-2006 Planners
            break;


            // Pre-Scan transactions 5-5-04 PAB
            // ------------------------------------------------------------------------------------
        case CMD_SUS:                                                       // Suspend Transaction
            // Move all code to TRANS02 to resolve 64K limit.
            suspend_transaction(inbound);                                   // 24-05-2007 PAB
            break;

// ------------------------------------------------------------------------------------
//
// UOS - UOD Start
//
// ------------------------------------------------------------------------------------

        case CMD_UOS:                                                       // SDH 26-11-04 CREDIT CLAIM

            {                                                               // SDH 26-11-04 CREDIT CLAIM

                //Declare working variables                                 // SDH 26-11-04 CREDIT CLAIM
                WORD wListNum;                                              // SDH 26-11-04 CREDIT CLAIM

                //Input and output views                                    // SDH 26-11-04 CREDIT CLAIM
                LRT_UOS *pUOS = (LRT_UOS*)inbound;                          // SDH 26-11-04 CREDIT CLAIM
                LRT_UOR *pUOR = (LRT_UOR*)out;                              // SDH 26-11-04 CREDIT CLAIM
                LRTLG_UOS *pLGUOS = (LRTLG_UOS*)dtls;                       // SDH 26-11-04 CREDIT CLAIM

                //Set up current date and time                              // SDH 26-11-04 CREDIT CLAIM
                B_DATE nowDate;                                             // SDH 26-11-04 CREDIT CLAIM
                B_TIME nowTime;                                             // SDH 26-11-04 CREDIT CLAIM
                GetSystemDate(&nowTime, &nowDate);                          // SDH 26-11-04 CREDIT CLAIM

                //Initial checks                                            // SDH 26-11-04 CREDIT CLAIM
                //These routines build the NAK if appropriate               // SDH 26-11-04 CREDIT CLAIM
                if (IsStoreClosed()) break;                                 // SDH 26-11-04 CREDIT CLAIM
                if (IsHandheldUnknown()) break;                             // SDH 26-11-04 CREDIT CLAIM
                UpdateActiveTime();                                         // SDH 26-11-04 CREDIT CLAIM

                //Open the credit claiming files for this session           // SDH 26-11-04 CREDIT CLAIM
                if (open_cclol() != RC_OK) {                                // SDH 26-11-04 CREDIT CLAIM
                    prep_nak("ERRORUnable to open "                         //SDH 23-Aug-2006 Planners
                              "CCLOL file. "                                // SDH 26-11-04 CREDIT CLAIM
                              "Check appl event logs" );                    // SDH 26-11-04 CREDIT CLAIM
                    break;                                                  // SDH 26-11-04 CREDIT CLAIM
                }                                                           // SDH 26-11-04 CREDIT CLAIM
                if (open_ccilf() != RC_OK) {                                // SDH 26-11-04 CREDIT CLAIM
                    prep_nak("ERRORUnable to open "                         //SDH 23-Aug-2006 Planners
                              "CCILF file. "                                // SDH 26-11-04 CREDIT CLAIM
                              "Check appl event logs" );                    // SDH 26-11-04 CREDIT CLAIM
                    close_cclol(CL_SESSION);                                // SDH 26-11-04 CREDIT CLAIM
                    break;                                                  // SDH 26-11-04 CREDIT CLAIM
                }                                                           // SDH 26-11-04 CREDIT CLAIM
                if (open_cchist() != RC_OK) {
                    prep_nak("ERRORUnable to open "                         //SDH 23-Aug-2006 Planners
                              "CCHIST file. "                               // SDH 26-11-04 CREDIT CLAIM
                              "Check appl event logs" );                    // SDH 26-11-04 CREDIT CLAIM
                    close_cclol(CL_SESSION);
                    close_ccilf(CL_SESSION);
                    break;                                                  // SDH 26-11-04 CREDIT CLAIM
                }                                                           // SDH 26-11-04 CREDIT CLAIM

                //Read CCLOL header and handle errors                       // SDH 26-11-04 CREDIT CLAIM
                rc2 = ReadCclol(0, __LINE__);                               // SDH 26-11-04 CREDIT CLAIM
                if (rc2 <= 0L) {                                            // SDH 26-11-04 CREDIT CLAIM
                    prep_nak("ERRORUnable to "                              //SDH 23-Aug-2006 Planners
                             "read from CCLOL. "                            // SDH 26-11-04 CREDIT CLAIM
                             "Check appl event logs" );                     // SDH 26-11-04 CREDIT CLAIM
                    close_cclol(CL_SESSION);                                // SDH 26-11-04 CREDIT CLAIM
                    close_ccilf(CL_SESSION);                                // SDH 26-11-04 CREDIT CLAIM
                    close_cchist(CL_SESSION);                               // SDH 26-11-04 CREDIT CLAIM
                    break;                                                  // SDH 26-11-04 CREDIT CLAIM
                }                                                           // SDH 26-11-04 CREDIT CLAIM

                //Get the list ID as an int and increment it to get the     // SDH 26-11-04 CREDIT CLAIM
                //next available list ID.                                   // SDH 26-11-04 CREDIT CLAIM
                //This code assumes that the file does not wrap, and that   // SDH 26-11-04 CREDIT CLAIM
                //the number of record will not reach 32,767                // SDH 26-11-04 CREDIT CLAIM
                wListNum = satoi(cclolrec.abListNum,                        // SDH 26-11-04 CREDIT CLAIM
                                 sizeof(cclolrec.abListNum)) + 1;           // SDH 26-11-04 CREDIT CLAIM

                //Build new CCLOL list record                               // SDH 26-11-04 CREDIT CLAIM
                memset(&cclolrec, 0x00, sizeof(cclolrec));                  // SDH 26-11-04 CREDIT CLAIM
                sprintf(sbuf, "%04d", wListNum);                            // SDH 26-11-04 CREDIT CLAIM
                memcpy(cclolrec.abListNum, sbuf, sizeof(cclolrec.abListNum));    // SDH 26-11-04 CREDIT CLAIM
                cclolrec.cListType = pUOS->cListType;                       // SDH 26-11-04 CREDIT CLAIM
                sprintf(sbuf, "%04d%02d%02d",                               // SDH 26-11-04 CREDIT CLAIM
                        nowDate.wYear, nowDate.wMonth, nowDate.wDay);       // SDH 26-11-04 CREDIT CLAIM
                memcpy(cclolrec.abDateUODOpened, sbuf,                      // SDH 26-11-04 CREDIT CLAIM
                       sizeof(cclolrec.abDateUODOpened));                   // SDH 26-11-04 CREDIT CLAIM
                sprintf(sbuf, "%02d%02d", nowTime.wHour, nowTime.wMin);     // SDH 26-11-04 CREDIT CLAIM
                memcpy(cclolrec.abTimeUODOpened, sbuf,                      // SDH 26-11-04 CREDIT CLAIM
                       sizeof(cclolrec.abTimeUODOpened));                   // SDH 26-11-04 CREDIT CLAIM
                memcpy(cclolrec.abOpID, pUOS->abOpID,                       // SDH 26-11-04 CREDIT CLAIM
                       sizeof(cclolrec.abOpID));                            // SDH 26-11-04 CREDIT CLAIM
                if (strncmp(lrtp[hh_unit]->user, pUOS->abOpID,              // SDH 26-11-04 CREDIT CLAIM
                            sizeof(pUOS->abOpID)) == 0) {                   // SDH 26-11-04 CREDIT CLAIM
                    memcpy(cclolrec.abOpName, lrtp[hh_unit]->abOpName,      // SDH 26-11-04 CREDIT CLAIM
                           sizeof(cclolrec.abOpName));                      // SDH 26-11-04 CREDIT CLAIM
                } else {                                                    // SDH 26-11-04 CREDIT CLAIM
                    memcpy(cclolrec.abOpName, "Mismatched oper",            // SDH 26-11-04 CREDIT CLAIM
                           sizeof(cclolrec.abOpName));                      // SDH 26-11-04 CREDIT CLAIM
                }                                                           // SDH 26-11-04 CREDIT CLAIM

                //Write record and handle errors                            // SDH 26-11-04 CREDIT CLAIM
                rc2 = WriteCclol(wListNum, __LINE__);                       // SDH 26-11-04 CREDIT CLAIM
                if (rc2 <= 0L) {                                            // SDH 26-11-04 CREDIT CLAIM
                    prep_nak("ERRORUnable to "                              //SDH 23-Aug-2006 Planners
                             "write to CCLOL. "                             // SDH 26-11-04 CREDIT CLAIM
                             "Check appl event log" );                      // SDH 26-11-04 CREDIT CLAIM
                    break;                                                  // SDH 26-11-04 CREDIT CLAIM
                }                                                           // SDH 26-11-04 CREDIT CLAIM

                //Increment the count on the header file and handle errors  // SDH 26-11-04 CREDIT CLAIM
                memcpy(sbuf, &cclolrec, sizeof(cclolrec.abListNum));        // SDH 26-11-04 CREDIT CLAIM
                memset(&cclolrec, 0x00, sizeof(cclolrec));                  // SDH 26-11-04 CREDIT CLAIM
                memcpy(&cclolrec, sbuf, sizeof(cclolrec.abListNum));        // SDH 26-11-04 CREDIT CLAIM
                rc2 = WriteCclol(0, __LINE__);                              // SDH 26-11-04 CREDIT CLAIM
                if (rc2 <= 0L) {                                            // SDH 26-11-04 CREDIT CLAIM
                    prep_nak("ERRORUnable to "                              //SDH 23-Aug-2006 Planners
                             "write to CCLOL. "                             // SDH 26-11-04 CREDIT CLAIM
                             "Check appl event log" );                      // SDH 26-11-04 CREDIT CLAIM
                    close_cclol(CL_SESSION);                                // SDH 26-11-04 CREDIT CLAIM
                    close_ccilf(CL_SESSION);                                // SDH 26-11-04 CREDIT CLAIM
                    close_cchist(CL_SESSION);                               // SDH 26-11-04 CREDIT CLAIM
                    break;                                                  // SDH 26-11-04 CREDIT CLAIM
                }                                                           // SDH 26-11-04 CREDIT CLAIM

                //Build UOR                                                 // SDH 26-11-04 CREDIT CLAIM
                //We don't bother to read the RFSCF since it would have     // SDH 26-11-04 CREDIT CLAIM
                //been read at sign on and the allowed business centres     // SDH 26-11-04 CREDIT CLAIM
                //don't change too often                                    // SDH 26-11-04 CREDIT CLAIM
                memcpy(pUOR->abCmd, "UOR", sizeof(pUOR->abCmd));            // SDH 26-11-04 CREDIT CLAIM
                memcpy(pUOR->abOpID, pUOS->abOpID, sizeof(pUOR->abOpID));   // SDH 26-11-04 CREDIT CLAIM
                memcpy(pUOR->abListNum, cclolrec.abListNum,                 // SDH 26-11-04 CREDIT CLAIM
                       sizeof(pUOR->abListNum));                            // SDH 26-11-04 CREDIT CLAIM
                memcpy(pUOR->abValidBusCentres, rfscfrec3.abBusCentres,     // SDH 26-11-04 CREDIT CLAIM
                       sizeof(pUOR->abValidBusCentres));                    // SDH 26-11-04 CREDIT CLAIM
                out_lth = LRT_UOR_LTH;                                      // SDH 26-11-04 CREDIT CLAIM

                //Build UOS audit                                           // SDH 26-11-04 CREDIT CLAIM
                memcpy(pLGUOS->abListNum, pUOR->abListNum,                  // SDH 26-11-04 CREDIT CLAIM
                       sizeof(pLGUOS->abListNum));                          // SDH 26-11-04 CREDIT CLAIM
                lrt_log(LOG_UOS, hh_unit, (BYTE*)pLGUOS);                   // SDH 26-11-04 CREDIT CLAIM

            }                                                               // SDH 26-11-04 CREDIT CLAIM

            break;                                                          // SDH 26-11-04 CREDIT CLAIM

// ------------------------------------------------------------------------------------
//
// UOA - UOD Add
//
// ------------------------------------------------------------------------------------

        case CMD_UOA:                                                       // SDH 26-11-04 CREDIT CLAIM

            {                                                               // SDH 26-11-04 CREDIT CLAIM

                //Input and output views                                    // SDH 26-11-04 CREDIT CLAIM
                LRT_UOA *pUOA = (LRT_UOA*)inbound;                          // SDH 26-11-04 CREDIT CLAIM
                LRTLG_UOA *pLGUOA = (LRTLG_UOA*)dtls;                       // SDH 26-11-04 CREDIT CLAIM

                //Set up current date and time                              // SDH 26-11-04 CREDIT CLAIM
                B_DATE nowDate;                                             // SDH 26-11-04 CREDIT CLAIM
                B_TIME nowTime;                                             // SDH 26-11-04 CREDIT CLAIM
                GetSystemDate(&nowTime, &nowDate);                          // SDH 26-11-04 CREDIT CLAIM

                //Initial checks                                            // SDH 26-11-04 CREDIT CLAIM
                if (IsStoreClosed()) break;                                 // SDH 26-11-04 CREDIT CLAIM
                if (IsHandheldUnknown()) break;                             // SDH 26-11-04 CREDIT CLAIM
                UpdateActiveTime();                                         // SDH 26-11-04 CREDIT CLAIM

                //Set up the record key                                     // SDH 26-11-04 CREDIT CLAIM
                memcpy(ccilfrec.abListNum, pUOA->abListNum,                 // SDH 26-11-04 CREDIT CLAIM
                       sizeof(ccilfrec.abListNum));                         // SDH 26-11-04 CREDIT CLAIM
                memcpy(ccilfrec.abRecSeq, pUOA->abRecSeq,                   // SDH 26-11-04 CREDIT CLAIM
                       sizeof(ccilfrec.abRecSeq));                          // SDH 26-11-04 CREDIT CLAIM

                //Are we doing a cancel?                                    // SDH 26-11-04 CREDIT CLAIM
                //If so then read the file rather than building             // SDH 26-11-04 CREDIT CLAIM
                //the CCILF record                                          // SDH 26-11-04 CREDIT CLAIM
                if (pUOA->cItemStatus == 'X') {                             // SDH 26-11-04 CREDIT CLAIM
                    rc2 = ReadCcilf(__LINE__);                              // SDH 26-11-04 CREDIT CLAIM
                    if (rc2 <= 0L) {                                        // SDH 26-11-04 CREDIT CLAIM
                        prep_nak("ERRORUnable to "                          //SDH 23-Aug-2006 Planners
                                 "read CCLOL. "                             // SDH 26-11-04 CREDIT CLAIM
                                 "Check appl event log" );                  // SDH 26-11-04 CREDIT CLAIM
                        break;                                              // SDH 26-11-04 CREDIT CLAIM
                    }                                                       // SDH 26-11-04 CREDIT CLAIM
                    //Otherwise build the entire CCILF record               // SDH 26-11-04 CREDIT CLAIM
                } else {                                                    // SDH 26-11-04 CREDIT CLAIM
                    memcpy(ccilfrec.abItemCode,  pUOA->abItemCode,          // SDH 26-11-04 CREDIT CLAIM
                           sizeof(ccilfrec.abItemCode));                    // SDH 26-11-04 CREDIT CLAIM
                    memcpy(ccilfrec.abBarCode,   pUOA->abBarCode,           // SDH 26-11-04 CREDIT CLAIM
                           sizeof(ccilfrec.abBarCode));                     // SDH 26-11-04 CREDIT CLAIM
                    memcpy(ccilfrec.abItemDesc,  pUOA->abDesc,              // SDH 26-11-04 CREDIT CLAIM
                           sizeof(ccilfrec.abItemDesc));                    // SDH 26-11-04 CREDIT CLAIM
                    memcpy(ccilfrec.abSelDesc,   pUOA->abSelDesc,           // SDH 26-11-04 CREDIT CLAIM
                           sizeof(ccilfrec.abSelDesc));                     // SDH 26-11-04 CREDIT CLAIM
                    memcpy(ccilfrec.abItemQty,   pUOA->abQty,               // SDH 26-11-04 CREDIT CLAIM
                           sizeof(ccilfrec.abItemQty));                     // SDH 26-11-04 CREDIT CLAIM
                    memset(ccilfrec.abFiller1, ' ',                         // SDH 26-11-04 CREDIT CLAIM
                           sizeof(ccilfrec.abFiller1));                     // SDH 26-11-04 CREDIT CLAIM
                    memcpy(ccilfrec.abItemPrice, pUOA->abPrice,             // SDH 26-11-04 CREDIT CLAIM
                           sizeof(ccilfrec.abItemPrice));                   // SDH 26-11-04 CREDIT CLAIM
                    ccilfrec.cBusCentre = pUOA->cBusCentre;                 // SDH 26-11-04 CREDIT CLAIM
                    memcpy(ccilfrec.abBusCentreDesc, pUOA->abBusCentreDesc, // SDH 26-11-04 CREDIT CLAIM
                           sizeof(ccilfrec.abBusCentreDesc));               // SDH 26-11-04 CREDIT CLAIM
                    sprintf(sbuf, "%04d%02d%02d",                           // SDH 26-11-04 CREDIT CLAIM
                            nowDate.wYear,nowDate.wMonth, nowDate.wDay);    // SDH 26-11-04 CREDIT CLAIM
                    memcpy(ccilfrec.abDateAdded, sbuf,                      // SDH 26-11-04 CREDIT CLAIM
                           sizeof(ccilfrec.abDateAdded));                   // SDH 26-11-04 CREDIT CLAIM
                    sprintf(sbuf, "%02d%02d", nowTime.wHour, nowTime.wMin); // SDH 26-11-04 CREDIT CLAIM
                    memcpy(ccilfrec.abTimeAdded, sbuf,                      // SDH 26-11-04 CREDIT CLAIM
                           sizeof(ccilfrec.abTimeAdded));                   // SDH 26-11-04 CREDIT CLAIM
                    memset(ccilfrec.abFiller2, ' ',                         // SDH 26-11-04 CREDIT CLAIM
                           sizeof(ccilfrec.abFiller2));                     // SDH 26-11-04 CREDIT CLAIM
                }                                                           // SDH 26-11-04 CREDIT CLAIM

                //Update the item status                                    // SDH 26-11-04 CREDIT CLAIM
                ccilfrec.cItemStatus = pUOA->cItemStatus;                   // SDH 26-11-04 CREDIT CLAIM

                //Write the CCILF and handle errors                         // SDH 26-11-04 CREDIT CLAIM
                rc2 = WriteCcilf(__LINE__);                                 // SDH 26-11-04 CREDIT CLAIM
                if (rc2 <= 0L) {                                            // SDH 26-11-04 CREDIT CLAIM
                    prep_nak("ERRORUnable to "                              //SDH 23-Aug-2006 Planners
                             "write to CCILF. "                             // SDH 04-05-06 A6C: Bug fix
                             "Check appl event log");                       // SDH 26-11-04 CREDIT CLAIM
                    break;                                                  // SDH 26-11-04 CREDIT CLAIM
                }                                                           // SDH 26-11-04 CREDIT CLAIM

                //Success - send ACK                                        // SDH 26-11-04 CREDIT CLAIM
                prep_ack("");                                               //SDH 23-Aug-2006 Planners

                //Build audit log                                           // SDH 26-11-04 CREDIT CLAIM
                memcpy(pLGUOA->abListNum, pUOA->abListNum,                  // SDH 26-11-04 CREDIT CLAIM
                       sizeof(pLGUOA->abListNum));                          // SDH 26-11-04 CREDIT CLAIM
                memcpy(pLGUOA->abItemCode, pUOA->abItemCode,                // SDH 26-11-04 CREDIT CLAIM
                       sizeof(pLGUOA->abItemCode));                         // SDH 26-11-04 CREDIT CLAIM
                pLGUOA->cItemStatus = pUOA->cItemStatus;                    // SDH 26-11-04 CREDIT CLAIM
                lrt_log(LOG_UOA, hh_unit, dtls);                            // SDH 26-11-04 CREDIT CLAIM
                                                                            // SDH 26-11-04 CREDIT CLAIM
            }                                                               // SDH 26-11-04 CREDIT CLAIM

            break;                                                          // SDH 26-11-04 CREDIT CLAIM

// -------------------------------------------------------------------------
//                                                                          
// UOX - UOD Close/dispatch/save                                            
//                                                                          
// -------------------------------------------------------------------------

        case CMD_UOX:                                                       // SDH 26-11-04 CREDIT CLAIM

            {                                                               // SDH 26-11-04 CREDIT CLAIM
                //Declare working variables                                 // SDH 26-11-04 CREDIT CLAIM
                WORD wListNum;                                              // SDH 26-11-04 CREDIT CLAIM

                //Input and output views                                    // SDH 26-11-04 CREDIT CLAIM
                LRT_UOX *pUOX = (LRT_UOX*)inbound;                          // SDH 26-11-04 CREDIT CLAIM
                LRTLG_UOX *pLGUOX = (LRTLG_UOX*)dtls;                       // SDH 26-11-04 CREDIT CLAIM

                //Set up current date and time                              // SDH 26-11-04 CREDIT CLAIM
                B_DATE nowDate;                                             // SDH 26-11-04 CREDIT CLAIM
                B_TIME nowTime;                                             // SDH 26-11-04 CREDIT CLAIM
                GetSystemDate(&nowTime, &nowDate);                          // SDH 26-11-04 CREDIT CLAIM

                //Initial checks                                            // SDH 26-11-04 CREDIT CLAIM
                //Store Closed check not required since this is an exit     // SDH 26-11-04 CREDIT CLAIM
                if (IsHandheldUnknown()) break;                             // SDH 26-11-04 CREDIT CLAIM
                UpdateActiveTime();                                         // SDH 26-11-04 CREDIT CLAIM

                //Read CCLOL and handle errors                              // SDH 26-11-04 CREDIT CLAIM
                //We must re-read the record since the terminal does not    // SDH 26-11-04 CREDIT CLAIM
                //pass the date/time list was created                       // SDH 26-11-04 CREDIT CLAIM
                wListNum = satoi(pUOX->abListNum, sizeof(pUOX->abListNum)); // SDH 26-11-04 CREDIT CLAIM
                rc2 = ReadCclol(wListNum, __LINE__);                        // SDH 26-11-04 CREDIT CLAIM

                //Handle errors                                             // SDH 26-11-04 CREDIT CLAIM
                //If we're doing a cancel then assume the HHT will          // SDH 26-11-04 CREDIT CLAIM
                //quit out of Credit Claiming, so end the session           // SDH 26-11-04 CREDIT CLAIM
                if (rc2 <= 0L) {                                            // SDH 26-11-04 CREDIT CLAIM
                    prep_nak("ERRORUnable to "                              //SDH 23-Aug-2006 Planners
                             "read from CCLOL. "                            // SDH 26-11-04 CREDIT CLAIM
                             "Check appl event logs" );                     // SDH 26-11-04 CREDIT CLAIM
                    if (pUOX->cStatus == 'C') {                             // SDH 26-11-04 CREDIT CLAIM
                        close_cclol(CL_SESSION);                            // SDH 26-11-04 CREDIT CLAIM
                        close_ccilf(CL_SESSION);                            // SDH 26-11-04 CREDIT CLAIM
                        close_cchist(CL_SESSION);                           // SDH 26-11-04 CREDIT CLAIM
                    }                                                       // SDH 26-11-04 CREDIT CLAIM
                    break;                                                  // SDH 26-11-04 CREDIT CLAIM
                }                                                           // SDH 26-11-04 CREDIT CLAIM

                //Update CCLOL fields                                       // SDH 26-11-04 CREDIT CLAIM
                //Don't update operator ID though since this is expected    // SDH 26-11-04 CREDIT CLAIM
                //not to change                                             // SDH 26-11-04 CREDIT CLAIM
                //Always set the UOD qty to the same as the Item Count      // SDH 26-11-04 CREDIT CLAIM
                //Set the RF Status flag to 'C' for complete                // SDH 26-11-04 CREDIT CLAIM
                cclolrec.cListType = pUOX->cListType;                       // SDH 26-11-04 CREDIT CLAIM
                memcpy(cclolrec.abUODNum, pUOX->abUODNum,                   // SDH 26-11-04 CREDIT CLAIM
                       sizeof(cclolrec.abUODNum));                          // SDH 26-11-04 CREDIT CLAIM
                memcpy(cclolrec.abItemCount, pUOX->abItemCount,             // SDH 26-11-04 CREDIT CLAIM
                       sizeof(cclolrec.abItemCount));                       // SDH 26-11-04 CREDIT CLAIM
                memcpy(cclolrec.abUODQty, pUOX->abItemCount,                // SDH 26-11-04 CREDIT CLAIM
                       sizeof(cclolrec.abUODQty));                          // SDH 26-11-04 CREDIT CLAIM
                cclolrec.cAdjStockFig = pUOX->cAdjStockFig;                 // SDH 26-11-04 CREDIT CLAIM
                cclolrec.cSupplyRoute = pUOX->cSupplyRoute;                 // SDH 26-11-04 CREDIT CLAIM
                cclolrec.cDispLocation = pUOX->cDispLocation;               // SDH 26-11-04 CREDIT CLAIM
                cclolrec.cBusCentre = pUOX->cBusCentre;                     // SDH 26-11-04 CREDIT CLAIM
                memcpy(cclolrec.abBusCentreDesc, pUOX->abBusCentreDesc,     // SDH 26-11-04 CREDIT CLAIM
                       sizeof(cclolrec.abBusCentreDesc));                   // SDH 26-11-04 CREDIT CLAIM
                memcpy(cclolrec.abRecallNum, pUOX->abRecallNum,             // SDH 26-11-04 CREDIT CLAIM
                       sizeof(cclolrec.abRecallNum));                       // SDH 26-11-04 CREDIT CLAIM
                memcpy(cclolrec.abAuth, pUOX->abAuth,                       // SDH 26-11-04 CREDIT CLAIM
                       sizeof(cclolrec.abAuth));                            // SDH 26-11-04 CREDIT CLAIM
                memcpy(cclolrec.abSupplier, pUOX->abSupplier,               // SDH 26-11-04 CREDIT CLAIM
                       sizeof(cclolrec.abSupplier));                        // SDH 26-11-04 CREDIT CLAIM
                memcpy(cclolrec.abReturnMethod, pUOX->abReturnMethod,       // SDH 26-11-04 CREDIT CLAIM
                       sizeof(cclolrec.abReturnMethod));                    // SDH 26-11-04 CREDIT CLAIM
                memcpy(cclolrec.abCarrier, pUOX->abCarrier,                 // SDH 26-11-04 CREDIT CLAIM
                       sizeof(cclolrec.abCarrier));                         // SDH 26-11-04 CREDIT CLAIM
                memcpy(cclolrec.abBirdNum, pUOX->abBirdNum,                 // SDH 26-11-04 CREDIT CLAIM
                       sizeof(cclolrec.abBirdNum));                         // SDH 26-11-04 CREDIT CLAIM
                memcpy(cclolrec.abReasonNum, pUOX->abReasonNum,             // SDH 26-11-04 CREDIT CLAIM
                       sizeof(cclolrec.abReasonNum));                       // SDH 26-11-04 CREDIT CLAIM
                memcpy(cclolrec.abReceivingStoreNum,                        // SDH 26-11-04 CREDIT CLAIM
                       pUOX->abReceivingStoreNum,                           // SDH 26-11-04 CREDIT CLAIM
                       sizeof(cclolrec.abReceivingStoreNum));               // SDH 26-11-04 CREDIT CLAIM
                memcpy(cclolrec.abDestination, pUOX->abDestination,         // SDH 26-11-04 CREDIT CLAIM
                       sizeof(cclolrec.abDestination));                     // SDH 26-11-04 CREDIT CLAIM
                cclolrec.cWarehouseRoute = pUOX->cWarehouseRoute;           // SDH 26-11-04 CREDIT CLAIM
                memcpy(cclolrec.abUODType, pUOX->abUODType,                 // SDH 26-11-04 CREDIT CLAIM
                       sizeof(cclolrec.abUODType));                         // SDH 26-11-04 CREDIT CLAIM
                memcpy(cclolrec.abDamageRsn, pUOX->abDamageRsn,             // SDH 26-11-04 CREDIT CLAIM
                       sizeof(cclolrec.abDamageRsn));                       // SDH 26-11-04 CREDIT CLAIM
                cclolrec.cRFStatus = 'C';                                   // SDH 26-11-04 CREDIT CLAIM

                //If list was dispatched then set the                       // SDH 26-11-04 CREDIT CLAIM
                //date of dispatch to today                                 // SDH 26-11-04 CREDIT CLAIM
                //Then start RFSCC.286 and pass the list number             // SDH 26-11-04 CREDIT CLAIM
                //Only copy the status across if its NOT dispatched         // SDH 26-11-04 CREDIT CLAIM
                //The dispatched flag is set by RFSCC.286 once              // SDH 26-11-04 CREDIT CLAIM
                //successfully completed.                                   // SDH 26-11-04 CREDIT CLAIM
                if (pUOX->cStatus == 'D') {                                 // SDH 26-11-04 CREDIT CLAIM

                    //Validate reason code (1-99).                          // SDH 22-06-2006
                    //Invalid reason codes have caused problems in store.   // SDH 22-06-2006
                    //Allow a space in the first character                  // SDH 22-06-2006
                    WORD wRsn = satoi(pUOX->abReasonNum,                    // SDH 17-Oct-06 Bug fix
                                      sizeof(pUOX->abReasonNum));           // SDH 17-Oct-06 Bug fix
                    if (wRsn < 1 || wRsn > 99) {                            // SDH 17-Oct-06 Bug fix
                        sprintf(sbuf, "The Reason Code is invalid: %.2s",   // SDH 22-06-2006
                                pUOX->abReasonNum);                         // SDH 22-06-2006
                        prep_nak(sbuf);                                     // SDH 23-Aug-2006 Planners
                        break;                                              // SDH 22-06-2006
                    }                                                       // SDH 22-06-2006

                    sprintf(sbuf, "%04d%02d%02d",                           // SDH 26-11-04 CREDIT CLAIM
                            nowDate.wYear, nowDate.wMonth, nowDate.wDay);   // SDH 26-11-04 CREDIT CLAIM
                    memcpy(cclolrec.abDateUODDispatched, sbuf,              // SDH 26-11-04 CREDIT CLAIM
                           sizeof(cclolrec.abDateUODDispatched));           // SDH 26-11-04 CREDIT CLAIM

                    //Update CCHIST                                         // SDH 26-11-04 CREDIT CLAIM
                    if ((strncmp(pUOX->abUODNum, "00000000001000",          // SDH 26-11-04 CREDIT CLAIM
                                 sizeof(pUOX->abUODNum)) != 0) &&           // SDH 26-11-04 CREDIT CLAIM
                        (pUOX->cListType == 'G')) {                         // SDH 26-11-04 CREDIT CLAIM
                        memcpy(cchistrec.abUODNum, pUOX->abUODNum,          // SDH 26-11-04 CREDIT CLAIM
                               sizeof(cchistrec.abUODNum));                 // SDH 26-11-04 CREDIT CLAIM
                        sprintf(sbuf, "%02d%02d%02d", nowDate.wYear%100,    // SDH 26-11-04 CREDIT CLAIM
                                nowDate.wMonth, nowDate.wDay);              // SDH 26-11-04 CREDIT CLAIM
                        memcpy(cchistrec.abDateUODAdded, sbuf,              // SDH 26-11-04 CREDIT CLAIM
                               sizeof(cchistrec.abDateUODAdded));           // SDH 26-11-04 CREDIT CLAIM
                        memcpy(cchistrec.abListNum, pUOX->abListNum,        // SDH 26-11-04 CREDIT CLAIM
                               sizeof(cchistrec.abListNum));                // SDH 26-11-04 CREDIT CLAIM
                        memset(cchistrec.abFiller, 0xFF,                    // SDH 26-11-04 CREDIT CLAIM
                               sizeof(cchistrec.abFiller));                 // SDH 26-11-04 CREDIT CLAIM
                        rc2 = WriteCchist(__LINE__);                        // SDH 26-11-04 CREDIT CLAIM
                        if (rc2 <= 0L) {                                    // SDH 26-11-04 CREDIT CLAIM
                            prep_nak("ERRORUnable to "                      //SDH 23-Aug-2006 Planners
                                     "write to CCHIST. "                    // SDH 26-11-04 CREDIT CLAIM
                                     "Check appl event log" );              // SDH 26-11-04 CREDIT CLAIM
                            close_cclol(CL_SESSION);                        // SDH 23-06-06
                            close_ccilf(CL_SESSION);                        // SDH 23-06-06
                            close_cchist(CL_SESSION);                       // SDH 23-06-06
                            break;                                          // SDH 26-11-04 CREDIT CLAIM
                        }                                                   // SDH 26-11-04 CREDIT CLAIM
                    }                                                       // SDH 26-11-04 CREDIT CLAIM

                } else {                                                    // SDH 26-11-04 CREDIT CLAIM
                    cclolrec.cStatus = pUOX->cStatus;                       // SDH 26-11-04 CREDIT CLAIM
                }                                                           // SDH 26-11-04 CREDIT CLAIM

                //Write CCLOL record and handle errors                      // SDH 26-11-04 CREDIT CLAIM
                rc2 = WriteCclol(wListNum, __LINE__);                       // SDH 26-11-04 CREDIT CLAIM
                if (rc2 <= 0L) {                                            // SDH 26-11-04 CREDIT CLAIM
                    prep_nak("ERRORUnable to "                              //SDH 23-Aug-2006 Planners
                             "write to CCLOL. "                             // SDH 26-11-04 CREDIT CLAIM
                             "Check appl event log" );                      // SDH 26-11-04 CREDIT CLAIM
                    close_cclol(CL_SESSION);                                // SDH 23-06-06
                    close_ccilf(CL_SESSION);                                // SDH 23-06-06
                    close_cchist(CL_SESSION);                               // SDH 23-06-06
                    break;                                                  // SDH 26-11-04 CREDIT CLAIM
                }                                                           // SDH 26-11-04 CREDIT CLAIM

                //If the list is being dispatched, start RFSCC.286 as a     // SDH 26-11-04 CREDIT CLAIM
                //background task.  First build the list name as a string   // SDH 26-11-04 CREDIT CLAIM
                //to pass to the program                                    // SDH 26-11-04 CREDIT CLAIM
                if (pUOX->cStatus == 'D') {                                 // SDH 26-11-04 CREDIT CLAIM
                    memcpy(sbuf, cclolrec.abListNum,                        // SDH 26-11-04 CREDIT CLAIM
                           sizeof(cclolrec.abListNum));                     // SDH 26-11-04 CREDIT CLAIM
                    sbuf[sizeof(cclolrec.abListNum)] = '\0';                // SDH 26-11-04 CREDIT CLAIM
                    rc = start_background_app("ADX_UPGM:RFSCC.286", sbuf,   // SDH 27-Sep-06 Bug Fix
                                              "Starting RFSCC");            // SDH 26-11-04 CREDIT CLAIM
                    if (rc < 0) {                                           // SDH 27-Sep-06 Bug Fix
                        prep_nak("Could not start RFSCC. Please try again " // SDH 27-Sep-06 Bug Fix
                                 "shortly.");                               // SDH 27-Sep-06 Bug Fix
                        break;                                              // SDH 27-Sep-06 Bug Fix
                    }                                                       // SDH 27-Sep-06 Bug Fix
                }                                                           // SDH 26-11-04 CREDIT CLAIM

                //Success - send ACK                                        // SDH 26-11-04 CREDIT CLAIM
                prep_ack("");                                               //SDH 23-Aug-2006 Planners

                //Build UOX audit                                           // SDH 26-11-04 CREDIT CLAIM
                memcpy(pLGUOX->abListNum, pUOX->abListNum,
                       sizeof(pLGUOX->abListNum));                          // SDH 26-11-04 CREDIT CLAIM
                pLGUOX->cStatus = pUOX->cStatus;                            // SDH 26-11-04 CREDIT CLAIM

                //Close Credit Claiming Files                               // SDH 26-11-04 CREDIT CLAIM
                close_cclol(CL_SESSION);                                    // SDH 26-11-04 CREDIT CLAIM
                close_ccilf(CL_SESSION);                                    // SDH 26-11-04 CREDIT CLAIM
                close_cchist(CL_SESSION);                                   // SDH 26-11-04 CREDIT CLAIM

            }                                                               // SDH 26-11-04 CREDIT CLAIM

            break;                                                          // SDH 26-11-04 CREDIT CLAIM

// ------------------------------------------------------------------------------------
//
// DSS - Get Direct Supplier List Start
//
// ------------------------------------------------------------------------------------

        case CMD_DSS:                                                       // SDH 26-11-04 CREDIT CLAIM

            {                                                               // SDH 26-11-04 CREDIT CLAIM

                //Input and output views                                    // SDH 26-11-04 CREDIT CLAIM
                LRTLG_DSS *pLGDSS = (LRTLG_DSS*)dtls;                       // SDH 26-11-04 CREDIT CLAIM

                //Initial checks                                            // SDH 26-11-04 CREDIT CLAIM
                if (IsStoreClosed()) break;                                 // SDH 26-11-04 CREDIT CLAIM
                if (IsHandheldUnknown()) break;                             // SDH 26-11-04 CREDIT CLAIM
                UpdateActiveTime();                                         // SDH 26-11-04 CREDIT CLAIM

                //Open the CCDIRSU for this list retrieval session          // SDH 26-11-04 CREDIT CLAIM
                //Handle errors                                             // SDH 26-11-04 CREDIT CLAIM
                if (open_ccdirsu() != RC_OK) {                              // SDH 26-11-04 CREDIT CLAIM
                    prep_nak("ERRORUnable to open "                         //SDH 23-Aug-2006 Planners
                              "CCDIRSU file. "                              // SDH 26-11-04 CREDIT CLAIM
                              "Check appl event logs");                     // SDH 26-11-04 CREDIT CLAIM
                    break;                                                  // SDH 26-11-04 CREDIT CLAIM
                }                                                           // SDH 26-11-04 CREDIT CLAIM

                //Successful open                                           // SDH 26-11-04 CREDIT CLAIM
                prep_ack("");                                               //SDH 23-Aug-2006 Planners

                //Write audit log                                           // SDH 26-11-04 CREDIT CLAIM
                pLGDSS->cSuccess = 'Y';                                     // SDH 26-11-04 CREDIT CLAIM
                lrt_log(LOG_DSS, hh_unit, dtls);                            // SDH 26-11-04 CREDIT CLAIM

            }                                                               // SDH 26-11-04 CREDIT CLAIM

            break;                                                          // SDH 26-11-04 CREDIT CLAIM

// ------------------------------------------------------------------------------------
//
// DSG - Get Direct Supplier List
//
// ------------------------------------------------------------------------------------

        case CMD_DSG:                                                       // SDH 26-11-04 CREDIT CLAIM

            {                                                               // SDH 26-11-04 CREDIT CLAIM

                //Input and output views                                    // SDH 26-11-04 CREDIT CLAIM
                LRT_DSG *pDSG = (LRT_DSG*)inbound;                          // SDH 26-11-04 CREDIT CLAIM
                LRTLG_DSG *pLGDSG = (LRTLG_DSG*)dtls;                       // SDH 26-11-04 CREDIT CLAIM
                LRT_DSR *pDSR = (LRT_DSR*)out;                              // SDH 26-11-04 CREDIT CLAIM
                LRT_DSE *pDSE = (LRT_DSE*)out;                              // SDH 26-11-04 CREDIT CLAIM

                //Initial checks                                            // SDH 26-11-04 CREDIT CLAIM
                if (IsStoreClosed()) break;                                 // SDH 26-11-04 CREDIT CLAIM
                if (IsHandheldUnknown()) break;                             // SDH 26-11-04 CREDIT CLAIM
                UpdateActiveTime();                                         // SDH 26-11-04 CREDIT CLAIM

                //Set up initial audit fields                               // SDH 26-11-04 CREDIT CLAIM
                pLGDSG->cBusCentre = pDSG->cBusCentre;                      // SDH 26-11-04 CREDIT CLAIM
                memcpy(pLGDSG->abSeqNum, pDSG->abNextSeqNum,                // SDH 26-11-04 CREDIT CLAIM
                       sizeof(pLGDSG->abSeqNum));                           // SDH 26-11-04 CREDIT CLAIM

                //Read the requested record in the CCDIRSU                  // SDH 26-11-04 CREDIT CLAIM
                ccdirsurec.cBusCentre = pDSG->cBusCentre;                   // SDH 26-11-04 CREDIT CLAIM
                memcpy(ccdirsurec.abSeqNum, pDSG->abNextSeqNum,             // SDH 26-11-04 CREDIT CLAIM
                       sizeof(ccdirsurec.abSeqNum));                        // SDH 26-11-04 CREDIT CLAIM
                rc2 = ReadCcdirsu(__LINE__);                                // SDH 26-11-04 CREDIT CLAIM

                //Handle record not found by sending back an end of list    // SDH 26-11-04 CREDIT CLAIM
                //Any other errors generate a NAK                           // SDH 26-11-04 CREDIT CLAIM
                if (rc2 <= 0L) {                                            // SDH 26-11-04 CREDIT CLAIM

                    if (rc2&0xffff != 0x06c8) {                             // SDH 26-11-04 CREDIT CLAIM
                        prep_nak("ERRORUnable to "                          //SDH 23-Aug-2006 Planners
                                 "read from CCDIRSU. "                      // SDH 26-11-04 CREDIT CLAIM
                                 "Check appl event logs");                  // SDH 26-11-04 CREDIT CLAIM
                        close_ccdirsu(CL_SESSION);                          // SDH 26-11-04 CREDIT CLAIM
                        break;                                              // SDH 26-11-04 CREDIT CLAIM
                    }                                                       // SDH 26-11-04 CREDIT CLAIM

                    //Build the reponse and the audit                       // SDH 26-11-04 CREDIT CLAIM
                    memcpy(pDSE->abCmd, "DSE", sizeof(pDSE->abCmd));        // SDH 26-11-04 CREDIT CLAIM
                    out_lth = LRT_DSE_LTH;                                  // SDH 26-11-04 CREDIT CLAIM
                    memcpy(pLGDSG->abSupplierNum, "EOF   ",                 // SDH 26-11-04 CREDIT CLAIM
                           sizeof(pLGDSG->abSupplierNum));                  // SDH 26-11-04 CREDIT CLAIM

                    //Close the file now, as its been fully processed       // SDH 26-11-04 CREDIT CLAIM
                    close_ccdirsu(CL_SESSION);                              // SDH 26-11-04 CREDIT CLAIM

                    //Else success, build DSR and audit                         // SDH 26-11-04 CREDIT CLAIM
                } else {                                                    // SDH 26-11-04 CREDIT CLAIM

                    memcpy(pDSR->abCmd, "DSR", sizeof(pDSR->abCmd));        // SDH 26-11-04 CREDIT CLAIM
                    pDSR->cBusCentre = ccdirsurec.cBusCentre;               // SDH 26-11-04 CREDIT CLAIM
                    memcpy(pDSR->abSeqNum, ccdirsurec.abSeqNum,             // SDH 26-11-04 CREDIT CLAIM
                           sizeof(pDSR->abSeqNum));                         // SDH 26-11-04 CREDIT CLAIM
                    memcpy(pDSR->abSupplierNum, ccdirsurec.abSupplierNum,   // SDH 26-11-04 CREDIT CLAIM
                           sizeof(pDSR->abSupplierNum));                    // SDH 26-11-04 CREDIT CLAIM
                    memcpy(pDSR->abSupplierName, ccdirsurec.abSupplierName, // SDH 26-11-04 CREDIT CLAIM
                           sizeof(pDSR->abSupplierName));                   // SDH 26-11-04 CREDIT CLAIM
                    out_lth = LRT_DSR_LTH;                                  // SDH 26-11-04 CREDIT CLAIM
                    memcpy(pLGDSG->abSupplierNum, ccdirsurec.abSupplierName,    // SDH 26-11-04 CREDIT CLAIM
                           sizeof(pLGDSG->abSupplierNum));                  // SDH 26-11-04 CREDIT CLAIM

                }                                                           // SDH 26-11-04 CREDIT CLAIM

                //Commit audit log                                          // SDH 26-11-04 CREDIT CLAIM
                lrt_log(LOG_DSG, hh_unit, dtls);                            // SDH 26-11-04 CREDIT CLAIM

            }                                                               // SDH 26-11-04 CREDIT CLAIM

            break;                                                          // SDH 26-11-04 CREDIT CLAIM


// ------------------------------------------------------------------------------------
//
// UOQ - UOD Label Enquiry
//
// ------------------------------------------------------------------------------------

        case CMD_UOQ:                                                       // SDH 26-11-04 CREDIT CLAIM

            {                                                               // SDH 26-11-04 CREDIT CLAIM

                //Input and output views                                    // SDH 26-11-04 CREDIT CLAIM
                LRT_UOQ *pUOQ = (LRT_UOQ*)inbound;                          // SDH 26-11-04 CREDIT CLAIM
                LRTLG_UOQ *pLGUOQ = (LRTLG_UOQ*)dtls;                       // SDH 26-11-04 CREDIT CLAIM

                //Initial checks                                            // SDH 26-11-04 CREDIT CLAIM
                if (IsStoreClosed()) break;                                 // SDH 26-11-04 CREDIT CLAIM
                if (IsHandheldUnknown()) break;                             // SDH 26-11-04 CREDIT CLAIM
                UpdateActiveTime();                                         // SDH 26-11-04 CREDIT CLAIM

                //Check whether the required record is present              // SDH 26-11-04 CREDIT CLAIM
                memcpy(cchistrec.abUODNum, pUOQ->abUODNum,                  // SDH 26-11-04 CREDIT CLAIM
                       sizeof(cchistrec.abUODNum));                         // SDH 26-11-04 CREDIT CLAIM
                rc2 = ReadCchist(__LINE__);                                 // SDH 26-11-04 CREDIT CLAIM

                //No error - Label already used - Send NAK                  // SDH 26-11-04 CREDIT CLAIM
                //Record not found - label NOT used before - send an ACK    // SDH 26-11-04 CREDIT CLAIM
                //Other errors - send an error NAK                          // SDH 26-11-04 CREDIT CLAIM
                if (rc2 > 0) {                                              // SDH 26-11-04 CREDIT CLAIM
                    prep_nak("UOD label has previously "                    //SDH 23-Aug-2006 Planners
                             "been used.");                                 // SDH 26-11-04 CREDIT CLAIM
                    break;                                                  // SDH 26-11-04 CREDIT CLAIM
                }                                                           // SDH 26-11-04 CREDIT CLAIM
                if (rc2&0xffff != 0x06c8) {                                 // SDH 26-11-04 CREDIT CLAIM
                    prep_nak("ERRORUnable to "                              //SDH 23-Aug-2006 Planners
                             "read from CCHIST. "                           // SDH 26-11-04 CREDIT CLAIM
                             "Check appl event logs");                      // SDH 26-11-04 CREDIT CLAIM
                    break;                                                  // SDH 26-11-04 CREDIT CLAIM
                }                                                           // SDH 26-11-04 CREDIT CLAIM

                //Good - no record found                                    // SDH 26-11-04 CREDIT CLAIM
                prep_ack("");                                               //SDH 23-Aug-2006 Planners
                pack(pLGUOQ->abUODPacked, 7, pUOQ->abUODNum, 14, 0);        // SDH 26-11-04 CREDIT CLAIM
                pLGUOQ->cDuplicate = 'N';                                   // SDH 26-11-04 CREDIT CLAIM
                lrt_log(LOG_UOQ, hh_unit, dtls);                            // SDH 26-11-04 CREDIT CLAIM

            }                                                               // SDH 26-11-04 CREDIT CLAIM

            break;                                                          // SDH 26-11-04 CREDIT CLAIM

// ------------------------------------------------------------------------------------
//
// STQ - Stock Take Query
//
// ------------------------------------------------------------------------------------

        case CMD_STQ:                                                       // SDH 26-11-04 CREDIT CLAIM

            {                                                               // SDH 26-11-04 CREDIT CLAIM
                //Working vars                                              // SDH 26-11-04 CREDIT CLAIM
                LONG lSeqNum;                                               // SDH 26-11-04 CREDIT CLAIM
                CCHIST_HOME *pHome = (CCHIST_HOME*)&cchistrec;              // SDH 26-11-04 CREDIT CLAIM

                //Input and output views                                    // SDH 26-11-04 CREDIT CLAIM
                LRT_STQ* pSTQ = (LRT_STQ*)inbound;                          // SDH 26-11-04 CREDIT CLAIM
                LRTLG_STQ* pLGSTQ = (LRTLG_STQ*)dtls;                       // SDH 26-11-04 CREDIT CLAIM
                LRT_STR* pSTR = (LRT_STR*)out;                              // SDH 26-11-04 CREDIT CLAIM

                //Initial checks                                            // SDH 26-11-04 CREDIT CLAIM
                if (IsStoreClosed()) break;                                 // SDH 26-11-04 CREDIT CLAIM
                if (IsHandheldUnknown()) break;                             // SDH 26-11-04 CREDIT CLAIM
                UpdateActiveTime();                                         // SDH 26-11-04 CREDIT CLAIM

                //Build home record key from prefix                         // SDH 26-11-04 CREDIT CLAIM
                //Prefix + "000000"                                         // SDH 26-11-04 CREDIT CLAIM
                //and Read the home record from the CCHIST                  // SDH 26-11-04 CREDIT CLAIM
                memset(&cchistrec, 0xFF, sizeof(cchistrec));                // SDH 26-11-04 CREDIT CLAIM
                memset(cchistrec.abUODNum, '0', sizeof(cchistrec.abUODNum));// SDH 26-11-04 CREDIT CLAIM
                memcpy(cchistrec.abUODNum, pSTQ->abUODPrefix,               // SDH 26-11-04 CREDIT CLAIM
                       sizeof(pSTQ->abUODPrefix));                          // SDH 26-11-04 CREDIT CLAIM
                rc2 = ReadCchist(__LINE__);                                 // SDH 26-11-04 CREDIT CLAIM

                //If no error then extract the seq num as a long            // SDH 26-11-04 CREDIT CLAIM
                //Send NAK for errors other than 'record not found'         // SDH 26-11-04 CREDIT CLAIM
                //If record not found error then assume seq num is 0        // SDH 26-11-04 CREDIT CLAIM
                if (rc2 > 0) {                                              // SDH 26-11-04 CREDIT CLAIM
                    lSeqNum = satol(pHome->abLastSeq,                       // SDH 26-11-04 CREDIT CLAIM
                                    sizeof(pHome->abLastSeq));              // SDH 26-11-04 CREDIT CLAIM
                } else {                                                    // SDH 26-11-04 CREDIT CLAIM
                    if (rc2&0xffff != 0x06c8) {                             // SDH 26-11-04 CREDIT CLAIM
                        prep_nak("ERRORUnable to "                          //SDH 23-Aug-2006 Planners
                                 "read from CCHIST. "                       // SDH 26-11-04 CREDIT CLAIM
                                 "Check appl event logs");                  // SDH 26-11-04 CREDIT CLAIM
                        break;                                              // SDH 26-11-04 CREDIT CLAIM
                    }                                                       // SDH 26-11-04 CREDIT CLAIM
                    lSeqNum = 0;                                            // SDH 26-11-04 CREDIT CLAIM
                }                                                           // SDH 26-11-04 CREDIT CLAIM

                //Increment seq num (next after 9999 is 1)                  // SDH 26-11-04 CREDIT CLAIM
                lSeqNum = (lSeqNum%9999) + 1;                               // SDH 26-11-04 CREDIT CLAIM
                sprintf(sbuf, "%06ld", lSeqNum);                            // SDH 26-11-04 CREDIT CLAIM
                memcpy(pHome->abLastSeq, sbuf, sizeof(pHome->abLastSeq));   // SDH 26-11-04 CREDIT CLAIM

                //Write the home record to CCHIST                           // SDH 26-11-04 CREDIT CLAIM
                rc2 = WriteCchist(__LINE__);                                // SDH 26-11-04 CREDIT CLAIM
                if (rc2 <= 0) {                                             // SDH 26-11-04 CREDIT CLAIM
                    prep_nak("ERRORUnable to "                              //SDH 23-Aug-2006 Planners
                             "write to CCHIST. "                            // SDH 26-11-04 CREDIT CLAIM
                             "Check appl event logs");                      // SDH 26-11-04 CREDIT CLAIM
                    break;                                                  // SDH 26-11-04 CREDIT CLAIM
                }                                                           // SDH 26-11-04 CREDIT CLAIM

                //Build the STR response                                    // SDH 26-11-04 CREDIT CLAIM
                memcpy(pSTR->abCmd, "STR", 3);                              // SDH 26-11-04 CREDIT CLAIM
                memcpy(pSTR->abUODPrefix, pSTQ->abUODPrefix,                // SDH 26-11-04 CREDIT CLAIM
                       sizeof(pSTR->abUODPrefix));                          // SDH 26-11-04 CREDIT CLAIM
                sprintf(sbuf, "%06ld", lSeqNum);                            // SDH 26-11-04 CREDIT CLAIM
                memcpy(pSTR->abUODSuffix, sbuf, sizeof(pSTR->abUODSuffix)); // SDH 26-11-04 CREDIT CLAIM
                out_lth = LRT_STR_LTH;                                      // SDH 26-11-04 CREDIT CLAIM

                //Build audit                                               // SDH 26-11-04 CREDIT CLAIM
                pack(pLGSTQ->abUODPrefPkd, 4, pSTR->abUODPrefix, 8, 0);     // SDH 26-11-04 CREDIT CLAIM
                pack(pLGSTQ->abUODSuffPkd, 3, pSTR->abUODSuffix, 6, 0);     // SDH 26-11-04 CREDIT CLAIM
                lrt_log(LOG_STQ, hh_unit, dtls);                            // SDH 26-11-04 CREDIT CLAIM

            }                                                               // SDH 26-11-04 CREDIT CLAIM

            break;                                                          // SDH 26-11-04 CREDIT CLAIM

// ------------------------------------------------------------------------------------
//
// DNQ - Deal Enquiry
//
// Always assume that the first qual and first reward are the important ones.
//
// ------------------------------------------------------------------------------------

        case CMD_DNQ:                                                       // SDH 15-12-04 PROMOTIONS
            DealEnquiry(inbound);                                           // 11-09-2007 12 BMG
            break;                                                          // SDH 15-12-04 PROMOTIONS
        case CMD_PGS:                                                       //SDH 14-Sep-2006 Planners
            PogSessionStart(inbound);                                       //SDH 14-Sep-2006 Planners
            break;                                                          //SDH 14-Sep-2006 Planners
        case CMD_PGX:                                                       //SDH 14-Sep-2006 Planners
            PogSessionExit(inbound);                                        //SDH 14-Sep-2006 Planners
            break;                                                          //SDH 14-Sep-2006 Planners
        case CMD_PGF:                                                       //SDH 14-Sep-2006 Planners
            PogLoadFamilies(inbound);                                       //SDH 14-Sep-2006 Planners
            break;                                                          //SDH 14-Sep-2006 Planners
        case CMD_PGQ:                                                       //SDH 14-Sep-2006 Planners
            PogListQuery(inbound);                                          //SDH 14-Sep-2006 Planners               
            break;                                                          //SDH 14-Sep-2006 Planners
        case CMD_PGM:                                                       //SDH 14-Sep-2006 Planners
            PogListModules(inbound);                                        //SDH 14-Sep-2006 Planners
            break;                                                          //SDH 14-Sep-2006 Planners
        case CMD_PSL:                                                       //SDH 14-Sep-2006 Planners
            PogShelfLoadRequest(inbound);                                   //SDH 14-Sep-2006 Planners
            break;                                                          //SDH 14-Sep-2006 Planners
        case CMD_PGL:                                                       //SDH 14-Sep-2006 Planners
            PogItemEnq(inbound);                                            //SDH 14-Sep-2006 Planners
            break;                                                          //SDH 14-Sep-2006 Planners
        case CMD_PRP:                                                       //SDH 14-Sep-2006 Planners
            PogPrint(inbound);                                              //SDH 14-Sep-2006 Planners
            break;                                                          //SDH 14-Sep-2006 Planners
        case CMD_RCA:                                                       //PAB 24-May-2007 Recalls
            RecallStart(inbound);                                           //PAB 24-May-2007 Recalls
            break;                                                          //PAB 24-May-2007 Recalls
        case CMD_RCB:                                                       //PAB 24-May-2007 Recalls
            RecallExit(inbound);                                            //PAB 24-May-2007 Recalls
            break;                                                          //PAB 24-May-2007 recalls
        case CMD_RCD:                                                       //PAB 24-May-2007 Recalls
            RecallListRequest(inbound);                                     //PAB 24-May-2007 Recalls
            break;                                                          //PAB 24-May-2007 recalls
        case CMD_RCG:                                                       //PAB 24-May-2007 Recalls
            RecallCount(inbound);                                           //PAB 24-May-2007 Recalls
            break;                                                          //PAB 24-May-2007 Recalls
        case CMD_RCH:                                                       //PAB 24-May-2007 Recalls
            RecallSelectList(inbound);                                      //PAB 24-May-2007 Recalls
            break;                                                          //PAB 24-May-2007 recalls
        case CMD_RCI:                                                       //PAB 24-May-2007 recalls
            RecallInstructions(inbound);                                    //PAB 24-May-2007 recalls
            break;                                                          //PAB 24-May-2007 recalls
        case CMD_WRF:                                                       //BMG 03-Jan-2008 14
            WriteToFile(inbound);                                           //BMG 03-Jan-2008 14
            break;                                                          //BMG 03-Jan-2008 14
        case CMD_XXX:                                                       //PAB 22-Nov-2006 recalls
            break;                                                          //PAB 22-Nov-2006 recalls


            //////// END OF MAIN SWITCH STATEMENT/////////
        }                                                                   

        usrrc = RC_OK;

        if (!debug && (lcmd != CMD_XXX)) {
            // Display status summary   
            sprintf( msg, "RF Online units: %02d  Active On Unit: %03d",
                     sess,hh_unit );
            background_msg(msg);
        }

        if (debug && (lcmd != CMD_XXX)) {
            sprintf( msg, 
                     "af    :%02d cimf  :%02d citem :%02d idf   :%02d "
                     "imfp  :%02d imstc :%02d irf   :%02d isf   :%02d",
                     af.sessions, cimf.sessions, citem.sessions, idf.sessions,
                     imfp.sessions, imstc.sessions, irf.sessions, isf.sessions );
            disp_msg(msg);
            sprintf( msg,
                     "plldb :%02d pllol :%02d psbt  :%02d rfrdes:%02d "
                     "stkmq :%02d stock :%02d tsf   :%02d wrf   :%02d",
                     plldb.sessions, pllol.sessions, psbt.sessions, rfrdesc.sessions,
                     stkmq.sessions, stock.sessions, tsf.sessions, wrf.sessions );
            disp_msg(msg);
            sprintf( msg,
                     "invok :%02d rfhist:%02d clolf :%02d clilf :%02d "
                     "minls :%02d                              ",
                     invok.sessions, rfhist.sessions, clolf.sessions, clilf.sessions,
                     minls.sessions );
            disp_msg(msg);
            sprintf( msg, "RFS Units Online: %02d sel:%s gap:%s Processing:",
                     hh_unit, 
                     !status_wk_block?"OK":"ER",
                     !status_wg_block?"OK":"ER" );
            disp_msg(msg);
        }

          
        // Process next stack entry every CHECK_G passes
        // Fix PK/PB 27/11/97 Boots Issue 2 added CMD_XXX check
        if ((cnt++ == CHECK_G) || (lcmd == CMD_XXX)) {                    // PAB 01-03-07

            rc = check_command();

            // Process next outstanding work file
            process_sel_stack();

            //Unstall any stalled printer jobs (only does this every 15 minutes //11-09-2007 12 BMG
            unstall_sel_stack();                                                //11-09-2007 12 BMG

            //Trickle feed any deal updates                                 //SDH 15-12-04 PROMOTIONS
            DealFileTrickle();                                              //SDH 15-12-04 PROMOTIONS

            // so we dont try and start tw PSS47s before the pipe is open   //PAB 01-12-2004
            cnt = 0;                                                        //PAB 01-12-2004
        }

        if (lcmd != CMD_XXX) {
            // Transfer outboud data to return buffer
            memcpy ( (BYTE *)(inbound), out, out_lth );
            //dump((BYTE *)out, out_lth);
            *nbytes = out_lth;
        }

        // Transfer outbound data to return buffer
        if (debug && (lcmd != CMD_XXX)) {
            form_timestamp( ts, sizeof(ts) );
            sprintf(msg, "TX (%s) ", ts);
            disp_msg(msg);
            dump((BYTE *)out, out_lth);
        }

        return( rc );

    }

}                                                                           // end not null command received


