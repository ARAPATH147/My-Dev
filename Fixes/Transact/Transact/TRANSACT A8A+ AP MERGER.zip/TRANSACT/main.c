/*************************************************************************
* 
* 
* File: main.c
*
* Author: Prashant Kotak
*
* Created: 18/08/97
*
* Purpose: Sockets Server for Boots 4690 Application under 
*          IBM version of  FlexOs. Start Module.
*
* History: 
* Version B:         Paul Bowers                18/09/98
* 
* Purpose: To prevent the application from ending if the IP stack
*          is not loaded, rather wait and retry until it is available
* 
*************************************************************************/

#include "transact.h" //SDH 19-May-2006

/* includes */
#include <flexif.h>
#include "sockserv.h"
#include "output.h"
#include "getparms.h"
#include "adxsrvfn.h"
#include "rfsfile.h"                                                        //SDH 18-02-2005

char SockFile[14] ;

char DebugFile[128] ;
int DebugLevel ;
//int BreakLoop = 0 ;

unsigned int LoopDelay = 20 ;
unsigned int BootsHookFreq = 1000 ; 

/* RBS Version Setting */
static char Version[] = "6.0.1";
static char DateStamp[] = "03-09-04";

/* Struct for parsing control file */
#define ENTRIES_SOCKSERV   2
#define ENTRIES_POLLLOOP   3
#define ENTRIES_DEBUG      3
#define ENTRIES_HHTLOG     4

KEYENTRY SockServ[ENTRIES_SOCKSERV] = 
{  { "SOCK_DIR",  'Z', 128, SockDir},  
   { "SOCK_FILE", 'Z', 14, SockFile} 
};

KEYENTRY PollLoop[ENTRIES_POLLLOOP] = 
{
   { "DELAY_IN_MILLS",  'B', sizeof(int), &LoopDelay}, 
   { "BOOTS_HOOK_FREQ", 'B', sizeof(int), &BootsHookFreq},  
   { "POLL_CTL_FILE", 'C', 1, &PollControlFile}
};

KEYENTRY DebugSettings[ENTRIES_DEBUG] = 
{
   { "DEBUG_LEVEL", 'B', sizeof(int), &DebugLevel},
   { "DEBUG_FILE", 'Z', 128, DebugFile},
   { "OUTPUT_TO_FILE", 'C', 1, &OutputToFile}
};

KEYENTRY HhtLogSettings[ENTRIES_HHTLOG] = 
{ 
   { "LIVE_LOG", 'Z', 128, HhtLiveLog},
   { "FLAG_FILE", 'Z', 128, HhtFlagFile},
   { "ARCHIVE_EXT", 'Z', 4, HhtLogExt},
   { "DAYS_TO_KEEP", 'B', sizeof(int), &KeepArchives}
};  

/* external prototypes */
// from Boots Code
int startup ( void ) ;
int shutdown ( void ) ;

void main(int argc, char *argv[])
{
   long lrc;

   //First thing, check whether the comms pipe is already                   //SDH 18-02-2005
   //created -- which means that TRANSACT is already running.               //SDH 18-02-2005
   lrc = s_create(O_FILE, CPIPE_CFLAGS, CPIPE, 1,                           //SDH 18-02-2005
                              0x0FFF, CPIPE_RECL);                          //SDH 18-02-2005
   if (lrc <= 0) {                                                          //SDH 18-02-2005
       sprintf( msg, "Error - Unable to create Comms pipe" );               //SDH 18-02-2005
       disp_msg(msg);                                                       //SDH 18-02-2005
       return;                                                              //SDH 18-02-2005
   }                                                                        //SDH 18-02-2005
   s_close(0, lrc);                                                         //SDH 18-02-2005

   // Parse the control file SOCKSERV.CTL first...
   ParseControlFile () ;

   // Parse the command tails to the program next
   // so that they can override some control file settings
   ParseCommandLineArgs ( argc, argv ) ;    

   // setup the Control-Break handler
   lrc = TermEvent () ;
   if ( lrc < 0L ) {
      LogMessage ( 1, "Ctl-Brk handler failed" ) ;
   }

   // check if protocol stack if loaded
   // ---------------------------------------------------
   // Version B         Paul Bowers               18/9/98
   // Wait here until the stack is loaded 
   //    do not end the application 
   // ---------------------------------------------------

   background_msg("RFS - Waiting for system");
   while ( TcpLoaded() ) {
      OutputMessage ( MSG_NOSTACK ) ;
      s_timer(0,5000);
   }


   // initialise sockets bits ...
   InitialiseSocketServer () ;

    
   startup () ;
   //if ( rc == 0 ) {
   // sit in a sockets loop /
       SocketServerLoop () ;
   //} else {
   //   LogMessage ( 1, "Socket Server not started: startup() returned %d", rc ) ;
   //   background_msg("RFS- TCP/IP Error - No sockets");
   // }


   // shutdown boots bits should never reach this code as app runs for ever
   shutdown () ;
   OutputMessage ( MSG_STOPPED ) ;
}

void ParseControlFile ( void )
{
   // Our control file is called SOCKSERV.CTL and resides
   // wherever RF: points to 

   GetParms ( "RF:SOCKSERV.CTL", 
                   "SOCKSERV", 
                   SockServ, 
                   sizeof (KEYENTRY),
                   ENTRIES_SOCKSERV) ;

   LogMessage ( 6, "SockDir: %s", SockDir ) ; 
   LogMessage ( 6, "SockFile: %s", SockFile ) ;

   GetParms ( "RF:SOCKSERV.CTL", 
                   "POLL_LOOP", 
                   PollLoop, 
                   sizeof (KEYENTRY),
                   ENTRIES_POLLLOOP) ;

   LogMessage ( 6, "DelayInMills: %d", LoopDelay ) ; 
   LogMessage ( 6, "BootsHookFreq: %d", BootsHookFreq ) ;
   LogMessage ( 6, "PollControlFile: %c", PollControlFile ) ;

   GetParms ( "RF:SOCKSERV.CTL", 
                   "DEBUG", 
                   DebugSettings, 
                   sizeof (KEYENTRY),
                   ENTRIES_DEBUG) ;

   LogMessage ( 6, "DebugLevel: %d", Debug ) ; 
   LogMessage ( 6, "DebugFile: %s", DebugFile ) ;
   LogMessage ( 6, "OutputToFile: %c", OutputToFile ) ;

   GetParms ( "RF:SOCKSERV.CTL", 
                   "HHTLOG", 
                   HhtLogSettings, 
                   sizeof (KEYENTRY),
                   ENTRIES_HHTLOG) ;

   LogMessage ( 6, "HhtLiveLog: %s", HhtLiveLog ) ;
   LogMessage ( 6, "HhtFlagFile: %s", HhtFlagFile ) ;
   LogMessage ( 6, "HhtLogExt: %s", HhtLogExt ) ; 
   LogMessage ( 6, "KeepArchives: %d", KeepArchives ) ;

   // processing, having read in the parameters
   Debug = DebugLevel ;
   if ( OutputToFile == 'Y' ) {
      // open the Debug Output file
      if ( DebugFileHandle == NULL ) {
         DebugFileHandle = fopen ( DebugFile, "w+" ) ;
      }
   } else {
      if ( DebugFileHandle != NULL ) {
         fclose ( DebugFileHandle ) ;
         DebugFileHandle = NULL ;
      }
   }
}

void ParseCommandLineArgs ( int argc, char *argv[] )
{
   int c ;

   for ( c = 1 ; c < argc ; c++ ) {
      switch ( argv[c][1] ) {
      case 'b' :
      case 'B':
         BreakLoop = 1 ;        
         LogMessage ( 2, "Break in Server Poll Loop enabled" ) ;
         break ;

      case 'd':
      case 'D':
         Debug = 10;
         LogMessage ( 2, "Full Debug ON (level 10)" ) ;
         break; 

      case 'v':
      case 'V': 
         printf ( "Boots/IBM RF Socket Server Version %s\r\n", Version ) ;
         printf ( "Release Date %s\r\n", DateStamp ) ;
         ParseControlFile () ;
         ExitApplication () ;
         break;

      default:
         LogMessage( 9, "Unrecognised Option");
      }
   } 
}
