#ifndef OSFUNC_H
#define OSFUNC_H

// prototypes for local routines
static long OpenFileForSendTx ( FILEINFO * FileInfo ) ; 
static long OpenFileForReceiveTx ( FILEINFO * FileInfo ) ;
static void CloseFile ( long ) ; 
//static long SeekToEndOfFile ( long FileHandle );
static long GetFileSize ( long, FILEINFO * ) ;
static long GetNextFilePacket ( long, unsigned char *, FILEINFO * ) ; 
static long PutNextFilePacket ( long, unsigned char *, FILEINFO * ) ;
static void * MallocShuffle ( char *, int * ) ;

static int TouchFile ( char * FileName, char * DateStr ) ;
static void TouchOrCreateFlagFile () ;
static long LookupFileDetails ( char * FileName, long Key, 
                                DISKFILE * FileDetails ) ; 
static long GetFileDate ( char * DateStr, char * FileName, long Key ) ;
static struct tm * CurrentDateTime () ; 
static void ExtractDateFromDateStr ( char * DateStr, int * Day, 
                                     int * Month, int * Year ) ;
static long JulianDay ( char * DateStr ) ; 
static int DeleteIfOlder ( DISKFILE * FileDetails ) ;

void CtlBrkHandler ( void );    // v4.01

#endif

