
// ------------------------------------------------------------------------
//                     Boots The Chemists Store Systems
//                  Radio Frequency Transaction Processor
// 
// Version 1.0               Paul Bowers       8th August 2007
// 
// MOdule TRANS02 reached 64K limit - split into next module.
// Entire module implemented for Mobile Printing.
//
// Version 1.1         Brian Greenfield        11th September 2007
// Added function unstall_sel_stack to set stack entries to ready.
// Added dump_pq_stack taken from rfs.c due to space.
// Added DealEnquiry taken from transact.c due to space.
// Added CycleLogs taken from rfs.c due to space.
//
// Version 1.2         Brian Greenfield        17th October 2007
// Fix for mobile printing.
//  
// Version 1.3         Paul Bowers              8th November 2007
// Changes to support painkiller warnings on the LPR transaction
// new function process painkiller and new file SELDESC.BIN  
//
// Version 1.4         Brian Greenfield         3rd January 2008
// Added WriteToFile function for WRF command.
//
// Version 1.5         Brian Greenfield         1st April 2008
// Moved process_sel_stakc into here from trans02.c.
//
// Version 1.6         Brian Greenfield         13th August 2008
// Added MultiSite function for Multi-Sited Counts.
// Moved LRT_PRT function into here from transact.c and called it trans04_LRT_PRT.
// -----------------------------------------------------------------------

/* standard include files */
#include "transact.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <flexif.h>


#include "trans2.h"                                      
#include "file.h"  


// ----------------- transaction definitions ------------------------                     
#include "rfs.h"  
#include "rfs2.h" 
                
                 
// -----------------file definitions --------------------------------                     
#include "rfsfile.h"      // files used in all modules
#include "rfsfile2.h"     // files used only in TRANS02 and TRANS03
#include "rfsfile3.h"     // files used only in TRANS03


// ---------------- standard functions and globals -----------------------------
#include "dateconv.h"
#include "wrap.h"
#include "sockserv.h"
#include "rfglobal.h"                   
#include "rfglobal2.h" 
#include "rfglobal3.h"
#include "adxsrvfn.h"                   
#include "adxsrvst.h"  

static ENQUIRY enqbuf;                                      // BMG 1.6 13-08-2008
static PRTCTL_REC prtctlrec;                                // BMG 1.6 13-08-2008 
static LONG sec, day, month, year;                          // BMG 1.6 13-08-2008
static WORD hour, min;                                      // BMG 1.6 13-08-2008
static BYTE authority[1], username[32];                     // BMG 1.6 13-08-2008


void MultiSite(char *inbound) { // BMG 1.6 13-08-2008

   LRT_MSA* pMSA = (LRT_MSA*)inbound;
   LRT_MSB* pMSB = (LRT_MSB*)out;
   LONG rc;
   int i;

   UNUSED(inbound);

   //Build the key and attempt the read
   memcpy( plldbrec.list_id, pMSA->list_id, 3 );
   memcpy(plldbrec.seq, pMSA->seq, 3);

   //Attempt read of PLLDB
   //If record not found return error - we should only be sent known list numbers
   rc = ReadPlldbLog(__LINE__, LOG_CRITICAL);
   if (rc<=0L) {
       if (rc == RC_DATA_ERR) {
           prep_nak("ERRORUnable to read from PLLDB. "
                     "Check appl event logs" );
       } else {
           prep_nak("ERRORUndefined 7. "
                     "Check appl event logs" );
       }
       return;
   }

   // return MSB transaction 
   memcpy(pMSB->cmd, "MSB", sizeof(pMSB->cmd)); 
   memcpy(pMSB->opid, pMSA->opid, sizeof(pMSA->opid));
   memcpy(pMSB->list_id, pMSA->list_id, sizeof(pMSA->list_id));
   memcpy(pMSB->seq, pMSA->seq, sizeof(pMSA->seq));

   for (i=0;i<11;i++) 
   {
       unpack(pMSB->abShelfCount+(i*4), 4, plldbrec.aMS_details[i].ms_loc_count, 2, 0 );
       unpack(pMSB->abFillQty+(i*4), 4, plldbrec.aMS_details[i].ms_fill_qty, 2, 0 );
   }

   out_lth = LRT_MSB_LTH;     

}


void trans04_LRT_PRT(char *inbound) { // BMG 1.6 13-08-2008

   //Static (permanent) data
   static BYTE abLastItemCode[13] = "";                        
   LRT_PRT* pPRT = (LRT_PRT*)inbound;                          // SDH 12-Oct-2006
   time_t CurrTime;                                            //11-09-2007 12 BMG

   URC usrrc = RC_OK;                                          // BMG 1.6 13-08-2008
   int rc = 0;                                                 // BMG 1.6 13-08-2008

   memset( (BYTE *)&prtctlrec, 0x00, sizeof(PRTCTL_REC) );     // BMG 1.6 13-08-2008

   if (IsHandheldUnknown()) return;                            // SDH 26-11-04 CREDIT CLAIM // BMG 1.6 13-08-2008
   // If local type print the the PPC needs extra info.        // 07-08-07 PAB Mobile Printing
   if (strncmp(pPRT->type,"L",1)== 0) {                        // 07-08-07 PAB Mobile Printing
       usrrc = BuildLPR(inbound);                              // 07-08-07 PAB Mobile Printing
       if (usrrc==1) {                                         // 08-08-07 PAB
           prep_nak("ERRORItem not on file"                    // 08-08-07 PAB
                    "Check appl event logs" );                 // 08-08-07 PAB
           return;                                             // 08-08-07 PAB // BMG 1.6 13-08-2008
       }    
       return;                                                 // 07-08-07 PAB Mobile Printing // BMG 1.6 13-08-2008
   }
   
   // if barcode is zeros then get update on printer status    // 19-02-04 PAB
   // new functionality Phase 2 Proximity printing             // 19-02-04 PAB
   if (strncmp(pPRT->item_code, "0000000000000", 13 ) == 0) {  // 19-02-04 PAB
       // Get SEL printer status                               // 19-02-04 PAB
       usrrc = open_prtctl();                                  // 19-02-04 PAB
       if (usrrc<=RC_DATA_ERR) {                               // 19-02-04 PAB
           prep_nak("ERRORUnable to open PRTCTL file. "        //SDH 23-Aug-2006 Planners
                     "Check appl event logs" );                // 19-02-04 PAB
           return;                                             // 19-02-04 PAB // BMG 1.6 13-08-2008
       }                                                       // 19-02-04 PAB
       // read the current status record & close the file      // 19-02-04 PAB
       rc = s_read( A_BOFOFF, prtctl.fnum,                     // 19-02-04 PAB
                    (void *)&prtctlrec, PRTCTL_RECL, 0L);      // 19-02-04 PAB
       if (rc<=0L) {                                           // 19-02-04 PAB
           log_event101(rc, PRTCTL_REP, __LINE__);             // 19-02-04 PAB
           printf("ERR-R PRTCTL. RC:%081X", rc);               // 19-02-04 PAB
       }                                                       // 19-02-04 PAB
       // 19-02-04 PAB
       usrrc = close_prtctl(CL_SESSION);                       // 19-02-04 PAB
       // Prep SNR tx and Break;                               // 19-02-04 PAB
       // Authorise user                                       // 19-02-04 PAB
       // 19-02-04 PAB
       usrrc = open_af();                                      // 19-02-04 PAB
       if (usrrc<=RC_DATA_ERR) {                               // 19-02-04 PAB
           prep_nak("ERRORUnable to open EALAUTH file. "       //SDH 23-Aug-2006 Planners
                     "Check appl event logs" );                // 19-02-04 PAB
           return;                                             // 19-02-04 PAB // BMG 1.6 13-08-2008
       }                                                       // 19-02-04 PAB
       usrrc = authorise_user( ((LRT_SOR *)(inbound))->opid,   // 19-02-04 PAB
                               ((LRT_SOR *)(inbound))->pass,   // 19-02-04 PAB
                               (BYTE *)&authority,             // 19-02-04 PAB
                               (BYTE *)&username );            // 19-02-04 PAB
       close_af( CL_SESSION );                                 // 19-02-04 PAB
       if (usrrc<RC_IGNORE_ERR) {                              // 19-02-04 PAB
           prep_nak("ERRORauthorise_user failed"               //SDH 23-Aug-2006 Planners
                     "Check appl event logs" );                // 19-02-04 PAB
           return;                                             // 19-02-04 PAB // BMG 1.6 13-08-2008
       }                                                       // 19-02-04 PAB
       // 19-02-04 PAB
       // Save user ID                                         // 19-02-04 PAB
       MEMCPY(lrtp[hh_unit]->user, ((LRT_SOR *)(inbound))->opid);// 19-02-04 PAB
       // Get time                                             // 19-02-04 PAB
       sysdate( &day, &month, &year, &hour, &min, &sec );      // 19-02-04 PAB

       // Prepare SNR                                          // 19-02-04 PAB
       buildSNR((LRT_SNR *)&out, prtctlrec.prtnum,             // 16-11-2004 SDH
                ((LRT_SOR *)(inbound))->opid, authority[0],    // 16-11-2004 SDH
                username, rfscfrec1and2.ossr_store,            // 25-Sep-2006 SDH Planners
                rfscfrec1and2.cPlannersActive);                // 25-Sep-2006 SDH Planners

       out_lth = LRT_SNR_LTH;                                  // 19-02-04 PAB
       //authorised = TRUE;                                    // 19-02-04 PAB
       ((LRTLG_SOR *)dtls)->authority[0] = 'Y';                // 17-11-04 SDH
       memset( ((LRTLG_SOR *)dtls)->resv, 0x00, 11 );          // 19-02-04 PAB
                                                               // 19-02-04 PAB
       return;                                                 // 19-02-04 PAB // BMG 1.6 13-08-2008
   }                                                           // 19-02-04 PAB

   if (IsStoreClosed()) return;                                // SDH 26-11-04 CREDIT CLAIM // BMG 1.6 13-08-2008

   //Check that item is on file, if it wasn't the last item    // SDH 26-11-04 CREDIT CLAIM
   //checked                                                   // SDH 26-11-04 CREDIT CLAIM
   if (strncmp(pPRT->item_code,                                // SDH 26-11-04 CREDIT CLAIM
               abLastItemCode, sizeof(abLastItemCode)) != 0) { // SDH 26-11-04 CREDIT CLAIM
       usrrc = stock_enquiry(SENQ_BOOTS, pPRT->item_code,      // SDH 26-11-04 CREDIT CLAIM
                             &enqbuf);                         // SDH 26-11-04 CREDIT CLAIM
       if (usrrc != RC_OK) {                                   // SDH 26-11-04 CREDIT CLAIM
           prep_nak("Item is not on file.");                   // SDH 23-Aug-2006 Planners
           return;                                             // SDH 26-11-04 CREDIT CLAIM // BMG 1.6 13-08-2008
       }                                                       // SDH 26-11-04 CREDIT CLAIM
   }                                                           // SDH 26-11-04 CREDIT CLAIM

   //Save away last item                                       // SDH 26-11-04 CREDIT CLAIM
   MEMCPY(abLastItemCode, pPRT->item_code);                    // SDH 26-11-04 CREDIT CLAIM

   // Write entry to LAB workfile (#1)
   MEMCPY(selbfrec.item_code, pPRT->item_code);
   MEMCPY(selbfrec.info, lrtp[hh_unit]->user);
   MEMCPY(selbfrec.info + 3, "000");
   selbfrec.printerid[0] = pPRT->type[0];                        // 18-02-04 PAB
   LONG rc2 = s_write( A_FLUSH | A_FPOFF, lrtp[hh_unit]->fnum1,
                  (void *)&selbfrec, SELBF_RECL, 0L );

   //sprintf(msg, "RC= :, %d",rc2);
   //disp_msg(msg);

   time(&CurrTime);                                            //11-09-2007 12 BMG
   pq[lrtp[hh_unit]->pq_sub1].last_access_time = CurrTime;     //11-09-2007 12 BMG
   
   if (rc2 >= 0) {                                             //PAB 28-NOv-2006
       prep_ack("");                                           //SDH 23-Aug-2006 Planners
   } else {
       rc2 = prepare_workfile( hh_unit, SYS_LAB );   
       // Write entry to LAB workfile (#1)
       MEMCPY(selbfrec.item_code, pPRT->item_code);
       MEMCPY(selbfrec.info, lrtp[hh_unit]->user);
       MEMCPY(selbfrec.info + 3, "000");
       selbfrec.printerid[0] = pPRT->type[0];                  // 18-02-04 PAB
       rc2 = s_write( A_FLUSH | A_FPOFF, lrtp[hh_unit]->fnum1,
                      (void *)&selbfrec, SELBF_RECL, 0L );
       pPRT->type[0] = '0';                                    // 24-02-04 PAB
       if (rc2>=0) {                                           //PAB 28-Nov-2006
           prep_ack("");                                       //SDH 23-Aug-2006 Planners
       } else {
           log_event101(rc, SELBF_REP, __LINE__);
           prep_nak("ERRORUnable to write to temp SELBF. "     //SDH 23-Aug-2006 Planners
                     "Check appl event logs" );
           return;                                             // BMG 1.6 13-08-2008
       } 
   }


   // Audit
   //  memset( ((LRTLG_PRT *)dtls)->resv, 0x00, 11 );                             // 25-8-2004 PAB
   memcpy(((LRTLG_PRT *)dtls)->resv, ((LRT_PRT *)(inbound))->item_code, 12 );    // 25-8-2004 PAB
   lrt_log( LOG_PRT, hh_unit, dtls );
}
