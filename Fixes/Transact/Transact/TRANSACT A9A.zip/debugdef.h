#if !defined DEBUGDEF_H
#define DEBUGDEF_H 1

// Debug
#define DBG_LOCAL       0
#define DBG_FILE        1

//FILE_CTRL dbg;

#endif /* DEBUGDEF_H not defined */


