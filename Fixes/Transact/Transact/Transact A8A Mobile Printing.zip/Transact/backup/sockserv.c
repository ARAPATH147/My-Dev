/*************************************************************************
* 
* 
* File: sockserv.c
*
* Author: Prashant Kotak
*
* Created: 18/08/97
*
* Purpose: High Level TCP/IP vendor-independant Sockets Server.
*
* History: 
*
* Version B Paul Bowers 
*
* Created 28/08/2004
*
* Purpose - Track PPC unit IP address to enable reconnection
* resource reuse rather than incremental allocation for each new PPC
* which connects without a valid disconnect. So if a unit connects and
* its IP addres is already known send the old UNIT number to the main 
* core.
* 
*************************************************************************/

#include "transact.h" //SDH 19-May-2006
#include "rfglobal.h"  //SDH 21-June-2006

#include <time.h>
#include "output.h"
#include "sockserv.h"
#include <flexif.h>
#include <stdio.h>
#include "adxsrvfn.h"
#include "file.h"                                                           //SDH 16-05-2005
#include "debug.h"                                                          //SDH 16-05-2005

#define STKCF     "STKCF"
#define STKCF_OFLAGS    0x2018
#define STKCF_REP 0

#define POLL_FREQ 5000L

//extern unsigned int LoopDelay ;
//extern unsigned int BootsHookFreq ;
//extern char PollControlFile ;
//extern long OpenDirectFile ( char *, unsigned int, int ) ;
//extern void CloseAllFiles ( void ) ;

CLIENT    *Clients[MAX_SOCKETS];              // client details TCP/IP table
sock_handle  PrimarySocketHandle;             // primary socket handle

extern int tcperrno;

int TcpLoaded ( void )
{
   // check if protocol stack is loaded
   // return TRUE if loaded, FALSE otherwise
   return IsTcpLoaded() ;
}

void InitialiseSocketServer ( void )
{
   int i ;

   // initialise the Client structure
   for ( i = 0 ; i < MAX_SOCKETS ; i++ ) {
      // mark all client slots as not allocated
      Clients[i] = NULL ; 
   }

   // allocate socket
   if ( AllocateSocket ( &PrimarySocketHandle ) < 0 ) {
      OutputMessage ( MSG_SOCKFAIL ) ;
      exit ( 1 ) ;
   }

   // bind address/port to socket
   if ( BindSocket ( &PrimarySocketHandle, HHTCOMMS_PORT ) < 0 ) {          // SDH 19-05-2005
      OutputMessage ( MSG_BINDFAIL ) ;
      exit ( 1 ) ;
   }

   if ( ListenOnSocket ( &PrimarySocketHandle ) < 0 ) {
      OutputMessage ( MSG_LSTNFAIL ) ;
      exit ( 1 ) ;
   }

   // if we got here, the socket setup succeeded
   OutputMessage ( MSG_READY ) ;
}

void SocketServerLoop(void)
{
   int key;
//   clock_t lCurrentTime = 0 ; 
//   clock_t lPreviousTime = 0 ;
   LONG lCurrentTime=0L, lPreviousTime=0L;
   TIMEDATE now;   

   // loop forever, waiting for: 
   //        i.  Anyone to disconnect
   //       ii.  New connections
   //      iii.  Any Receives  
   //       iv.  Anything to send
   // no calls in the loop will block
   // N.B: The order in which ProcessPendingXXXX funcs are called is important!
   for (;;) {
      // anyone already connected tried to break connection? 
      ProcessPendingDisconnects () ;

      // has anyone new attempted connection?
      // ProcessPendingConnects ( &PrimarySocketHandle ) ;

      // anyone already connected tried to talk to us?
      ProcessPendingReceives () ;

      // reply to anyone already connected
      ProcessPendingSends () ;

      if ( BreakLoop != 0 ) {
         // wait... 
         LogMessage( 0, "Press ESC to END or any key to continue...") ;
         key = getchar () ;
         if ( key == 27 ) {
            CtlBrkHandler () ;
            break;
         }
      }

      // call into Boots Code every POLL_FREQ mS 
      // also reload control file if flag set
      // also check if HHT logs need recycling

//      lCurrentTime = clock () / CLOCKS_PER_SEC ; 
      s_get( T_TD, 0L, (void *)&now, TIMESIZE );
      lCurrentTime = now.td_time;

      if ( ( ( lPreviousTime + POLL_FREQ ) < lCurrentTime ) ||
           ( lCurrentTime < lPreviousTime ) ) {
         static int iStoreCloseCheck = 0 ;

         if ( iStoreCloseCheck++ % 4 == 0 ) {
            long lSTKCFHandle = 0 ;

            LogMessage ( 7, "Check for store closed flag" ) ;

            lSTKCFHandle = OpenDirectFile (STKCF, STKCF_OFLAGS, STKCF_REP, TRUE);    //SDH

            if ( lSTKCFHandle ) {
               char pBuff[12] ;
               //int rc = 0 ;

               //rc = s_read ( 0, lSTKCFHandle, pBuff, sizeof pBuff, 0L ) ;
               s_read ( 0, lSTKCFHandle, pBuff, sizeof pBuff, 0L ) ;

               if ( pBuff[10] == 'N' ) {
                  LogMessage ( 7, "Store is closed" ) ;
                  CloseAllFiles () ;
                  cStoreClosed = 'Y' ;
                  background_msg("RFS - Closed");
               } else {
                  LogMessage ( 7, "Store is open" ) ;
                  sprintf(msg,"RFS - Ready and Waiting... - Online: %02d",sess);
                  background_msg(msg);                               // 25-8-2004 PAB
                  cStoreClosed = 'N' ;
               }

               s_close ( 0, lSTKCFHandle ) ;
            } else {
               LogMessage ( 1, "Could not open STKCF" ) ;
            }
         }

         LogMessage ( 7, "Dummy call to Boots code" ) ;
         // call into Boots code
         DummyCallToProcess () ; 

         // re-parse control file
         if ( PollControlFile == 'Y' ) {
            ParseControlFile () ;
         }

         /* SDH - 26-11-2004  Redundant code
         // cycle HHT logs
         if ( DateHasChanged () ) {
            CycleHhtLogs () ;
         }
         */
         
//         lPreviousTime = clock () / CLOCKS_PER_SEC ;
         
      }

      lPreviousTime = lCurrentTime;

      // add a delay using system calls so that OS gives other processes
      // a chance ( LoopDelay controlled by control file parameter )
      //DelayProcess ( ( long ) LoopDelay ) ; 


      //lEndTime = clock () ;

      //lElapsedTime = lEndTime - lStartTime ; 

      //LogMessage ( 10, "Loop time  %ld    \n", lElapsedTime ) ;

      //lStartTime = clock () ;
   }
}

void ProcessPendingConnects ( sock_handle *SockHandle )
{
   static int index = -1 ; // initalise to 'not assigned'
   int result ;

   LogMessage ( 10, "Processing pending connects" ) ;

   do {
      // get a new slot if the memory for one is not already allocated
      if ( index < 0 ) {
         index = GetFreeClientSlot () ;
      }

      if ( index >= 0 ) {
         // Got an assigned slot. Try to accept on the socket
         LogMessage ( 10, "About to attempt AcceptOnSocket" ) ;
         result = AcceptOnSocket ( SockHandle, Clients[index] ) ;
         if ( result >= 0 ) {
            // Conncetion was accepted. Check if this HHT (IP address)
            // is already logged on and if so, use the old connection instead
            index = ClearOldClientConnection ( index ) ;                    //SDH 16-05-2005

            // record who it is, for when we have 
            // to tell Boots app the HH_UNIT ID
            Clients[index]->HhtId = index ;

            index = -1 ; // we'll need a new ClientSlot next time
         }
         //else
         //{ 
         //    // accept did not have anyone awaiting connects or accept failed
         //    ReleaseClientSlot ( index ) ;
         //}
      } else {
         result = 0 ; // no more free Client slots available
      }
   }
   while ( result >= 0 ) ;
}

void ProcessPendingReceives ( void )
{
   int i, j, rc ;
   int sock_read  [MAX_SOCKETS] = { 0} ;
   int sock_index [MAX_SOCKETS] = { 0} ;

   // Check the Client structure for sockets who can
   // receive and build a handles array of those who can
   
   // Set to test for reads on primary socket
   sock_read [0] = PrimarySocketHandle ;
   sock_index [0] = 0 ;
   
   // Set up child sockets
   for ( j = 1, i = 0 ; i < MAX_SOCKETS ; i++ ) {
      if ( Clients[i] != ( void * ) NULL ) {
         if ( Clients[i]->InUse == 1 && 
              Clients[i]->SocketHandle >= 0 &&
              Clients[i]->SocketState == AWAITING_INPUT ) {
            // add the socket handle on which we expect a read to our array
            sock_read[j] = Clients[i]->SocketHandle ;
            // record the index in parallel
            sock_index[j++] = i ; 
         }
      }
   }

   LogMessage( 7, "Awaiting Receive from %d clients", j ) ;
   // printf( "Awaiting Receive from %d clients\n", j ) ;

   // setup multiplexed test to find which sockets are ready to be read
   rc = SocketGroupStatus ( &sock_read[0], j, STATUS_READ ) ;

   // printf ( "Select ended rc = %d\n", rc ) ; 

   if ( sock_read[0] != -1 ) {
      ProcessPendingConnects ( &PrimarySocketHandle ) ;
   }

   else {
      if ( rc > 0 ) { // the group status check shows 1 or more sockets to read
         // process all the ready sockets
         for ( i = 1 ; i < j ; i++ ) {
            if ( sock_read[i] != -1 ) {
               LogMessage( 10, "Socket Handle %d is ready to be read", i );

               // found socket ready with data, so read it
               rc = ReadSocket ( Clients[sock_index[i]] ) ;

               
               if ( rc > 0 ) {
                  // we've got some data from the client, so process it
                  //ProcessMessage ( Clients[sock_index[i]] ) ;
                   ProcessBootsCommand ( Clients[sock_index[i]] ) ;  // 22-5-07 PAB


                  // ...and set state 'awaiting send to client'
                  Clients[sock_index[i]]->SocketState =  AWAITING_OUTPUT ;
               }
            } else {
               LogMessage ( 1, "Client %d (SocketHandle=%d) failed on READ select()",
                            sock_index[i], Clients[sock_index[i]]->SocketHandle );
            }
         }
      }
   }
}

void ProcessPendingSends(void)
{
   int i, j, rc;
   int sock_write[MAX_SOCKETS], sock_index[MAX_SOCKETS];

   // Check the Client structure for sockets to whom
   // we have to send and build a handles array of these
   for (j = 0, i = 0; i < MAX_SOCKETS; i++) {
      if (Clients[i] != NULL) {
         // we have to send an ACK _before_ we disconnect
         // so we still send even if we are awaiting disconnect.
         if (Clients[i]->InUse == 1 &&  
             Clients[i]->SocketHandle >= 0 &&
             (Clients[i]->SocketState == AWAITING_OUTPUT || 
              Clients[i]->SocketState == AWAITING_DISCONNECT)) {
            // add socket handle on which we expect a read to our array
            sock_write[j] = Clients[i]->SocketHandle ;
            // record the index in parallel
            sock_index[j++] = i ; 
         }
      }
   }

   if (j > 0 ) {
      LogMessage( 9, "Awaiting Send to %d clients", j ) ;
      // setup multiplexed test to find which sockets are ready to be read
      rc = SocketGroupStatus(sock_write, j, STATUS_WRITE);

      //if (rc > 0)
      {
         // process all the ready sockets
         for (i = 0; i < j; i++) {
            if (sock_write[i] != -1) {
               LogMessage( 10, "Socket Handle %d is ready to be written", i );

               // socket ready, so write to it whatever we've prepared
               rc = WriteSocket(Clients[sock_index[i]]);

               if (rc > 0 && 
                   Clients[sock_index[i]]->SocketState == AWAITING_OUTPUT) {
                  // ...and set state to 'awaiting message from client'
                  Clients[sock_index[i]]->SocketState = AWAITING_INPUT;
               }
            } else {
               LogMessage ( 1, "Client %d (SocketHandle=%d) failed on select() WRITE",
                            sock_index[i], Clients[sock_index[i]]->SocketHandle );
            }
         }
      }
   }
}

void ProcessPendingDisconnects ( void )
{ 
   int i ;

   // Check the Client structure for sockets we can disconnect immediately
   for (i = 0; i < MAX_SOCKETS; i++) {
      if (Clients[i] != NULL) {
         // look for sockets awaiting disconnect.
         if ( Clients[i]->InUse == 1 &&  
              Clients[i]->SocketHandle >= 0 &&
              Clients[i]->SocketState == ERROR_STATE ) {
            LogMessage( 7, "Disconnecting Client %d (SocketHandle=%d)...", 
                        i, Clients[i]->SocketHandle ); 
            CloseSocket( &(Clients[i]->SocketHandle));
            ReleaseClientSlot(i); 
            LogMessage( 7, "...Client %d Disconnected!", i);
         }
      }
   } 
}

int GetFreeClientSlot(void)
{
   int found, i;

   LogMessage( 10, "In GetFreeClientSlot");    

   // Check the Client structure for any empty slots
   for (found = 0, i = 0; i < MAX_SOCKETS; i++) {
      if (Clients[i] == NULL) {
         // found an unused slot so assign memory to it
         Clients[i] = (CLIENT *) AllocateBuffer ( sizeof ( CLIENT ) ) ;
         memset(Clients[i], 0, sizeof(CLIENT)) ;

         // allocate a default size for the buffer
         Clients[i]->Buffer = ( char * ) AllocateBuffer(BUFFER_SIZE) ;
         memset(Clients[i]->Buffer, 0, BUFFER_SIZE);

         LogMessage( 10, "Client slot allocation successful" ) ;

         if (Clients[i] != NULL) {
            Clients[i]->BufferSize = BUFFER_SIZE; 
            found = 1; // mark it assigned 
            LogMessage( 10, "Buffer Size for allocated Client = %d", 
                        Clients[i]->BufferSize);
         }

         // we've finished, so break out of loop
         break;
      }
   } 
   return (found ? i : -1); // if found then i else -1
}


int ClearOldClientConnection(int SlotIndex)                                 //SDH 16-05-2005
{
   int i, rc;
   struct sockaddr_in *addr1;
   struct sockaddr_in *addr2;

   // work out IP address of New connection
   addr1 = (struct sockaddr_in *) &(Clients[SlotIndex]->SocketAddress); 

   if (debug) {                                                //SDH 16-05-2005
        sprintf(msg, "New connection from IP address: "        //SDH 16-05-2005
                "%d.%d.%d.%d", *((char*)(&addr1->sin_addr)),   //SDH 16-05-2005 
                *((char*)(&addr1->sin_addr)+1),                //SDH 16-05-2005 
                *((char*)(&addr1->sin_addr)+2),                //SDH 16-05-2005 
                *((char*)(&addr1->sin_addr)+3));               //SDH 16-05-2005 
        disp_msg(msg);                                         //SDH 16-05-2005
   }                                                           //SDH 16-05-2005

   // we are going to cycle round the clients to see if the 
   // IP address of the new connection matches any of the old clients
   for (i = 0; i < MAX_SOCKETS; i++) {
      if (Clients[i] != NULL) {
         // In use and not the new one
         if (Clients[i]->InUse == 1 && i != SlotIndex) {
            addr2 = (struct sockaddr_in *) &(Clients[i]->SocketAddress); 

            rc = memcmp((char *) &(addr2->sin_addr), 
                        (char *) &(addr1->sin_addr),
                        4);

            if (rc == 0) { // Same HHT (IP addr) has tried to log on again
               
                if (debug) {                                                //SDH 16-05-2005
                    sprintf(msg, "HHT previously on slot:%d handle:%d!",    //SDH 16-05-2005 
                           i, Clients[i]->SocketHandle);                    //SDH 16-05-2005
                    disp_msg(msg);                                          //SDH 16-05-2005
                }                                                           //SDH 16-05-2005

                //We're going to use the old slot rather than the new.      //SDH 16-05-2005
                //Close the old socket, replace the socket address in the   //SDH 16-05-2005
                //old slot, then delete the new slot                        //SDH 16-05-2005
                CloseSocket(&(Clients[i]->SocketHandle));                   //SDH 16-05-2005
                Clients[i]->SocketAddress = Clients[SlotIndex]->SocketAddress;//SDH 16-05-2005
                Clients[i]->SocketHandle = Clients[SlotIndex]->SocketHandle;//SDH 16-05-2005
                Clients[i]->SocketState = Clients[SlotIndex]->SocketState;  //SDH 16-05-2005
                ReleaseClientSlot(SlotIndex);                               //SDH 16-05-2005
                return i;                                                   //SDH 16-05-2005

               /* //SDH 16-05-2005
               if ( Clients[i]->SignedOn == 1 ) {
                  // Tell Boots app to tidy up its structures for old unit...
                  IssueCmdOffToBootsApp(i);
                  // and turn of the Signed On flag
                  Clients[i]->SignedOn = 0;
               } 

               // now shut down the old socket
               CloseSocket(&(Clients[i]->SocketHandle));
               ReleaseClientSlot(i);
               LogMessage( 6, "Closed slot %i" );
               */ //SDH 16-05-2005

            }
         }
      }
   }

   if (debug) disp_msg("New IP address");                                   //SDH 16-05-2005

   //Nothing found - return new slot                                        //SDH 16-05-2005
   return SlotIndex;                                                        //SDH 16-05-2005

}

void ReleaseClientSlot (int SlotIndex)
{
   if ( Clients[SlotIndex] != (void *) NULL ) {
      // free the Buffer whic has been allocated to this client
      FreeBuffer( (void *) Clients[SlotIndex]->Buffer );

      // now free the client itself
      FreeBuffer( (void *) Clients[SlotIndex] );
      LogMessage( 10, "Client Slot %d Freed", SlotIndex ) ;

      //... and mark the slot as free
      Clients[SlotIndex] = NULL;
   }
}

void ShutDownAllSockets(void)
{ 
   int i ;

   LogMessage ( 4, "Shutting down all sockets..." ) ;
   for (i = 0; i < MAX_SOCKETS; i++) {
      if (Clients[i] != NULL) {
         if (Clients[i]->InUse == 1) {
            //rc = SetBlockingMode(&(Clients[i]->SocketHandle), 0);
            CloseSocket(&(Clients[i]->SocketHandle));
            LogMessage( 10, "Closed socket index %d, returned %d", i, tcperrno);
         }
      }
   }

   // shutdowns succeeded so place the socket in nonblocking mode
   //rc = SetBlockingMode(&PrimarySocketHandle, 0) ;

   // Close Primary
   CloseSocket(&PrimarySocketHandle) ;
   LogMessage( 4, "...Closed Primary, returning: %d", tcperrno) ;
   //SDH ExitApplication() ;
}
