// ****************************************************************************
// v2.1
// v3.0 - 2004 RF Core Rollout January - March 2004 Paul Bowers
// v4.0 - 2004 OSSR (Off site StockRoom Support) 31st August 2004 Paul Bowers
// v5.0 - 2004 Credit Claiming - 16th Nov 2004 - Stuart Highley
// v6.0 - 2007 Recalls 22nd May 2007 - Paul Bowers
// ****************************************************************************

#if !defined RFSFILE_H
    #define RFSFILE_H 1

//Flags for Boots read and write interfaces
    #define B_OPENFILE          0x01
    #define B_CLOSEFILE         0x02

    #define LRTLG               "LRTLG"
    #define LRTLGBKP            "ADXLXACN::D:\\ADX_UDT1\\LRTLG.BKP"
    #define LRTLG_RECL          25L                                         //SDH 19-01-2005 OSSR WAN
    #define LRTLG_REP           548                                         //SDH 19-01-2005 OSSR WAN
    #define LRTLG_OFLAGS        0x2014
    #define LRTLG_CFLAGS        0x2014

// LRTLG record layout
typedef struct LRTLG_Record_Layout {
    BYTE type;
    BYTE user[3];
    WORD year;
    BYTE month;
    BYTE day;
    LONG time_ms;
    BYTE bLocation;                                                         //SDH 19-01-2005 OSSR WAN
    BYTE details[12];
} LRTLG_REC;

// LRTLG details field overlays - dependant on type
typedef struct LRTLG_SOR_Record_Layout {
    BYTE authority[1];                                                      // X = Unauthorised
    BYTE resv[11];
} LRTLG_SOR;

typedef struct LRTLG_PCM_Record_Layout {
    BYTE boots_code[4];
    BYTE check_type[1];                                                     // 26-7-2004 PAB
    BYTE resv[7];
} LRTLG_PCM;
typedef struct LRTLG_GAX_Record_Layout {
    LONG gaps_identified;
    BYTE resv[8];
} LRTLG_GAX;
typedef struct LRTLG_PCX_Record_Layout {
    LONG items_checked;
    LONG sels_printed;
    BYTE resv[4];
} LRTLG_PCX;
typedef struct LRTLG_PRT_Record_Layout {
    BYTE resv[12];
} LRTLG_PRT;
typedef struct LRTLG_ENQ_Record_Layout {
    BYTE enqpc[1];
    BYTE resv[11];
} LRTLG_ENQ;
typedef struct LRTLG_PLX_Record_Layout {
    BYTE resv[12];
} LRTLG_PLX;
// v4.0 START
typedef struct LRTLG_CLS_Record_Layout {
    BYTE list_id[4];
    BYTE resv[8];
} LRTLG_CLS;
typedef struct LRTLG_CLC_Record_Layout {
    BYTE list_id[4];
    BYTE boots_code[7];
    BYTE resv[1];
} LRTLG_CLC;
typedef struct LRTLG_CLX_Record_Layout {
    BYTE list_id[4];
    BYTE commit_flag[1];
    BYTE resv[7];
} LRTLG_CLX;
typedef struct LRTLG_SUS_Record_layout {
    BYTE txnid[4];
    BYTE fail[1];
} LRTLG_SUS;
// v4.0 END
typedef struct LRTLG_UOS_Record_layout {
    BYTE abListNum[4];
    BYTE abFiller[8];
} LRTLG_UOS;
typedef struct LRTLG_UOA_Record_layout {
    BYTE abListNum[4];
    BYTE abItemCode[7];
    BYTE cItemStatus;
} LRTLG_UOA;
typedef struct LRTLG_UOX_Record_layout {
    BYTE abListNum[4];
    BYTE cStatus;
    BYTE abFiller[7];
} LRTLG_UOX;
typedef struct LRTLG_DSS_Record_layout {
    BYTE cSuccess;  //'Y' or 'N'
    BYTE abFiller[11];
} LRTLG_DSS;
typedef struct LRTLG_DSG_Record_layout {
    BYTE cBusCentre;
    BYTE abSeqNum[4];
    BYTE abSupplierNum[6];
    BYTE cFiller;
} LRTLG_DSG;
typedef struct LRTLG_UOQ_Record_layout {
    BYTE abUODPacked[7];
    BYTE cDuplicate;
    BYTE abFiller[4];
} LRTLG_UOQ;
typedef struct LRTLG_STQ_Record_layout {
    BYTE abUODPrefPkd[4];
    BYTE abUODSuffPkd[3];
    BYTE abFiller[5];
} LRTLG_STQ;
typedef struct LRTLG_DNQ_Record_layout {
   BYTE abDealNum[4];
   BYTE abFiller[8];
} LRTLG_DNQ;
typedef struct {                                                            //SDH 14-Sep-2006 Planners
    BYTE abFiller[12];                                                      //SDH 14-Sep-2006 Planners
} LRTLG_PGS;                                                                //SDH 14-Sep-2006 Planners
typedef struct {                                                            //SDH 14-Sep-2006 Planners
    BYTE abFiller[12];                                                      //SDH 14-Sep-2006 Planners
} LRTLG_PGX;                                                                //SDH 14-Sep-2006 Planners
typedef struct {                                                            //SDH 14-Sep-2006 Planners
    BYTE abSeq[4];                                                          //SDH 14-Sep-2006 Planners
    BYTE cCoreFlag;                                                         //SDH 14-Sep-2006 Planners
    BYTE cLivePend;                                                         //SDH 14-Sep-2006 Planners
    BYTE abFiller[6];                                                       //SDH 14-Sep-2006 Planners
} LRTLG_PGF;                                                                //SDH 14-Sep-2006 Planners
typedef struct {                                                            //SDH 14-Sep-2006 Planners
    BYTE abPOGIRec[6];                                                      //SDH 14-Sep-2006 Planners
    BYTE cLivePend;                                                         //SDH 14-Sep-2006 Planners
    BYTE abFiller[5];                                                       //SDH 14-Sep-2006 Planners
} LRTLG_PGQ;                                                                //SDH 14-Sep-2006 Planners
typedef struct {                                                            //SDH 14-Sep-2006 Planners
    BYTE abPOGKey[6];                                                       //SDH 14-Sep-2006 Planners
    BYTE abModSeq[3];                                                       //SDH 14-Sep-2006 Planners
    BYTE abFiller[3];                                                       //SDH 14-Sep-2006 Planners
} LRTLG_PGM;                                                                //SDH 14-Sep-2006 Planners
typedef struct {                                                            //SDH 14-Sep-2006 Planners
    BYTE abFiller[12];                                                      //SDH 14-Sep-2006 Planners
} LRTLG_PPL;                                                                //SDH 14-Sep-2006 Planners
typedef struct {                                                            //SDH 14-Sep-2006 Planners
    BYTE abPOGKey[6];                                                       //SDH 25-Aug-2006 Planners
    BYTE abModSeq[3];       //Base 0                                        //SDH 25-Aug-2006 Planners
    BYTE abShelfNum[2];                                                     //SDH 25-Aug-2006 Planners    
    BYTE abNextChain[1];    //Base 0                                        //SDH 25-Aug-2006 Planners
} LRTLG_PSL;                                                                //SDH 14-Sep-2006 Planners
typedef struct {                                                            //SDH 14-Sep-2006 Planners
    BYTE abItemCode[6];                                                     //SDH 14-Sep-2006 Planners
    BYTE abStartChain[3];                                                   //SDH 14-Sep-2006 Planners
    BYTE abStartPlan[3];                                                    //SDH 14-Sep-2006 Planners
} LRTLG_PGL;                                                                //SDH 14-Sep-2006 Planners
typedef struct {                                                            //SDH 14-Sep-2006 Planners
    BYTE abPOGKey[6];                                                       //SDH 14-Sep-2006 Planners
    BYTE abMod[3];                                                          //SDH 14-Sep-2006 Planners
} LRTLG_PRP;                                                                //SDH 14-Sep-2006 Planners


    #define SELBF               "SELBF"
    #define SELBF_RECL          20L
    #define SELBF_REP           0
    #define SELBF_OFLAGS        0x201C
    #define SELBF_CFLAGS        0x243C

// SELBF record layout
typedef struct SELBF_Record_Layout {
    BYTE item_code[13];
    BYTE info[6];
    BYTE printerid[1];
} SELBF_REC;

    #define GAPBF               "GAPBF"
    #define GAPBF_RECL          1L         // Variable
    #define GAPBF_REP           0
    #define GAPBF_OFLAGS        0x203C
    #define GAPBF_CFLAGS        0x243C

//// GAPBF record layout
//typedef struct GAPBF_Record_Layout {
//    BYTE item_code[13];
//    BYTE check_price[6];
//    BYTE filler[1];
//} GAPBF_REC;

    #define IDF                 "IDF"
    #define IDF_RECL            60L
    #define IDF_KEYL            4
    #define IDF_REP             6
    #define IDF_OFLAGS          0x2018

typedef struct IDF_Record_Layout {
    BYTE boots_code[4];
    BYTE first_bar_code[6];
    BYTE second_bar_code[6];
    BYTE no_of_bar_codes[2];
    BYTE product_grp[3];
    BYTE stndrd_desc[24];
    BYTE status_1[1];
    BYTE intro_date[3];
    BYTE bsns_cntr[1];
    BYTE filler[1];
    UBYTE bit_flags_1;
    UBYTE bit_flags_2;
    BYTE parent_code[4];
    BYTE date_of_last_sale[3];
} IDF_REC;

    #define IRF                 "IRF"
    #define IRF_RECL            50L
    #define IRF_KEYL            11
    #define IRF_REP             7
    #define IRF_OFLAGS          0x2018

//Used by IRF and IRFDEX                                                    //SDH 14-01-2005 Promotions
typedef struct DEALDATA {                                                   //SDH 14-01-2005 Promotions
    UWORD uwDealNum:14;                                                     //SDH 14-01-2005 Promotions
    UBYTE ubListID:2;                                                       //SDH 14-01-2005 Promotions
} DEALDATA;                                                                 //SDH 14-01-2005 Promotions

typedef struct IRF_Record_Layout {
    BYTE bar_code[11];
    UBYTE indicat0;
    UBYTE indicat1;
    //BYTE indicat2[1];                                                     // v3.0
    //BYTE deal_num[2];                                                     // v3.0
    //BYTE indicat4[1];                                                     // v3.0
    //BYTE salequan[1];                                                     // v3.0
    DEALDATA dealdata0;                                                     // v3.0
    UBYTE indicat8;                                                         // 23-5-07 PAB recalls
    BYTE unused1[2];                                                        // 23-5-07 PAB recalls
    BYTE salepric[5];
    //BYTE mpgroup[1];                                                      // v3.0
    UBYTE indicat5;                                                         // v3.0
    BYTE itemname[18];
    BYTE boots_code[3];
    //BYTE deal_saving[2];                                                  // v3.0
    //WORD points;                                                          // v3.0
    DEALDATA dealdata1;                                                     // v3.0
    DEALDATA dealdata2;                                                     // v3.0
    UBYTE indicat3;
} IRF_REC;

    #define IRFDEX              "IRFDEX"
    #define IRFDEX_RECL         17L
    #define IRFDEX_KEYL         3
    #define IRFDEX_REP          673
    #define IRFDEX_OFLAGS       0x2018

typedef struct IRFDEX_Record_Layout {                                       //SDH 14-01-2005 Promotions
    BYTE abItemCodePD[3];                                                   //SDH 14-01-2005 Promotions
    DEALDATA aDealData[7];                                                  //SDH 14-01-2005 Promotions
} IRFDEX_REC;                                                               //SDH 14-01-2005 Promotions

    #define ISF                 "ISF"
    #define ISF_RECL            55
    #define ISF_KEYL            4
    #define ISF_REP             9
    #define ISF_OFLAGS          0x2018

typedef struct ISF_Record_Layout {
    BYTE boots_code[4];
    BYTE sel_desc[45];
    BYTE cUnitType[1];
    ULONG integer4:24;                             // PAB 8-8-07
    WORD integer2;                                 // PAB 8-8-07
} ISF_REC;

    #define STOCK               "STOCK"
    #define STOCK_RECL          30L
    #define STOCK_KEYL          4
    #define STOCK_REP           108
    #define STOCK_OFLAGS        0x2018

typedef struct STOCK_Record_Layout {
    BYTE boots_code[4];
    WORD stock_fig;
    WORD last_count;
    BYTE date_last_count[3];
    BYTE date_last_move[3];
    WORD last_rec;
    BYTE date_last_rec[3];
    BYTE filler[11];
} STOCK_REC;

    #define IMSTC               "IMSTC"
    #define IMSTC_RECL          40L
    #define IMSTC_KEYL          11
    #define IMSTC_REP           31
    #define IMSTC_OFLAGS        0x2018

typedef struct IMSTC_Record_Layout {
    BYTE bar_code[11];
    LONG restart;
    LONG numitems;
    LONG amtsale;
    LONG reserved;
    LONG stkmq_restart;
    BYTE status_flag[1];
    WORD stock_figure;
    BYTE reason_item_removed[1];
    BYTE filler[5];
} IMSTC_REC;

    #define CIMF                "CIMFI"
    #define CIMF_RECL           16L
    #define CIMF_KEYL           4
    #define CIMF_REP            54
    #define CIMF_OFLAGS         0x2018

typedef struct CIMF_Record_Layout {
    BYTE boots_code[4];
    LONG restart;
    LONG numitem;
    BYTE trans_date[3];
    BYTE space[1];
} CIMF_REC;

    #define CITEM               "CITEM"
    #define CITEM_RECL          64L
    #define CITEM_KEYL          4
    #define CITEM_REP           184
    #define CITEM_OFLAGS        0x2018

typedef struct CI_Record_Layout {
    BYTE boots_code[4];
    BYTE shelf_allocation[2];
    BYTE vulnerable_esa[2];
    BYTE special_order_esa[2];
    BYTE total_esa[2];
    BYTE initial_display_stock[2];
    BYTE on_order_in_this_pdt[2];
    BYTE on_order_today[2];
    BYTE total_on_order[2];
    BYTE date_of_last_manual_count[3];
    BYTE unit[1];
    BYTE vulnerable_report_flag[1];
    BYTE sales_sign_flag[1];
    BYTE week_4_sales[4];
    BYTE week_3_sales[4];
    BYTE week_2_sales[4];
    BYTE week_1_sales[4];
    WORD alter_sales_quantity;
    BYTE list_frequency[1];
    BYTE yesterdays_sales[2];
    BYTE count_request_flag[1];
    WORD previous_theoretical_stock;
    BYTE filler[14];
} CITEM_REC;

    #define GAPMES              "GAPMES"
    #define GAPMES_RECL         1L
    #define GAPMES_REP          0
    #define GAPMES_OFLAGS      0x201C
// No layout required - semaphore file

    #define EALAUTH         "EALAUTH"
    #define EALAUTH_KEYL    4L
    #define EALAUTH_RECL    80L
    #define EALAUTH_REP        2
    #define EALAUTH_OFLAGS     0x2018

// EALAUTH record layout
typedef struct EALAUTH_Record_Layout {
    BYTE operator_no[4];
    BYTE password[4];
    UBYTE options_key[1];
    UWORD indicat1;
    UWORD indicat2;
    UWORD indicat3;
    UBYTE indicat4;
    UBYTE indicat5;
    UBYTE indicat6;
    UBYTE indicat7;
    UBYTE indicat8;
    UBYTE indicat9;
    UBYTE indicat10;
    UBYTE indicat11;
    UBYTE indicat12;
    BYTE operator_name[20];
    UBYTE indicat13;
    UBYTE indicat14;
    UBYTE indicat15;
    UBYTE indicat16;
    BYTE reserved[12];
    BYTE user[9];
    BYTE date_pswd_change[3];
    UWORD model_flags_1;
    UWORD model_flags_2;
    BYTE sup_flag[1];
    BYTE op_model[3];
} EALAUTH_REC;

    #define PLLOL           "PLLOL"
    #define PLLOL_RECL      34L                                             // 02-2-05 SDH OSSR WAN
    #define PLLOL_REP       510
    #define PLLOL_OFLAGS    0x201C

//  record layout
typedef struct PLLOL_Record_Layout {
    BYTE list_id[3];
    BYTE creator[3];
    BYTE picker[3];
    BYTE list_status[1];
    BYTE create_date[6];
    BYTE create_time[4];
    BYTE pick_start_time[4];
    BYTE pick_end_time[4];
    BYTE item_count[4];
    BYTE cOssrPicking;                                                      // 02-2-05 SDH OSSR WAN
    BYTE cLocation; // [S]helf Monitor, [F]ast fill, [O]ssr, [E]xcess stock (shop floor),
                    // [B]ack shop Excess stock, Excess stock [C]ount in OSSR
} PLLOL_REC;

    #define PLLDB           "PLLDB"
    #define PLLDB_KEYL      6L
//#define PLLDB_RECL      28L                                               // 31-8-04 PAB OSSR
    #define PLLDB_RECL      54L                                             // 31-8-04 PAB OSSR
    #define PLLDB_REP       511
    #define PLLDB_OFLAGS    0x201C

//  record layout
typedef struct PLLDB_Record_Layout {
    BYTE list_id[3];
    BYTE seq[3];
    BYTE boots_code[4];
    BYTE qty_on_shelf[4];
    BYTE fill_qty[4];
    BYTE gap_flag[1];             
    BYTE item_status[1];
    BYTE stock_room_count[4];
    BYTE sales_figure[4];
    BYTE filler[8];                                                         // SDH 17-11-04 OSSR WAN
    BYTE ossr_count[4];                                                     // PAB 31-8-04 OSSR
    BYTE time_sf_count[2];                                                  // PAB 31-8-04 OSSR
    BYTE time_bs_count[2];                                                  // PAB 31-8-04 OSSR
    BYTE time_ossr_count[2];                                                // PAB 31-8-04 OSSR
    BYTE sales_bs_count[4];                                                 // PAB 31-8-04 OSSR
    BYTE sales_ossr_count[4];                                               // PAB 31-8-04 OSSR
} PLLDB_REC;

    #define PGF                "PGF"                                        // PAB 23-10-03
    #define PGF_KEYL           3L                                           // PAB 23-10-03
    #define PGF_RECL           30L                                          // PAB 23-10-03
    #define PGF_REP            0                                            // PAB 23-10-03
    #define PGF_OFLAGS         0x2018                                       // PAB 23-10-03

// record layout
typedef struct PGF_Record_layout {                                          // PAB 23-10-03
    BYTE prod_grp_no[3];                                                    // UPD PAB 23-10-03
    BYTE abProdGrpName[18];                                                 // SDH 24-12-04
    BYTE price_check_notexempt[1];                                          // ASCII [Y/N]     PAB 23-10-03
    BYTE cOssrFlag; //'Y' or 'N' (' ' means 'N')                            // SDH 24-12-2004
    BYTE pgf_filler2[7];                                                    // SDH 24-12-2004
} PGF_REC;                                                                  // PAB 23-10-03

    #define PRTCTL             "D:\\ADX_UDT1\\PRTCTL.BIN"                   // PAB 18-02-04 4.02
    #define PRTCTL_RECL        12L                                          // PAB 18-02-04 4.02
    #define PRTCTL_REP         0                                            // PAB 18-02-04 4.02
    #define PRTCTL_OFLAGS      0x2018                                       // PAB 18-02-04 4.02

// record layout
typedef struct PRTCTL_record_layout {                                       // PAB 18-02-04 4.02
    BYTE prtnum[10];                                                        // PAB 18-02-04 4.02
} PRTCTL_REC;                                                               // PAB 18-02-04 4.02

    #define PRTLIST            "D:\\ADX_UDT1\\PRTLIST.BIN"                  // PAB 17-05-04
    #define PRTLIST_RECL       200L // Variable Length                         SDH 10-May-2006
    #define PRTLIST_REP        0                                            // PAB 17-05-04
    #define PRTLIST_OFLAGS     0x2018                                       // PAB 17-05-04   

// record layout
typedef struct PRTLIST_record_layout {                                      // PAB 17-05-04
    BYTE prtdesc[200];                                                      // SDH 10-05-2006
} PRTLIST_REC;                                                              // PAB 17-05-04


    #define RFHIST             "RFHIST"
    #define RFHIST_KEYL        4L
    #define RFHIST_RECL        18L
    #define RFHIST_REP         0
    #define RFHIST_OFLAGS      0x201C

//  record layout
typedef struct RFHIST_Record_Layout {
    BYTE boots_code[4];                                                     // UPD, format [0BBBBBBC] (C=check digit)
    BYTE date_last_pchk[4];                                                 // UPD, format [YYYYMMDD]
    BYTE price_last_pchk[3];                                                // UPD
    BYTE date_last_gap[4];                                                  // UPD, format [YYYYMMDD]
    UBYTE ubPgfOssrFlag:1;                                                  // SDH 20-04-2005
    UBYTE ubItemOssrFlag:1;                                                 // SDH 20-04-2005
    UBYTE ubGAPMFlag:1;                                                     // SDH 28-04-2005
    BYTE bUnused:5;                                                         // SDH 28-04-2005
    BYTE resrv[2];
} RFHIST_REC;

    #define CLOLF              "CLOLF"
    #define CLOLF_RECL         49L                                          // 10/01/05 SDH OSSR WAN
    #define CLOLF_REP          556
    #define CLOLF_OFLAGS       0x201C

//  record layout
typedef struct CLOLF_Record_Layout {
    BYTE list_id[3];                                                        // ASCII
    BYTE total_items[3];                                                    // ASCII
    BYTE items_shopfloor[3];                                                // ASCII
    BYTE items_backshop[3];                                                 // ASCII
    BYTE list_type[1];                                                      // ASCII - [H]ead office, [R]ectification proc, [N] Negative
    BYTE bus_unit[1];                                                       // ASCII
    BYTE bus_unit_name[15];                                                 // ASCII
    BYTE list_status[1];                                                    // ASCII - [A]ctive, [C]omplete, [ ]Initial
    BYTE head_off_list_id[4];                                               // ASCII
    BYTE cnt_date[8];                                                       // ASCII - Format YYYYMMDD
    BYTE ossr_store;                                                        // marked for OSSR counting Y/N
    BYTE items_ossr[3];                                                     // ASCII
    BYTE abUserID[3];                                                       // ASCII  SDH 11-01-2005 OSSR WAN
} CLOLF_REC;

    #define CLILF              "CLILF"
    #define CLILF_RECL         125L
    #define CLILF_KEYL         6L
    #define CLILF_REP          557
    #define CLILF_OFLAGS       0x201C

//  record layout
typedef struct CLILF_Record_Layout {
    BYTE list_id[3];                                                        // ASCII
    BYTE seq[3];                                                            // ASCII   
    BYTE boots_code[7];                                                     // ASCII - Format BBBBBBC (C=check digit)
    BYTE item_code[13];                                                     // ASCII
    BYTE sel_desc[45];                                                      // ASCII 3 x 15 charaters
    BYTE active_deal_flag[1];                                               // ASCII [Y]es, [N]o
    BYTE product_group[6];                                                  // ASCII (should be 6)
    BYTE product_group_desc[12];                                            // ASCII
    //The 3 counts                                                          // SDH 10-01-2005
    BYTE count_backshop[4];                                                 // ASCII
    BYTE count_shopfloor[4];                                                // ASCII
    BYTE abOSSRCount[4];                                                    // SDH 10-01-2005
    //The 3 sales figures at the time of counts                             // SDH 10-01-2005
    BYTE sales[4];                                                          // ASCII
    BYTE abAtStockSales[4];                                                 // SDH 10-01-2005
    BYTE abAtOSSRSales[4];                                                  // SDH 10-01-2005
    //Some random field                                                     // SDH 10-01-2005
    BYTE ho_seq_no[2];                                                      // ASCII
    //The three times of counts                                             // SDH 10-01-2005
    BYTE abTimeSalesCntPD[2];                                               // SDH 10-01-2005
    BYTE abTimeStockCntPD[2];                                               // SDH 10-01-2005
    BYTE abTimeOSSRCntPD[2];                                                // SDH 10-01-2005
    BYTE abFiller[3];                                                       // SDH 10-01-2005
} CLILF_REC;                                                                // SDH 10-01-2005

    #define STC                 "STCXX"
    #define STC_RECL            128L
    #define STC_KEYL            2
    #define STC_REP             38
    #define STC_OFLAGS          0x2018

    #define STP                 "STPXX"
    #define STP_RECL            128L
    #define STP_KEYL            2
    #define STP_REP             39
    #define STP_OFLAGS          0x2018

typedef struct ST_SubRecord_Layout {
    LONG cash;
    LONG credit;
    BYTE cr_time[3];
    LONG discount;
    BYTE resv[3];
} ST_REC_SUB;

typedef struct ST_Record_Layout {
    BYTE workgroup[2];
    ST_REC_SUB details[7];
} ST_REC;

    #define IMFP                "IMFP"
    #define IMFP_RECL           27L
    #define IMFP_KEYL           11
    #define IMFP_REP            32
    #define IMFP_OFLAGS         0x2018

typedef struct IMF_Record_Layout {
    BYTE bar_code[11];
    LONG restart;
    LONG numitems;
    LONG amtsale;
    LONG resv;
} IMF_REC;

    #define STKMQ               "STKMQ"
    #define STKMQ_RECL          1L      // Variable length
    #define STKMQ_REP           83
    #define STKMQ_OFLAGS        0x2014
// Type 13 record
//  o/s   lth  description          data ( []=binary )
//    0     3  record ident         "[13];
//    3     3  date now (YYMMDD)    PPP
//    6     3  time now (HHMMSS)    PPP
//    9     4  list number          AAAA
//    13    2  item number          AA
//    15    1  item status          A
//    16    4  item code (0ccccccd) PPPP
//    20    3  count date (YYMMDD)  PPP
//    23    2  count time (HHMM)    PP
//    25    6  price                PPPPP;
//    31    5  count                AAAA;
//    36    4  backroom count       AAAA     "XXXX" = RP Count.
//    40    3  record terminator    "[0D0A]
    #define STKMQ_T13_LTH 43L

// Type 17 record
//  o/s   lth  description          data ( []=binary )
//     0    3  record ident         "[14];
//     3    3  date (YYMMDD)        PPP
//     6    3  time (HHMMSS)        PPP
//     9    4  list number          AAAA
//    13    1  list status          A   (from PILST list Header record)
//    14    3  record terminator    "[0D0A]
    #define STKMQ_T14_LTH 17L

// Variable length record - create dynamically

    #define RFRDESC             "RFRDESC"
    #define RFRDESC_RECL        51L
    #define RFRDESC_REP         0
    #define RFRDESC_OFLAGS     0x201C

typedef struct RFRDESC_Record_Layout {
    BYTE title[20];
    BYTE fname[12];
    BYTE days[3];
    BYTE action[1];
    BYTE arcfname[12];
    BYTE reptype[1];                                                        // v3.0
    BYTE term[2];
} RFRDESC_REC;

    #define RFREP_RECL         26L
    #define RFREP_REP       0
    #define RFREP_OFLAGS    0x201C

typedef struct RFREP_Record_Layout {
    BYTE q1[1];
    BYTE level[1];
    BYTE exp[1];
    BYTE data[20];
    BYTE q2[1];
    BYTE term[2];
} RFREP_REC;

    #define TSF                   "EALTERMS"
    #define TSF_RECL              63L
    #define TSF_KEYL              2
    #define TSF_REP               29
    #define TSF_OFLAGS            0x2018
    #define TSF_BUFFER            0x8000L

    #define PSBT                  "PSBTERMS"
    #define PSBT_RECL             63L
    #define PSBT_KEYL             2
    #define PSBT_REP              43
    #define PSBT_OFLAGS           0x2018

typedef struct TSF_Record_Layout_S {
    BYTE till[2];                                                           // UPD (= 0x9999)
    BYTE indicat0[1];
    BYTE indicat1[1];
    BYTE tslname[8];
    BYTE monitor[2];
    BYTE tlogflag[1];
    BYTE resvd[48]
} TSF_STORE_REC;

typedef struct TSF_Record_Layout_T {
    BYTE till[2];                                                           // UPD (not = 0x9999)
    BYTE indicat0[1];
    BYTE indicat1[1];
    LONG grosspos;
    LONG grossneg;
    LONG netcash;
    LONG netncash;
    LONG amtloan;
    LONG amtpicku;
    LONG amtcashc;
    BYTE operator[4];                                                       // ?
    BYTE transnum[2];                                                       // ?
    BYTE user[9];                                                           // ?
    BYTE controller[2];                                                     // ?
    BYTE resvd[14]
} TSF_TILL_REC;

    #define WRF                   "EALWORKG"
    #define WRF_RECL              112L
    #define WRF_KEYL     2
    #define WRF_REP               11
    #define WRF_OFLAGS            0x2018
    #define WRF_BUFFER      0x8000L

typedef struct WRF_Record_Layout {
    BYTE wrkgp[2];                                                          // UPD
    BYTE name[20];
    BYTE till[20][2];                                                       // UPD
} WRF_REC;

// External communications pipe
    #define CPIPE           "pi:rfscomms"
    #define CPIPE_RECL         6L
    #define CPIPE_REP       0
//#define CPIPE_CFLAGS     0x2519      // v4.0
    #define CPIPE_CFLAGS    0x3519      // v4.0
    #define CPIPE_TIMEOUT      100L     // Read timeout (mS)

    #define DBG          "ADXLXACN::D:\\ADX_UDT1\\RFDEBUG.DAT"
    #define DBGBKP          "ADXLXACN::D:\\ADX_UDT1\\RFDEBUG.BKP"
    #define DBG_RECL        1L
    #define DBG_REP            0
    #define DBG_OFLAGS         0x2014
    #define DBG_CFLAGS         0x2014


    #define PST          "ADXLXACN::D:\\ADX_UDT1\\PATRACE.DAT"
    #define PSTBKP          "ADXLXACN::D:\\ADX_UDT1\\PATRACE.BKP"
    #define PST_RECL        1L
    #define PST_REP         0
    #define PST_OFLAGS         0x2014
    #define PST_CFLAGS         0x2014


    #define RFSCF           "RFSCF"
    #define RFSCF_RECL      80L
    #define RFSCF_REP       517
    #define RFSCF_OFLAGS    0x201C

//RFSCF Record 1 layout
typedef struct RFSCF_Record_Layout_1and2 {                                  // 16-11-04 SDH
    WORD pmed_term;
    WORD qbust_term;
    WORD pmed_next_txn;
    WORD qbust_next_txn;
    LONG pmed_txn_cnt;
    LONG pmed_qty;
    LONG qbust_txn_cnt;
    LONG qbust_qty;
    BYTE phase[1]; // Phase 4 = Pocket PC, Phase 3 = Palm Pilot, Phase 2 = Symbol RF LDT, Phase 1 = Telxon RF PPC
    LONG recount_qty;                                                       // v2.1
    LONG recount_val;                                                       // v2.1
    LONG percent_var;                                                       // v2.1
    WORD recheck_days;                                                      // v2.1
    LONG pchk_target;                                                       // v2.1
    LONG pchk_done;                                                         // v2.1
    LONG pchk_upper;                                                        // v2.1
    LONG pchk_lower;                                                        // v2.1
    WORD pchk_inc;                                                          // v2.1
    LONG pchk_target_def;                                                   // v2.1
    LONG pchk_errors_c;                                                     // v2.1
    LONG pchk_errors_l;                                                     // v2.1
    BYTE emu_active[1];                                                     // v2.1
    BYTE prim_curr[1];          // [S]terling / [E]cu                       // v2.1
    LONG emu_conv_fact;         // nnnn.nnnnnn                              // v2.1
    BYTE ossr_store;            // Store has OSSR W/Y/N (W = WAN active)    // 31/8/04 PAB
    WORD recount_days_retain;                                               // PAB 25 Jan 2007
    BYTE cPlannersActive;       // Y or N                                   // SDH 25-Oct-2006 Planners
    BYTE resvd1[1];                                                         // PAB 25 Jan 2007
    
    //Record 2 start
    //NOTE THAT THESE FIELDS ARE NOT READ DUE TO THE READ CODE ONLY READING
    //80 BYTES.  SINCE THE FIELDS ARE NOT USED I WILL NOT FIX THIS BUG - SDH
    WORD hht_ip_min;                                                        // v2.1
    WORD hht_ip_max;                                                        // v2.1
    UWORD activity;                                                         // bit 0 Price Check active                      // v3.0
                                                                            // bit 1 Gap Monitor
                                                                            // bit 1 Gap Monitor
                                                                            // bit 2 Picking
                                                                            // bit 3 Reports
                                                                            // bit 4 Cust Service (P/Med)
                                                                            // bit 5 Cust Service (Q/Bust)
                                                                            // bit 6
                                                                            // bit 7
                                                                            // bit 8 UOD Active
    BYTE resvd2[74];                                                        // SDH 25-Sep-2006 Planners
} RFSCF_REC_1AND2;

//RFSCF Record 1 layout - Not currently read

//RFSCF Record 3 layout
typedef struct RFSCF_Record_Layout_3 {                                      // 16-11-04 SDH
    BYTE bCCActive;                                                         // 16-11-04 SDH
    BYTE abBusCentres[30];                                                  // 16-11-04 SDH
    BYTE abCChistNumDays[3];                                                // 16-11-04 SDH
    BYTE abFiller[46];                                                      // 16-11-04 SDH
} RFSCF_REC_3;                                                              // 16-11-04 SDH

    #define MINLS               "MINLS"
    #define MINLS_RECL          11L
    #define MINLS_KEYL          4
    #define MINLS_REP           547
    #define MINLS_OFLAGS        0x201C

typedef struct MINLS_Record_Layout {
    BYTE boots_code[4];                                                     // UPD
    BYTE recount_date[3];                                                   // UPD YYMMDD (windowed)
    BYTE discrepancy[3];                                                    // UPD
    BYTE count_status[1];
} MINLS_REC;

    #define INVOK               "INVOK"
    #define INVOK_RECL          80L
    #define INVOK_REP           89
    #define INVOK_OFLAGS        0x2018

typedef struct INVOK_Record_Layout {
    BYTE serial_no[5];
    BYTE date[3];
    BYTE success_flag[1];
    BYTE store_no[4];
    BYTE inventory_srlno[5];
    BYTE inventory_success[1];
    BYTE sales_srlno[5];
    BYTE sales_success[1];
    BYTE new_list_srlno[5];
    BYTE new_list_success[1];
    BYTE csr_ident[1];
    BYTE csr_delivery_no[5];
    BYTE csr_delivery_date[6];
    BYTE csr_psc11_flag[1];
    BYTE csr_psc12_flag[1];
    BYTE csr_psc13_flag[1];
    BYTE csr_psc12_days[1];
    BYTE pss33_run_date[3];
    BYTE pss33_success_flag[1];
    BYTE dir_impl_flag[1];
    BYTE psc30_run_date[3];
    BYTE psc30_success_flag[1];
    BYTE uod_impl_flag[1];
    BYTE last_uod_date[3];
    BYTE prev_serial_no[5];
    BYTE prev_success_flag[1];
    BYTE suppress_excep_report[1];
    BYTE csr_started_by_sup[1];
    BYTE csr_psc14_flag[1];
    BYTE csr_conversion_status_flag[1];
    BYTE pts_events_ok_date[3];
    BYTE rp_days[1];
    BYTE filler[6];
} INVOK_REC;

    #define SUSPT              "EALSUSPT"
    #define SUSPT_RECL         508L
    #define SUSPT_KEYL         6
    #define SUSPT_REP          81
    #define SUSPT_OFLAGS       0x201C

typedef struct SUSPT_Record_layout {
    BYTE terminal[2];                                                       // UPD
    BYTE transnum[2];                                                       // UPD
    WORD sequence;                                                          // UPD
    BYTE reason[1];                                                         // ascii  
    BYTE day_time[6];                                                       // UPD ddmmyyhhmmss
    BYTE operator_id[3];                                                    // ascii
    BYTE EAN_data[481];                                                     // Ascii 37*13EAN
    BYTE filler[11];
} SUSPT_REC;

    #define PIITM              "PIITM"
    #define PIITM_RECL         30L
    #define PIITM_KEYL         6
    #define PIITM_REP          121
    #define PIITM_OFLAGS       0x2018

typedef struct PIITM_Record_Layout {
    BYTE list_no[4];                                                        // ASCII "0000"
    BYTE list_seq[2];                                                       // ASCII
    BYTE item_code[4];                                                      // UPD YYMMDD (windowed)
    BYTE on_idf[1];                                                         // ASCII
    BYTE activity[1];                                                       // ASCII
    BYTE cycle_length[2];
    BYTE family_marker[2];
    BYTE members[2];
    BYTE eligibility_flag[1];
    BYTE status[1];
    BYTE potential_recount[1];
    BYTE discrepancy_qty[2];
    BYTE discrepancy_amt[2];
    BYTE filler[5];
} PIITM_REC;


    #define PILST              "PILST"
    #define PILST_RECL         40L
    #define PILST_KEYL         4
    #define PILST_REP          120
    #define PILST_OFLAGS       0x2018

typedef struct PILST_Record_Layout_H {
    BYTE list_no[4];                                                        // ASCII "0000"
    BYTE list_no_spare[4];                                                  // ASCII
    BYTE cpm_run_date[3];                                                   // UPD YYMMDD (windowed)
    BYTE pipln_run_ok[1];                                                   // ASCII
    BYTE list_no_highest[4];                                                // ASCII
    BYTE resvd[24];
} PILST_HEADER_REC;

typedef struct PILST_Record_Layout_D {
    BYTE list_no[4];                                                        // ASCII not "0000"
    BYTE name[12];                                                          // ASCII
    BYTE bc_letter[1];                                                      // ASCII
    BYTE type[1];                                                           // ASCII
    BYTE count_by_date[3];                                                  // UPD YYMMDD (windowed)
    BYTE product_group[3];                                                  // UPD GGGGSS
    BYTE items[1];                                                          // UPD
    BYTE to_be_counted[1];                                                  // UPD
    BYTE count_date[3];                                                     // UPD YYMMDD (windowed)
    BYTE status[1];                                                         // ASCII
    BYTE recount_date[3];                                                   // UPD YYMMDD (windowed)
    BYTE recount_allowed[1];                                                // ASCII
    BYTE resvd[6];
} PILST_DETAIL_REC;

// Shared memory buffer, for interprocess communications
    #define SM_BUFFER_NAME      "sm:rfsstat"
    #define SM_BUFFER_SIZE      1024L

    #define NVURL               "NVURL"
//#define NVURL               "adxlxacn::d:\\adx_udt1\\envurl.dat"
    #define NVURL_RECL          127L
    #define NVURL_KEYL          3
    #define NVURL_REP           0
    #define NVURL_OFLAGS        0x2018

typedef struct NVURL_Record_Layout {
    BYTE btc_parent[3];
    BYTE btc_link[3];
    BYTE url_info[60];                                                      // Info URL : (e.g. http://domain/dir/file.html)
    BYTE url_link[60];                                                      // Link URL : (e.g. http://domain/dir/file.html)
    UBYTE flags;                                                            // bits 1-0 = enforcement 00 = no enforcement
                                                                            //                        01 = force info URL
                                                                            //                        10 = force link URL
                                                                            //                        11 = reserved
                                                                            // bits 7-2 = reserved (set to 000000)
} NVURL_REC;


    #define RFOK           "ADXLXACN::D:\\ADX_UDT1\\RFOK.BIN"               // 24-8-2004 PAB
    #define RFOK_RECL      80L                                              // 24-8-2004 PAB
    #define RFOK_REP       517                                              // 24-8-2004 PAB
    #define RFOK_OFLAGS    0x201C                                           // 24-8-2004 PAB
// 24-8-2004 PAB
typedef struct RFOK_Record_Layout {                                         // 24-08-2004 PAB
    BYTE rfaudit;                                                           // 24-08-2004 PAB
    BYTE rfmaint;                                                           // 24-08-2004 PAB
    BYTE rfpikmnt;                                                          // 24-08-2004 PAB
    BYTE rfccmnt;                                                           // 07-12-2004 SDH
    BYTE rfscc;                                                             // 07-12-2004 SDH
    BYTE filler[75];                                                        // 24-8-2004 PAB
} RFOK_REC;                                                                 // 24-8-2004 PAB

    #define BCSMF              "BCSMF"                                      // SDH 17-11-04 OSSR WAN
    #define BCSMF_RECL         33L                                          // SDH 17-11-04 OSSR WAN
    #define BCSMF_KEYL         1                                            // SDH 17-11-04 OSSR WAN
    #define BCSMF_REP          84                                           // SDH 17-11-04 OSSR WAN
    #define BCSMF_OFLAGS       A_READ | A_SHARE                             // SDH 17-11-04 OSSR WAN

typedef struct BCSMF_Record_Layout {                                        // SDH 17-11-04 OSSR WAN
    BYTE cBusCentre;                                                        // SDH 17-11-04 OSSR WAN
    BYTE abDesc[14];                                                        // SDH 17-11-04 OSSR WAN
    BYTE bRecntLimit;                                                       // SDH 17-11-04 OSSR WAN
    BYTE bMinRecntLimit;                                                    // SDH 17-11-04 OSSR WAN
    BYTE bMaxRecntLimit;                                                    // SDH 17-11-04 OSSR WAN
    WORD wDiscrepencyValue;                                                 // SDH 17-11-04 OSSR WAN
    BYTE bDiscrepencyCount;                                                 // SDH 17-11-04 OSSR WAN
    BYTE bDiscrepencyPrcnt;                                                 // SDH 17-11-04 OSSR WAN
    BYTE bStockCountLimit;                                                  // SDH 17-11-04 OSSR WAN
    WORD wMinListNum;                                                       // SDH 17-11-04 OSSR WAN
    WORD wMaxListNum;                                                       // SDH 17-11-04 OSSR WAN
    BYTE bSequenceNum;                                                      // SDH 17-11-04 OSSR WAN
    BYTE bPseudoBusCentre;                                                  // SDH 17-11-04 OSSR WAN
    BYTE bNoRepeatTickets;                                                  // SDH 17-11-04 OSSR WAN
    BYTE abFiller[3];                                                       // SDH 17-11-04 OSSR WAN
} BCSMF_REC;                                                                // SDH 17-11-04 OSSR WAN

    #define CCLOL              "ADXLXACN::D:/ADX_UDT1/CCLOL.BIN"            // SDH 17-11-04 OSSR WAN
    #define CCLOL_RECL         150L                                         // SDH 17-11-04 OSSR WAN
    #define CCLOL_REP          691                                          // SDH 17-11-04 OSSR WAN
    #define CCLOL_OFLAGS       A_READ | A_WRITE | A_SHARE                   // SDH 17-11-04 OSSR WAN

//---- CCLOL ----                                                           // SDH 26-11-04 CREDIT CLAIM
typedef struct CCLOL_Record_Layout {                                        // SDH 26-11-04 CREDIT CLAIM
    BYTE abListNum[4];                                                      // SDH 26-11-04 CREDIT CLAIM
    BYTE cListType; //"G" - Goods out, "C" - credit claim                   // SDH 26-11-04 CREDIT CLAIM
    BYTE abUODNum[14];                                                      // SDH 26-11-04 CREDIT CLAIM
    BYTE cStatus;                                                           // SDH 26-11-04 CREDIT CLAIM
    BYTE abItemCount[4];                                                    // SDH 26-11-04 CREDIT CLAIM
    BYTE abUODQty[4];                                                       // SDH 26-11-04 CREDIT CLAIM
    BYTE cAdjStockFig;  //"Y" or "N"                                        // SDH 26-11-04 CREDIT CLAIM
    BYTE cSupplyRoute;                                                      // SDH 26-11-04 CREDIT CLAIM
    BYTE cDispLocation;                                                     // SDH 26-11-04 CREDIT CLAIM
    BYTE cBusCentre;                                                        // SDH 26-11-04 CREDIT CLAIM
    BYTE abBusCentreDesc[14];                                               // SDH 26-11-04 CREDIT CLAIM
    BYTE abRecallNum[8];                                                    // SDH 26-11-04 CREDIT CLAIM
    BYTE abAuth[15];                                                        // SDH 26-11-04 CREDIT CLAIM
    BYTE abSupplier[15];                                                    // SDH 26-11-04 CREDIT CLAIM
    BYTE abReturnMethod[2];                                                 // SDH 26-11-04 CREDIT CLAIM
    BYTE abCarrier[2];                                                      // SDH 26-11-04 CREDIT CLAIM
    BYTE abBirdNum[8];                                                      // SDH 26-11-04 CREDIT CLAIM
    BYTE abReasonNum[2];                                                    // SDH 26-11-04 CREDIT CLAIM
    BYTE abReceivingStoreNum[4];                                            // SDH 26-11-04 CREDIT CLAIM
    BYTE abDestination[2];                                                  // SDH 26-11-04 CREDIT CLAIM
    BYTE cWarehouseRoute;                                                   // SDH 26-11-04 CREDIT CLAIM
    BYTE abUODType[2];                                                      // SDH 26-11-04 CREDIT CLAIM
    BYTE abDamageRsn[2];                                                    // SDH 26-11-04 CREDIT CLAIM
    BYTE abDateUODOpened[8];        //YYYYMMDD                              // SDH 26-11-04 CREDIT CLAIM
    BYTE abDateUODDispatched[8];    //YYYYMMDD                              // SDH 26-11-04 CREDIT CLAIM
    BYTE abTimeUODOpened[4];        //HHMM                                  // SDH 26-11-04 CREDIT CLAIM
    BYTE abOpID[3];                                                         // SDH 26-11-04 CREDIT CLAIM
    BYTE abOpName[15];                                                      // SDH 26-11-04 CREDIT CLAIM
    BYTE cRFStatus;                 //'A' active, 'C' complete              // SDH 26-11-04 CREDIT CLAIM
    BYTE abFiller[2];                                                       // SDH 26-11-04 CREDIT CLAIM
} CCLOL_REC;                                                                // SDH 26-11-04 CREDIT CLAIM

//---- CCILF ----                                                           // SDH 17-11-04 CREDIT CLAIM
    #define CCILF              "ADXLXACN::D:/ADX_UDT1/CCILF.BIN"            // SDH 17-11-04 CREDIT CLAIM
    #define CCILF_KEYL         8        //List ID + Rec Seq                 // SDH 17-11-04 CREDIT CLAIM
    #define CCILF_REP          692                                          // SDH 17-11-04 CREDIT CLAIM
    #define CCILF_OFLAGS       A_READ | A_WRITE | A_SHARE                   // SDH 17-11-04 CREDIT CLAIM
typedef struct CCILF_Record_Layout {                                        // SDH 26-11-04 CREDIT CLAIM
    BYTE abListNum[4];                                                      // SDH 26-11-04 CREDIT CLAIM
    BYTE abRecSeq[4];                                                       // SDH 26-11-04 CREDIT CLAIM
    BYTE abItemCode[7];                                                     // SDH 26-11-04 CREDIT CLAIM
    BYTE abBarCode[13];                                                     // SDH 26-11-04 CREDIT CLAIM
    BYTE abItemDesc[20];                                                    // SDH 26-11-04 CREDIT CLAIM
    BYTE abSelDesc[45];                                                     // SDH 26-11-04 CREDIT CLAIM
    BYTE abItemQty[4];                                                      // SDH 26-11-04 CREDIT CLAIM
    BYTE abFiller1[6];      //Unused                                        // SDH 26-11-04 CREDIT CLAIM
    BYTE abItemPrice[6];                                                    // SDH 26-11-04 CREDIT CLAIM
    BYTE cBusCentre;                                                        // SDH 26-11-04 CREDIT CLAIM
    BYTE abBusCentreDesc[14];                                               // SDH 26-11-04 CREDIT CLAIM
    BYTE abDateAdded[8];                                                    // SDH 26-11-04 CREDIT CLAIM
    BYTE abTimeAdded[4];                                                    // SDH 26-11-04 CREDIT CLAIM
    BYTE cItemStatus;   //'A' added, 'X' cancelled                          // SDH 26-11-04 CREDIT CLAIM
    BYTE abFiller2[3];                                                      // SDH 26-11-04 CREDIT CLAIM
} CCILF_REC;                                                                // SDH 26-11-04 CREDIT CLAIM
    #define CCILF_RECL         sizeof(CCILF_REC)                            // SDH 26-11-04 CREDIT CLAIM

//---- CCHIST ----                                                          // SDH 17-11-04 CREDIT CLAIM
    #define CCHIST              "ADXLXACN::D:/ADX_UDT1/CCHIST.BIN"          // SDH 17-11-04 CREDIT CLAIM
    #define CCHIST_KEYL         14                                          // SDH 17-11-04 CREDIT CLAIM
    #define CCHIST_REP          693                                         // SDH 17-11-04 CREDIT CLAIM
    #define CCHIST_OFLAGS       A_READ | A_WRITE | A_SHARE                  // SDH 17-11-04 CREDIT CLAIM
typedef struct CCHIST_Record_Layout {                                       // SDH 26-11-04 CREDIT CLAIM
    BYTE abUODNum[14];                                                      // SDH 26-11-04 CREDIT CLAIM
    BYTE abDateUODAdded[6];                                                 // SDH 26-11-04 CREDIT CLAIM
    BYTE abListNum[4];                                                      // SDH 26-11-04 CREDIT CLAIM
    BYTE abFiller[8];                                                       // SDH 26-11-04 CREDIT CLAIM
} CCHIST_REC;                                                               // SDH 26-11-04 CREDIT CLAIM
    #define CCHIST_RECL         sizeof(CCHIST_REC)                          // SDH 26-11-04 CREDIT CLAIM
typedef struct CCHIST_Home_Layout {                                         // SDH 26-11-04 CREDIT CLAIM
    BYTE abUODNum[14];                                                      // SDH 26-11-04 CREDIT CLAIM
    BYTE abLastSeq[6];                                                      // SDH 26-11-04 CREDIT CLAIM
    BYTE abFiller[12];                                                      // SDH 26-11-04 CREDIT CLAIM
} CCHIST_HOME;                                                              // SDH 26-11-04 CREDIT CLAIM

//---- CCDIRSU ----                                                         // SDH 17-11-04 CREDIT CLAIM
    #define CCDIRSU             "ADXLXACN::D:/ADX_UDT1/CCDIRSU.BIN"         // SDH 17-11-04 CREDIT CLAIM
    #define CCDIRSU_REP         694                                         // SDH 17-11-04 CREDIT CLAIM
    #define CCDIRSU_OFLAGS      A_READ | A_SHARE                            // SDH 17-11-04 CREDIT CLAIM
    #define CCDIRSU_KEYL        5                                           // SDH 17-11-04 CREDIT CLAIM
typedef struct CCDIRSU_Record_Layout {                                      // SDH 26-11-04 CREDIT CLAIM
    BYTE cBusCentre;                                                        // SDH 26-11-04 CREDIT CLAIM
    BYTE abSeqNum[4];                                                       // SDH 26-11-04 CREDIT CLAIM
    BYTE abSupplierNum[6];                                                  // SDH 26-11-04 CREDIT CLAIM
    BYTE abSupplierName[10];                                                // SDH 26-11-04 CREDIT CLAIM
} CCDIRSU_REC;                                                              // SDH 26-11-04 CREDIT CLAIM
    #define CCDIRSU_RECL         sizeof(CCDIRSU_REC)                        // SDH 17-11-04 CREDIT CLAIM

//---- DEAL ----                                                            // SDH 17-11-04 CREDIT CLAIM
    #define DEAL             "$EAL"                                         // SDH 17-11-04 CREDIT CLAIM
    #define DEAL_REP         311                                            // SDH 17-11-04 CREDIT CLAIM
    #define DEAL_OFLAGS      A_READ | A_SHARE                               // SDH 17-11-04 CREDIT CLAIM
    #define DEAL_KEYL        2                                              // SDH 26-11-04 PROMOTIONS
typedef struct DEAL_QLFY_Layout {                                           // SDH 26-11-04 PROMOTIONS
    BYTE bFlag;                                                             // SDH 26-11-04 PROMOTIONS
    BYTE bCode;                                                             // SDH 26-11-04 PROMOTIONS
    LONG lAmnt;                                                             // SDH 26-11-04 PROMOTIONS
    BYTE bList;                                                             // SDH 26-11-04 PROMOTIONS
    BYTE bFiller;                                                           // SDH 26-11-04 PROMOTIONS
} DEAL_QLFY;                                                                // SDH 26-11-04 PROMOTIONS
typedef struct DEAL_REWD_Layout {                                           // SDH 26-11-04 PROMOTIONS
    BYTE bCode;                                                             // SDH 26-11-04 PROMOTIONS
    BYTE bQty;                                                              // SDH 26-11-04 PROMOTIONS
    LONG lAmt;                                                              // SDH 26-11-04 PROMOTIONS
    BYTE bList;                                                             // SDH 26-11-04 PROMOTIONS
    BYTE bQualMsg;                                                          // SDH 26-11-04 PROMOTIONS
    BYTE abQlfyMsgRcpt[38];                                                 // SDH 26-11-04 PROMOTIONS
    BYTE abQlfyMsgDisp[20];                                                 // SDH 26-11-04 PROMOTIONS
    BYTE bRewdMsg;                                                          // SDH 26-11-04 PROMOTIONS
    BYTE abRewdMsgRcpt[27];                                                 // SDH 26-11-04 PROMOTIONS
    WORD wMaxQlfy;                                                          // SDH 26-11-04 PROMOTIONS
    WORD wNumRewdQlfy;                                                      // SDH 26-11-04 PROMOTIONS
    BYTE abFiller[2];                                                       // SDH 26-11-04 PROMOTIONS
} DEAL_REWD;                                                                // SDH 26-11-04 PROMOTIONS
typedef struct DEAL_REC_Layout {                                            // SDH 26-11-04 PROMOTIONS
    BYTE abDealNumPD[2];                                                    // SDH 26-11-04 PROMOTIONS
    BYTE abPrevDealPD[2];                                                   // SDH 26-11-04 PROMOTIONS
    BYTE abNextDealPD[2];                                                   // SDH 26-11-04 PROMOTIONS
    BYTE abStartDatePD[4];                                                  // SDH 26-11-04 PROMOTIONS
    WORD wStartTime;                                                        // SDH 26-11-04 PROMOTIONS
    BYTE abEndDatePD[4];                                                    // SDH 26-11-04 PROMOTIONS
    WORD wEndTime;                                                          // SDH 26-11-04 PROMOTIONS
    BYTE cBusCentre;                                                        // SDH 26-11-04 PROMOTIONS
    BYTE abDealDesc[35];                                                    // SDH 26-11-04 PROMOTIONS
    BYTE bNumLists;                                                         // SDH 26-11-04 PROMOTIONS
    BYTE bRunDay;                                                           // SDH 26-11-04 PROMOTIONS
    BYTE bPriority;                                                         // SDH 26-11-04 PROMOTIONS
    WORD wExemptTills;                                                      // SDH 26-11-04 PROMOTIONS
    BYTE bFlags1;                                                           // SDH 26-11-04 PROMOTIONS
    BYTE bSalesPrompt;                                                      // SDH 26-11-04 PROMOTIONS
    BYTE bExclMsg;                                                          // SDH 26-11-04 PROMOTIONS
    BYTE bFlags2;                                                           // SDH 26-11-04 PROMOTIONS
    BYTE bNumQlfns;                                                         // SDH 26-11-04 PROMOTIONS
    BYTE bNumRewds;                                                         // SDH 26-11-04 PROMOTIONS
    BYTE abFiller[3];                                                       // SDH 26-11-04 PROMOTIONS
    DEAL_QLFY Qual[4];                                                      // SDH 26-11-04 PROMOTIONS
    DEAL_REWD Rewd[3];                                                      // SDH 26-11-04 PROMOTIONS
} DEAL_REC;                                                                 // SDH 26-11-04 PROMOTIONS
    #define DEAL_RECL         sizeof(DEAL_REC)                              // SDH 26-11-04 PROMOTIONS
//---- TDTFF (Deal trickle file) ----                                       // SDH 26-11-04 PROMOTIONS
    #define TDTFF            "$DTFF"                                        // SDH 26-11-04 PROMOTIONS
    #define TDTFF_REP        650                                            // SDH 26-11-04 PROMOTIONS
    #define TDTFF_OFLAGS     A_READ | A_SHARE                               // SDH 26-11-04 PROMOTIONS
typedef struct TDTFF_HEADER_Layout {                                        // SDH 26-11-04 PROMOTIONS
    LONG lPtr;                                                              // SDH 26-11-04 PROMOTIONS
    LONG lMaxPtr;                                                           // SDH 26-11-04 PROMOTIONS
} TDTFF_HEADER;                                                             // SDH 26-11-04 PROMOTIONS
typedef struct TDTFF_REC_Layout {                                           // SDH 26-11-04 PROMOTIONS
    UWORD uwDealNumPD;                                                      // SDH 26-11-04 PROMOTIONS
} TDTFF_REC;                                                                // SDH 26-11-04 PROMOTIONS
    #define TDTFF_RECL      sizeof(TDTFF_REC)                               // SDH 26-11-04 PROMOTIONS

    #define EPSOM           "D:\\ADX_UDT1\\EPSOM.BIN"                       // v3.0
    #define EPSOM_RECL      1L                                              // v3.0
    #define EPSOM_REP       186                                             // v3.0
    #define EPSOM_OFLAGS    0x200F  // Exclusive lock required              // v3.0

    #define PCHK            "D:\\ADX_UDT1\\PCHECK.BIN"                      // v3.0
    #define PCHK_RECL       1L                                              // v3.0
    #define PCHK_REP        190                                             // v3.0
    #define PCHK_OFLAGS     0x200F  // Exclusive lock required              // v3.0
                                                                         
    #define CCDMY           "CCDMY"                                         // 16-11-2004 SDH
    #define CCDMY_REP       324                                             // 16-11-2004 SDH
    #define CCDMY_OFLAGS    A_FORCE                                         // 16-11-2004 SDH

#define JOBOK           "JOBOK"                                              // 13-12-2004 PAB
#define JOBOK_RECL      84L                                                  // 13-12-2004 PAB
#define JOBOK_REP       14                                                   // 13-12-2004 PAB
#define JOBOK_OFLAGS    0x201C                                               // 13-12-2004 PAB
                                                                             // 13-12-2004 PAB
typedef struct JOBOK_Record_Layout {                                         // 13-12-2004 PAB
   BYTE delim1[1];
   BYTE psb21[1];          // Started,Ended,Xabend                           // 13-12-2004 PAB
   BYTE psb22[1];                                                            // 13-12-2004 PAB
   BYTE psb23[1];                                                            // 13-12-2004 PAB
   BYTE psb24[1];                                                            // 13-12-2004 PAB
   BYTE psb25[1];                                                            // 13-12-2004 PAB
   BYTE filler[78];                                                          // 13-12-2004 PAB
} JOBOK_REC;                                                                 // 13-12-2004 PAB

#define POGOK           "POGOK"                                                            
#define POGOK_RECL      80L                                                                
#define POGOK_REP       718
#define POGOK_OFLAGS    A_READ | A_SHARE
typedef struct POGOK_Record_Layout {                                                       
   BYTE abSRDELTASerial[4];
   BYTE abSRMAPSerial[4];                                                                  
   BYTE abSRDELTADate[4];           //YYYYMMDD (packed)
   BYTE abSRMAPDate[4];             //YYYYMMDD (packed)
   BYTE cReload;                    //Y/N
   BYTE cSRP10;                     //SEXY
   BYTE cSRP05;                     //SEXY
   BYTE cSRP06;                     //SEXY
   BYTE cSRP07;                     //SEXY
   BYTE cSRP04;                     //SEXY
   BYTE cSRP10rc;                   //0=ok
                                    //1=record count mismatch
                                    //2=missing trailer
                                    //3=out of seq. serial num
                                    //4=old file previous processed
                                    //5=delta file sent when initial load was expected
                                    //6=input file not found
                                    //7=run not required, awaiting previous application
   BYTE cSRP05rc;                   //As above
   BYTE cSRP06rc;                   //As above
   BYTE cSRP07rc;                   //As above
   BYTE cSRP04rc;                   //As above
   BYTE abSRDELTAFailedSerial[4];
   BYTE abSRDELTAFailedDate[4];     //YYYYMMDD (packed)
   BYTE abSRMAPFailedSerial[4];
   BYTE abSRMAPFailedDate[4];       //YYYYMMDD (packed)
   BYTE abSRP10Date[4];             //YYYYMMDD (packed)
   BYTE abSRP05Date[4];             //YYYYMMDD (packed)
   BYTE abSRP06Date[4];             //YYYYMMDD (packed)
   BYTE abSRP07Date[4];             //YYYYMMDD (packed)
   BYTE abSRP04Date[4];             //YYYYMMDD (packed)
   WORD wRetainDays;
   BYTE cSRP19;                     //SEXY
   BYTE cSRP19rc;                   //As above (0=ok...)
   BYTE abSRP19Date[4];             //YYYYMMDD (packed)
   BYTE SRDELTARecCount[4];
   BYTE SRMAPRecCount[4];    
   BYTE bFiller;
} POGOK_REC;                                                                               

#define SRPOG           "SRPOG"
#define SRPOG_RECL      101L
#define SRPOG_KEYL      4
#define SRPOG_REP       719      
#define SRPOG_OFLAGS    A_READ | A_SHARE
typedef struct SRPOG_Record_Layout {
    ULONG ulKey;
    ULONG ulID;
    BYTE abActiveDate[4];           //YYYYMMDD (packed)
    BYTE abDeactiveDate[4];         //YYYYMMDD (packed)
    BYTE abDesc[30];       
    BYTE abSRCATDesc[30];
    UBYTE ubModuleCount;
    ULONG ulSRCATKey;
    UBYTE ubKeyHierachy;            //1, 2 or 3
    UBYTE ubLiveRepeatCount;
    BYTE abDateRepeatCount[4];      //YYYYMMDD (packed)
    UBYTE ubPendingRepeatCount;
    LONG lCat1ID;
    LONG lCat2ID;
    LONG lCat3ID;
    BYTE bFiller;
} SRPOG_REC;                                                                               

#define SRMOD           "SRMOD"
#define SRMOD_RECL      508L
#define SRMOD_KEYL      6
#define SRMOD_REP       719
#define SRMOD_OFLAGS    A_READ | A_SHARE
typedef struct {
    UBYTE ubShelfNum;
    UBYTE ubFacings;
    BYTE abItemCode[3];
    UWORD uwMaxDisplyQty;
    UWORD uwPhysicalShelfCapacity;
} ShelfItem;
#define SRMOD_NUM_ITEMS 50
typedef struct SRMOD_Record_Layout {
    ULONG ulKey;
    UBYTE ubModSeq;                     //Base 0
    BYTE cChain;                        //Base 0
    BYTE abModuleDesc[30];          
    ShelfItem aShelfItem[SRMOD_NUM_ITEMS];
    UWORD uwShelfCount;
    UWORD uwItemCoun;
    BYTE abFiller[18];                  
} SRMOD_REC;

#define SRITML          "SRITML"
#define SRITMP          "SRITMP"
#define SRITML_RECL     127L
#define SRITMP_RECL     127L
#define SRITML_KEYL     4
#define SRITMP_KEYL     4
#define SRITML_REP      721
#define SRITMP_REP      722
#define SRITML_OFLAGS   A_READ | A_SHARE
#define SRITMP_OFLAGS   A_READ | A_SHARE
typedef struct {
    ULONG ulPOGKey;
    UBYTE ubModSeq;
    UBYTE ubRepeatCnt;
    BYTE bCoreFlag;                 //Core=Y, NonCore=N
} ModuleKey;
#define SRITM_NUM_MODS  16
typedef struct SRITM_Record_Layout {
    BYTE abItemCode[3];
    UBYTE ubRecChain;               //Base 0
    UBYTE ubModuleCount;                
    UWORD uwCoreItemCount;
    UWORD uwNonCoreItemCount;
    ModuleKey aModuleKey[SRITM_NUM_MODS];
    BYTE abFiller[6];
} SRITML_REC, SRITMP_REC;

#define SRPOGIF         "SRPOGIF"
#define SRPOGIF_RECL    64L
#define SRPOGIF_REP     723
#define SRPOGIF_OFLAGS  A_READ | A_SHARE
typedef struct SRPOGIF_Record_Layout {
    BYTE abDesc[50];                //50 bytes legacy.  desc is actually 30 bytes on other files
    ULONG ulPOGLiveIndexPtr;
    ULONG ulPOGPendingIndexPtr;
    UBYTE ubFamilyType;             //1=CORE,2=Gondola-end,3=Mid gondola,4=PSDU
    UBYTE ubKeyHierachy;          
    ULONG ulSRCATKey;
} SRPOGIF_REC;

#define SRPOGIL         "SRPOGIL"
#define SRPOGIP         "SRPOGIP"
#define SRPOGIL_RECL    64L
#define SRPOGIP_RECL    64L
#define SRPOGIL_REP     724
#define SRPOGIP_REP     725
#define SRPOGIL_OFLAGS  A_READ | A_SHARE
#define SRPOGIP_OFLAGS  A_READ | A_SHARE
typedef struct SRPOGI_Record_Layout {
    ULONG ulPOGKey;
    ULONG ulNextPOGIRec;            //Next planner in family (or 0xFFFFFFFF for end of chain)
    ULONG ulPOGId;                  //Non-unique
    BYTE abDesc[30];
    BYTE abActiveDate[4];           //YYYYMMDD (packed)
    BYTE abDeactiveDate[4];         //YYYYMMDD (packed)
    UBYTE ubModuleCount;                
    ULONG ulSRCATKey;
    BYTE abFiller1[4];
    UBYTE ubSRMAPRepeatCnt;
    BYTE bCoreFlag;                 //Y=Core,N=NonCore
    BYTE abFiller2[3];
} SRPOGIL_REC, SRPOGIP_REC;

#define SRCAT           "SRCAT"
#define SRCAT_RECL      64L
#define SRCAT_REP       726
#define SRCAT_OFLAGS    A_READ | A_SHARE
typedef struct SRCAT_Record_Layout {
    ULONG ulKey;
    BYTE abDesc[30];
    UBYTE ubKeyHierachy;
    BYTE bCoreFlag;                 //Y=Core,N=NonCore
    BYTE abFiller[28];
} SRCAT_REC;

#define SRSDF           "SRSDF"
#define SRSDF_RECL      34L
#define SRSDF_KEYL      4
#define SRSDF_REP       729
#define SRSDF_OFLAGS    A_READ | A_SHARE
typedef struct {
    ULONG ulKey;
    BYTE abDesc[30];
} SRSDF_REC;

#define SRSXF           "SRSXF"
#define SRSXF_RECL      63L
#define SRSXF_KEYL      6
#define SRSXF_REP       730
#define SRSXF_OFLAGS    A_READ | A_SHARE
typedef struct {
    ULONG ulPOGDB;
    UBYTE ubModSeq;
    UBYTE ubShelfNum;
    UBYTE ubNotchNum;
    ULONG ulShelfDescKey;
    BYTE abShelfDesc[30];
    BYTE abFiller[2];
} SRSXF_REC;
 

#endif /* RFSFILE_H not defined */

