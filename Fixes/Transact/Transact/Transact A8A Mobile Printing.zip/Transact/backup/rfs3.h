
URC open_phf( void );
URC close_phf( WORD type );
LONG readPhf(LONG lLineNumber); 
URC open_iduf( void );
URC close_iduf( WORD type );
LONG ReadIduf(LONG lLineNumber); 


