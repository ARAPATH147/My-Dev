/*************************************************************************
*
*
* File: sockserv.c
*
* Author: Prashant Kotak
*
* Created: 18/08/97
*
* Purpose: High Level TCP/IP vendor-independant Sockets Server.
*
* History:
*
* Version B Paul Bowers
*
* Created 28/08/2004
*
* Purpose - Track PPC unit IP address to enable reconnection
* resource reuse rather than incremental allocation for each new PPC
* which connects without a valid disconnect. So if a unit connects and
* its IP addres is already known send the old UNIT number to the main
* core.
*
* 17/12/2009 BMG
* Changes to accomodate message fragmentation and new message
* formatting with message lengths for RF Stabilisation.
*
*************************************************************************/

#include "transact.h"                                                       //SDH 19-May-2006

#include "osfunc.h"
#include <flexif.h>
#include "osfunc.h"
#include "trxfile.h"                                                        // Streamline SDH 22-Sep-2008
#include "rfglobal.h"                                                       //SDH 21-June-2006
#include "sockserv.h"
#include "trxutil.h"                                                        // BMG 17-12-2009
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
//#include "app_proc.h"

#define STKCF           "STKCF"
#define STKCF_OFLAGS    0x2018
#define STKCF_REP       0
#define POLL_FREQ       5000L

enum group_status {
    STATUS_READ,
    STATUS_WRITE,
    STATUS_EXCPT
};

enum sock_state {
    ERROR_STATE = -1,
    UNCONNECTED = 0,
    AWAITING_INPUT,
    AWAITING_OUTPUT,
    AWAITING_DISCONNECT
};


enum appmsg_type {
    MSG_TYPE_RBS,
    MSG_TYPE_BOOTS
};

//extern unsigned int LoopDelay ;
//extern unsigned int BootsHookFreq ;
//extern char PollControlFile ;
//extern long OpenDirectFile ( char *, unsigned int, int ) ;
//extern void CloseAllFiles ( void ) ;

CLIENT    *Clients[MAX_SOCKETS];              // client details TCP/IP table
sock_handle  PrimarySocketHandle;             // primary socket handle

extern int tcperrno;

extern int process ( char *, int * ) ;  // v4.01

////////////////////////////////////////////////////////////////////////////////
///
///   PRIVATE FUNCTIONS
///
////////////////////////////////////////////////////////////////////////////////

static void CloseSocket ( sock_handle *SocketHandle )
{
   soabort ( *SocketHandle ) ;
   soclose ( *SocketHandle ) ;
}

static void ReleaseClientSlot (int SlotIndex)
{
   if ( Clients[SlotIndex] != (void *) NULL ) {
      // free the Buffer that has been allocated to this client
      FreeBuffer( (void *) Clients[SlotIndex]->Buffer );

      // now free the client itself
      FreeBuffer( (void *) Clients[SlotIndex] );
      //LogMessage( 10, "Client Slot %d Freed", SlotIndex ) ;

      //... and mark the slot as free
      Clients[SlotIndex] = NULL;
   }
}

static int AllocateSocket ( sock_handle *SockHandle )
{
   int rc ;

   /* allocate socket */
   rc = socket ( AF_INET, SOCK_STREAM, 0 ) ;
   if ( rc < 0 ) {
      sprintf(sbuf, "socket() failed with %d", tcperrno);
      disp_msg(sbuf);
   }
   *SockHandle = rc ;

   return rc ;
}

static int BindSocket ( sock_handle *SockHandle, int iPortNum )             // Streamline SDH 16-Sep-08
{
   int rc ;
   struct sockaddr_in addr ;

   // clear out struct and set it up
   memset ( ( char * ) &addr, 0, sizeof ( addr ) ) ;
   addr.sin_family = AF_INET;
   addr.sin_port = BSWAP(iPortNum);                                         // SDH 19-05-2005
   addr.sin_addr.s_addr = INADDR_ANY;

   rc = bind ( *SockHandle, ( struct sockaddr * ) &addr, sizeof ( addr ) ) ;
   if (rc < 0) {
      sprintf(sbuf, "bind() failed with: %d, attempting retry...", tcperrno); // Streamline SDH 16-Sep-2008
      disp_msg (sbuf);
      rc = port_cancel(BSWAP(iPortNum));                                      // SDH 19-05-2005
      sprintf(sbuf, "Port Cancel returned: rc=%d, err=%d", rc, tcperrno);     // Streamline SDH 16-Sep-2008
      disp_msg(sbuf);                                                         // Streamline SDH 16-Sep-2008
      rc = bind ( *SockHandle, ( struct sockaddr * ) &addr, sizeof ( addr ) ) ;
      if ( rc < 0 ) {
         sprintf(sbuf, "bind() failed again with : %d, oh dear!", tcperrno);  // Streamline SDH 16-Sep-2008
         disp_msg(sbuf);                                                      // Streamline SDH 16-Sep-2008
         CloseSocket ( SockHandle ) ;
      } else {
         disp_msg("oh, we're ok!");                                           // Streamline SDH 16-Sep-2008
      }
   } else {
      sprintf(sbuf, "bind() succeeded, tcperrno: %d", tcperrno);              // Streamline SDH 16-Sep-2008
      disp_msg(sbuf);                                                         // Streamline SDH 16-Sep-2008
      rc = 1 ;
   }

   return rc ;
}

static int ListenOnSocket ( sock_handle *SockHandle )
{
   int rc1, rc2, noblock ;

   // listen with a max of 10 connection requests queued (more ignored)
   rc1 = listen ( *SockHandle, 10 ) ;
   if ( rc1 != 0 ) {
      sprintf(sbuf, "listen() failed with %d", tcperrno);                   // Streamline SDH 16-Sep-2008
      disp_msg(sbuf);                                                       // Streamline SDH 16-Sep-2008
      CloseSocket ( SockHandle ) ;
   } else {
      //sprintf(sbuf, "listen() succeeded with SocketHandle=%d", *SockHandle);// Streamline SDH 16-Sep-2008
      //disp_msg(sbuf);                                                       // Streamline SDH 16-Sep-2008
      // listen succeeded so place the socket in nonblocking mode
      noblock = 1 ;
      rc2 = ioctl ( *SockHandle, FIONBIO,
                    ( char * ) &noblock, sizeof ( noblock ) ) ;
      if ( rc2 != 0 ) {
         rc1 = -1 ;
         sprintf (sbuf, "ioctl() failed with %d", tcperrno);                // Streamline SDH 16-Sep-2008
         disp_msg(sbuf);                                                    // Streamline SDH 16-Sep-2008
         CloseSocket( SockHandle ) ;
      }
   }
   return rc1 ;
}

static int AcceptOnSocket ( sock_handle *OriginalSocket, CLIENT *client )
{
   int namelen ;

   namelen = sizeof ( client->SocketAddress );
   client->SocketHandle = accept( *OriginalSocket,
                                  &( client->SocketAddress ),
                                  &namelen ) ;

   if (client->SocketHandle < 0 ) {
      if ( tcperrno == EWOULDBLOCK ) {
         // we're here because there are no outstanding
         // connect requests and we're not in blocking mode
         //printf ("accept returned EWOULDBLOCK\n");

      } else {
         sprintf (sbuf, "accept() failed with %d", tcperrno);               // Streamline SDH 16-Sep-2008
         disp_msg (sbuf);                                                   // Streamline SDH 16-Sep-2008
         /* close the socket */
         CloseSocket ( &( client->SocketHandle ) ) ;
         /* mark failed for return */
         client->SocketHandle = -1 ;
      }
   } else {
      // we've connected...

      sprintf (sbuf, "Client Connected, Handle = %d", client->SocketHandle);// Streamline SDH 16-Sep-2008
      disp_msg (sbuf);                                                      // Streamline SDH 16-Sep-2008

      // record the length of the client address
      client->SocketAddrLen = namelen ;
      // mark this client as in use...
      client->InUse = 1 ;
      // ...and its awaiting input from client
      client->SocketState = AWAITING_INPUT ;
      // set default values                                                                // BMG 17-12-2009
      client->Continuation = 0;                                                            // BMG 17-12-2009
      client->NewFormMess = 0;                                                             // BMG 17-12-2009
   }

   return client->SocketHandle ;
}

static int SocketGroupStatus ( int *sock_handles, int num_socks, int sock_type )
{
   int rc, st_read, st_write, st_excpt ;
//   long timeout = 16000 ;
   long timeout = 5000L ;

   st_read = st_write = st_excpt = 0 ;
   switch ( sock_type ) {
   case STATUS_READ:
      st_read = num_socks ;
//            ioctl ( sock_handles[0], FIONBIO,
//                      ( char * ) &noblock, sizeof ( noblock ) ) ;
      break ;

   case STATUS_WRITE:
      st_write = num_socks ;
      break ;

   case STATUS_EXCPT:
      st_excpt = num_socks ;
      break ;
   }

   // check num_socks handles for read availability
   //sprintf (sbuf, "Read=%d,Write=%d,Excp=%d", st_read, st_write, st_excpt); // Streamline SDH 16-Sep-2008
   //disp_msg (sbuf);                                                         // Streamline SDH 16-Sep-2008

   rc = select( sock_handles, st_read, st_write, st_excpt, timeout ) ;
   if ( rc < 0 ) {
      sprintf (sbuf, "select() failed with %d", tcperrno);                  // Streamline SDH 16-Sep-2008
      disp_msg (sbuf);                                                      // Streamline SDH 16-Sep-2008
      rc = 0 ;
   } else if ( rc == 0 ) {
      //disp_msg ("select() timed out");                                      // Streamline SDH 16-Sep-2008
      rc = 0 ;
   } else if ( rc > 0 ) {
      // success
      //disp_msg ("select() succeeded");                                      // Streamline SDH 16-Sep-2008
   } else {
      sprintf (sbuf, "unknown select() error: %d", tcperrno);               // Streamline SDH 16-Sep-2008
      disp_msg (sbuf);                                                      // Streamline SDH 16-Sep-2008
      rc = 0 ;
   }

   return rc ;
}

static int ReadSocket ( CLIENT *client )
{
   int rc ;
   int iMessLen;                                                                           // BMG 17-12-2009
   int iFragPoint;                                                                         // BMG 17-12-2009
   int iFullRead;                                                                          // BMG 17-12-2009
   BYTE TempBuff[BUFFER_SIZE];                                                             // BMG 17-12-2009
   
   sprintf (sbuf, "ReadSocket: SocketHandle = %d, BufferSize = %d",         // Streamline SDH 16-Sep-2008
                client->SocketHandle, client->BufferSize);
   disp_msg (sbuf);                                                         // Streamline SDH 16-Sep-2008

   //rc = recv ( client->SocketHandle, client->Buffer, client->BufferSize, 0 ) ;           // BMG 17-12-2009 Replaced with routine below

   // New message handling socket read                                                     // BMG 17-12-2009
   iFullRead = 1;
   if (client->Continuation) {
       //We are expecting more data from previous request so
       //see if the incoming is the rest of the previous message
       rc = recv ( client->SocketHandle, TempBuff, client->BufferSize, MSG_PEEK );
       if (rc > 0) {
           if (TempBuff[0] == 0xFF) {
               //Got a new message so nothing we can do but process this message below
               client->Continuation = 0;
               client->NewFormMess = 0;
               client->MessageLen = 0;
           } else {
               //Add the new fragment onto the previous message.
               sprintf (sbuf, "Fragmented message - got more of a message on this socket"); disp_msg (sbuf);
               iFragPoint = client->MessageLen;
               rc = recv ( client->SocketHandle, client->Buffer+iFragPoint, rc, 0 ) ;
               rc+=client->MessageLen;
               client->MessageLen = rc;
               //Check to see if we now have the whole message
               iMessLen = satoi(client->Buffer+1, 4);
               if (iMessLen == client->MessageLen) {
                   client->Continuation = 0;
               } else rc = 0;
               //Don't do socket message read again
               iFullRead = 0;
           }
       }
   }
   if (iFullRead) {
       rc = recv ( client->SocketHandle, client->Buffer, client->BufferSize, 0 ) ;
       if (rc > 5) { //no point testing if less than 5 - just let it through as not new style messages
           if (client->Buffer[0] == 0xFF) {
               //Got new style message so validate message length
               client->NewFormMess = 1;
               iMessLen = satoi(client->Buffer+1, 4);
               if (iMessLen != rc) {
                   sprintf (sbuf, "*** BAD message length. Expected %i, got %i", iMessLen, rc); disp_msg (sbuf);
                   dump((BYTE *)client->Buffer, rc);
                   if (iMessLen > rc) {
                       //More of the message to come (fragmented message) so set up pointers and wait for more data
                       sprintf (sbuf, "Fragmented message - wait for more of the message"); disp_msg (sbuf);
                       client->Continuation = 1;
                       client->MessageLen = rc;
                       rc = 0;
                   } else {
                       //Too much data so create an ANK response
                       sprintf (sbuf, "Message too long - converting to ANK/NAK"); disp_msg (sbuf);
                       sprintf(client->Buffer+1, "0045ANKInvalid Message - Too long           ");
                       rc = 45;
                       client->MessageLen = rc;
                   }
               } //Message good so let through
           } else client->NewFormMess = 0; // else just let existing message type through
       } else client->NewFormMess = 0;
   }
   
   sprintf (sbuf, "recv(): rc=%d, TCPERRNO=%d", rc, tcperrno);              // Streamline SDH 16-Sep-2008
   disp_msg (sbuf);                                                         // Streamline SDH 16-Sep-2008

   if (rc <= 0) {
      // we failed, test error
      if ( (rc == 0 && client->Continuation == 0) || ( rc < 0 && tcperrno != EWOULDBLOCK ) ) { // BMG 17-12-2009 rc will be zero if more data to come!
         
         /* mark failed for return */
         client->SocketState = ERROR_STATE ;

         if (rc == 0) {
             sprintf(sbuf, "Client (handle=%d) requested disconnect", client->SocketHandle);
         } else {
             sprintf(sbuf, " Socket (handle=%d) marked for Disconnect after recv() failed",
                     client->SocketHandle);
         }
         disp_msg(sbuf);                                                    // Streamline SDH 16-Sep-2008

      }
   } else {
      // success
      // Set message length - not set up before for some reason             //BMG 1.1 12/09/2008
      client->MessageLen = rc;                                              //BMG 1.1 12/09/2008
   }

   return rc ;
}

static int WriteSocket ( CLIENT *client )
{
   int rc ;

   rc = send ( client->SocketHandle, client->Buffer, client->MessageLen, 0 ) ;
   if (rc < 0) {
      /* we failed because of an error*/
      sprintf (sbuf, "send() failed rc=%d, TCPERRNO=%d", rc, tcperrno);     // Streamline SDH 16-Sep-2008
      disp_msg (sbuf);

      /* mark failed for return */
      client->SocketState = ERROR_STATE ;

      sprintf(sbuf, " Socket (handle=%d) marked for Disconnect after send() failed", // Streamline SDH 16-Sep-2008
                   client->SocketHandle);
      disp_msg (sbuf);                                                      // Streamline SDH 16-Sep-2008
   }

   // clear down the buffer
   memset ( client->Buffer, 0, client->BufferSize ) ;

   return rc ;
}

static void ProcessPendingConnects ( sock_handle *SockHandle )
{
   static int index = -1 ; // initalise to 'not assigned'
   int result ;

   //LogMessage ( 10, "Processing pending connects" ) ;

   do {
      // get a new slot if the memory for one is not already allocated
      if ( index < 0 ) {
         index = GetFreeClientSlot () ;
      }

      if ( index >= 0 ) {
         // Got an assigned slot. Try to accept on the socket
         //disp_msg ("About to attempt AcceptOnSocket");                    // Streamline SDH 16-Sep-2008
         result = AcceptOnSocket ( SockHandle, Clients[index] ) ;
         if ( result >= 0 ) {
            // Conncetion was accepted. Check if this HHT (IP address)
            // is already logged on and if so, use the old connection instead
            index = ClearOldClientConnection ( index ) ;                    //SDH 16-05-2005

            // record who it is, for when we have
            // to tell Boots app the HH_UNIT ID
            Clients[index]->HhtId = index ;

            index = -1 ; // we'll need a new ClientSlot next time
         }
         //else
         //{
         //    // accept did not have anyone awaiting connects or accept failed
         //    ReleaseClientSlot ( index ) ;
         //}
      } else {
         result = 0 ; // no more free Client slots available
      }
   }
   while ( result >= 0 ) ;
}

static void DummyCallToProcess ( void )
{
    char Buffer[BUFFER_SIZE];                                    // Streamline SDH 21-Sep-2008
    //RBSCommandStruct *RbsCmd;
    int SizeOfCmd = 3;                                           // Streamline SDH 21-Sep-2008

    //RbsCmd = ( RBSCommandStruct * ) Buffer;                    // Streamline SDH 21-Sep-2008
    // setup dummy command
    //memcpy( RbsCmd->TID, RF_HHT_MSG_RBS_RESERVED, RF_MESSAGE_TID_LENGTH );
    memcpy( Buffer, "XXX", 3);                                   // Streamline SDH 21-Sep-2008
    //RbsCmd->Command = -1; // dummy, invalid command            // Streamline SDH 21-Sep-2008

    // issue it to hook into Boots code
    CurrentHHT = -1 ; // setup for process()
    //process( ( char * ) RbsCmd , &SizeOfCmd);
    process(Buffer, &SizeOfCmd);                                 // Streamline SDH 21-Sep-2008
}

static void ProcessPendingReceives ( void )
{
   int i, j, rc ;
   int sock_read  [MAX_SOCKETS] = { 0} ;
   int sock_index [MAX_SOCKETS] = { 0} ;

   // Check the Client structure for sockets who can
   // receive and build a handles array of those who can

   // Set to test for reads on primary socket
   sock_read [0] = PrimarySocketHandle ;
   sock_index [0] = 0 ;

   // Set up child sockets
   for ( j = 1, i = 0 ; i < MAX_SOCKETS ; i++ ) {
      if ( Clients[i] != ( void * ) NULL ) {
         if ( Clients[i]->InUse == 1 &&
              Clients[i]->SocketHandle >= 0 &&
              Clients[i]->SocketState == AWAITING_INPUT ) {
            // add the socket handle on which we expect a read to our array
            sock_read[j] = Clients[i]->SocketHandle ;
            // record the index in parallel
            sock_index[j++] = i ;
         }
      }
   }

   //LogMessage( 7, "Awaiting Receive from %d clients", j ) ;
   // printf( "Awaiting Receive from %d clients\n", j ) ;

   // setup multiplexed test to find which sockets are ready to be read
   rc = SocketGroupStatus ( &sock_read[0], j, STATUS_READ ) ;

   // printf ( "Select ended rc = %d\n", rc ) ;

   if ( sock_read[0] != -1 ) {
      ProcessPendingConnects ( &PrimarySocketHandle ) ;
   } else {
      if ( rc > 0 ) { // the group status check shows 1 or more sockets to read
         // process all the ready sockets
         for ( i = 1 ; i < j ; i++ ) {
            if ( sock_read[i] != -1 ) {

               //LogMessage( 10, "Socket Handle %d is ready to be read", i );

               // found socket ready with data, so read it
               rc = ReadSocket ( Clients[sock_index[i]] ) ;

               // we've got some data from the client, so process it
               // ...and set state 'awaiting send to client'
               if ( rc > 0 ) {
                  CurrentHHT = Clients[sock_index[i]]->HhtId ; // setup for process()// Streamline SDH 16-Sep-2008
                  process ( Clients[sock_index[i]]->Buffer,                          // Streamline SDH 16-Sep-2008
                            &( Clients[sock_index[i]]->MessageLen ) ) ;              // Streamline SDH 16-Sep-2008
                  Clients[sock_index[i]]->SocketState =  AWAITING_OUTPUT ;           // Streamline SDH 16-Sep-2008
               }

            } else {
               sprintf (sbuf, "Client %d (SocketHandle=%d) failed on READ select()", // Streamline SDH 16-Sep-2008
                        sock_index[i], Clients[sock_index[i]]->SocketHandle );
               disp_msg (sbuf);                                             // Streamline SDH 16-Sep-2008
            }
         }
      }
   }
}

static void ProcessPendingSends(void)
{
   int i, j, rc;
   int sock_write[MAX_SOCKETS], sock_index[MAX_SOCKETS];

   // Check the Client structure for sockets to whom
   // we have to send and build a handles array of these
   for (j = 0, i = 0; i < MAX_SOCKETS; i++) {
      if (Clients[i] != NULL) {
         // we have to send an ACK _before_ we disconnect
         // so we still send even if we are awaiting disconnect.
         if (Clients[i]->InUse == 1 &&
             Clients[i]->SocketHandle >= 0 &&
             (Clients[i]->SocketState == AWAITING_OUTPUT ||
              Clients[i]->SocketState == AWAITING_DISCONNECT)) {
            // add socket handle on which we expect a read to our array
            sock_write[j] = Clients[i]->SocketHandle ;
            // record the index in parallel
            sock_index[j++] = i ;
         }
      }
   }

   if (j > 0 ) {
      //LogMessage( 9, "Awaiting Send to %d clients", j ) ;
      // setup multiplexed test to find which sockets are ready to be read
      rc = SocketGroupStatus(sock_write, j, STATUS_WRITE);

      //if (rc > 0)
      {
         // process all the ready sockets
         for (i = 0; i < j; i++) {
            if (sock_write[i] != -1) {
               //LogMessage( 10, "Socket Handle %d is ready to be written", i );

               // socket ready, so write to it whatever we've prepared
               rc = WriteSocket(Clients[sock_index[i]]);

               if (rc > 0 &&
                   Clients[sock_index[i]]->SocketState == AWAITING_OUTPUT) {
                  // ...and set state to 'awaiting message from client'
                  Clients[sock_index[i]]->SocketState = AWAITING_INPUT;
               }
            } else {
               sprintf (sbuf, "Client %d (SocketHandle=%d) failed on select() WRITE", // Streamline SDH 16-Sep-2008
                        sock_index[i], Clients[sock_index[i]]->SocketHandle );
               disp_msg (sbuf);                                             // Streamline SDH 16-Sep-2008
            }
         }
      }
   }
}

static void ProcessPendingDisconnects ( void )
{
   int i ;

   // Check the Client structure for sockets we can disconnect immediately
   for (i = 0; i < MAX_SOCKETS; i++) {
      if (Clients[i] != NULL) {
         // look for sockets awaiting disconnect.
         if ( Clients[i]->InUse == 1 &&
              Clients[i]->SocketHandle >= 0 &&
              Clients[i]->SocketState == ERROR_STATE ) {
            sprintf (sbuf, "Disconnecting Client %d (SocketHandle=%d)...",  // Streamline SDH 16-Sep-2008
                        i, Clients[i]->SocketHandle );
            disp_msg (sbuf);                                                // Streamline SDH 16-Sep-2008
            CloseSocket( &(Clients[i]->SocketHandle));
            ReleaseClientSlot(i);
            //LogMessage( 7, "...Client %d Disconnected!", i);
         }
      }
   }
}

static int GetFreeClientSlot(void)
{
   int found, i;

   //LogMessage( 10, "In GetFreeClientSlot");

   // Check the Client structure for any empty slots
   for (found = 0, i = 0; i < MAX_SOCKETS; i++) {
      if (Clients[i] == NULL) {
         // found an unused slot so assign memory to it
         Clients[i] = (CLIENT *) AllocateBuffer ( sizeof ( CLIENT ) ) ;
         memset(Clients[i], 0, sizeof(CLIENT)) ;

         // allocate a default size for the buffer
         Clients[i]->Buffer = ( char * ) AllocateBuffer(BUFFER_SIZE) ;
         memset(Clients[i]->Buffer, 0, BUFFER_SIZE);

         //LogMessage( 10, "Client slot allocation successful" ) ;

         if (Clients[i] != NULL) {
            Clients[i]->BufferSize = BUFFER_SIZE;
            found = 1; // mark it assigned
            //LogMessage( 10, "Buffer Size for allocated Client = %d",
            //            Clients[i]->BufferSize);
         }

         // we've finished, so break out of loop
         break;
      }
   }
   return (found ? i : -1); // if found then i else -1
}

static int ClearOldClientConnection(int SlotIndex)                          //SDH 16-05-2005
{
   int i, rc;
   struct sockaddr_in *addr1;
   struct sockaddr_in *addr2;

   // work out IP address of New connection
   addr1 = (struct sockaddr_in *) &(Clients[SlotIndex]->SocketAddress);

   if (debug) {                                                //SDH 16-05-2005
        sprintf(msg, "New connection from IP address: "        //SDH 16-05-2005
                "%d.%d.%d.%d", *((char*)(&addr1->sin_addr)),   //SDH 16-05-2005
                *((char*)(&addr1->sin_addr)+1),                //SDH 16-05-2005
                *((char*)(&addr1->sin_addr)+2),                //SDH 16-05-2005
                *((char*)(&addr1->sin_addr)+3));               //SDH 16-05-2005
        disp_msg(msg);                                         //SDH 16-05-2005
   }                                                           //SDH 16-05-2005

   // we are going to cycle round the clients to see if the
   // IP address of the new connection matches any of the old clients
   for (i = 0; i < MAX_SOCKETS; i++) {
      if (Clients[i] != NULL) {
         // In use and not the new one
         if (Clients[i]->InUse == 1 && i != SlotIndex) {
            addr2 = (struct sockaddr_in *) &(Clients[i]->SocketAddress);

            rc = memcmp((char *) &(addr2->sin_addr),
                        (char *) &(addr1->sin_addr),
                        4);

            if (rc == 0) { // Same HHT (IP addr) has tried to log on again

                if (debug) {                                                //SDH 16-05-2005
                    sprintf(msg, "HHT previously on slot:%d handle:%d!",    //SDH 16-05-2005
                           i, Clients[i]->SocketHandle);                    //SDH 16-05-2005
                    disp_msg(msg);                                          //SDH 16-05-2005
                }                                                           //SDH 16-05-2005

                //We're going to use the old slot rather than the new.      //SDH 16-05-2005
                //Close the old socket, replace the socket address in the   //SDH 16-05-2005
                //old slot, then delete the new slot                        //SDH 16-05-2005
                CloseSocket(&(Clients[i]->SocketHandle));                   //SDH 16-05-2005
                Clients[i]->SocketAddress = Clients[SlotIndex]->SocketAddress;//SDH 16-05-2005
                Clients[i]->SocketHandle = Clients[SlotIndex]->SocketHandle;//SDH 16-05-2005
                Clients[i]->SocketState = Clients[SlotIndex]->SocketState;  //SDH 16-05-2005
                ReleaseClientSlot(SlotIndex);                               //SDH 16-05-2005
                return i;                                                   //SDH 16-05-2005

               /* //SDH 16-05-2005
               if ( Clients[i]->SignedOn == 1 ) {
                  // Tell Boots app to tidy up its structures for old unit...
                  IssueCmdOffToBootsApp(i);
                  // and turn of the Signed On flag
                  Clients[i]->SignedOn = 0;
               }

               // now shut down the old socket
               CloseSocket(&(Clients[i]->SocketHandle));
               ReleaseClientSlot(i);
               LogMessage( 6, "Closed slot %i" );
               */ //SDH 16-05-2005

            }
         }
      }
   }

   if (debug) disp_msg("New IP address");                                   //SDH 16-05-2005

   //Nothing found - return new slot                                        //SDH 16-05-2005
   return SlotIndex;                                                        //SDH 16-05-2005

}


////////////////////////////////////////////////////////////////////////////////
///
///   PUBLIC FUNCTIONS
///
////////////////////////////////////////////////////////////////////////////////

int TcpLoaded ( void )
{
    /* check if the protocol stack is loaded
    return TRUE if loaded
    return FALSE otherwise
    */
    /* initialize with sockets */
    return sock_init();
}

void InitialiseSocketServer ( void )
{
   int i ;

   // initialise the Client structure
   for ( i = 0 ; i < MAX_SOCKETS ; i++ ) {
      // mark all client slots as not allocated
      Clients[i] = NULL ;
   }

   // allocate socket
   if ( AllocateSocket ( &PrimarySocketHandle ) < 0 ) {
      disp_msg ("Socket Call Failed");                                      // Streamline SDH 16-Sep-2008
      exit (1);
   }

   // bind address/port to socket
   if ( BindSocket ( &PrimarySocketHandle, HHTCOMMS_PORT ) < 0 ) {          // SDH 19-05-2005
      disp_msg ("Bind Call Failed");                                        // Streamline SDH 16-Sep-2008
      exit (1);
   }

   if ( ListenOnSocket ( &PrimarySocketHandle ) < 0 ) {
      disp_msg ("Listen Call Failed");                                      // Streamline SDH 16-Sep-2008
      exit (1);
   }

   // if we got here, the socket setup succeeded
   disp_msg ("Socket Server Initialised and Ready");                        // Streamline SDH 16-Sep-2008
}

void SocketServerLoop(void)
{

//   int key;
//   clock_t lCurrentTime = 0 ;
//   clock_t lPreviousTime = 0 ;
   LONG lCurrentTime=0L, lPreviousTime=0L;
   TIMEDATE now;

   // loop forever, waiting for:
   //        i.  Anyone to disconnect
   //       ii.  New connections
   //      iii.  Any Receives
   //       iv.  Anything to send
   // no calls in the loop will block
   // N.B: The order in which ProcessPendingXXXX funcs are called is important!
   for (;;) {
      // anyone already connected tried to break connection?
      ProcessPendingDisconnects () ;

      // has anyone new attempted connection?
      // ProcessPendingConnects ( &PrimarySocketHandle ) ;

      // anyone already connected tried to talk to us?
      ProcessPendingReceives () ;

      // reply to anyone already connected
      ProcessPendingSends () ;

/*
      if ( BreakLoop != 0 ) {
         // wait...
         disp_msg("Press ESC to END or any key to continue...");            // Streamline SDH 16-Sep-2008
         key = getchar () ;
         if ( key == 27 ) {
            CtlBrkHandler () ;
            break;
         }
      }
*/

      // call into Boots Code every POLL_FREQ mS
      // also reload control file if flag set
      // also check if HHT logs need recycling

//      lCurrentTime = clock () / CLOCKS_PER_SEC ;
      s_get( T_TD, 0L, (void *)&now, TIMESIZE );
      lCurrentTime = now.td_time;

      if ( ( ( lPreviousTime + POLL_FREQ ) < lCurrentTime ) ||
           ( lCurrentTime < lPreviousTime ) ) {
         static int iStoreCloseCheck = 0 ;

         if ( iStoreCloseCheck++ % 4 == 0 ) {
            long lSTKCFHandle = 0 ;

            lSTKCFHandle = OpenDirectFile (STKCF, STKCF_OFLAGS, STKCF_REP, TRUE);    //SDH

            if ( lSTKCFHandle ) {
               char pBuff[12] ;
               //int rc = 0 ;

               //rc = s_read ( 0, lSTKCFHandle, pBuff, sizeof pBuff, 0L ) ;
               s_read ( 0, lSTKCFHandle, pBuff, sizeof pBuff, 0L ) ;

               if ( pBuff[10] == 'N' ) {
                  CloseAllFiles () ;
                  cStoreClosed = 'Y' ;
                  background_msg("RFS - Closed");
               } else {
                  sprintf(msg,"RFS - Ready and Waiting... - Online: %02d",sess);
                  background_msg(msg);                               // 25-8-2004 PAB
                  cStoreClosed = 'N' ;
               }

               s_close ( 0, lSTKCFHandle ) ;
            } else {
               disp_msg ("Could not open STKCF");                           // Streamline SDH 16-Sep-2008
            }
         }

         //disp_msg ("Dummy call to Boots code");                             // Streamline SDH 16-Sep-2008
         // call into Boots code
         DummyCallToProcess () ;

         // re-parse control file
         //if ( PollControlFile == 'Y' ) {
         //   ParseControlFile () ;
         //}

         /* SDH - 26-11-2004  Redundant code
         // cycle HHT logs
         if ( DateHasChanged () ) {
            CycleHhtLogs () ;
         }
         */

//         lPreviousTime = clock () / CLOCKS_PER_SEC ;

      }

      lPreviousTime = lCurrentTime;

      // add a delay using system calls so that OS gives other processes
      // a chance ( LoopDelay controlled by control file parameter )
      //DelayProcess ( ( long ) LoopDelay ) ;


      //lEndTime = clock () ;

      //lElapsedTime = lEndTime - lStartTime ;

      //LogMessage ( 10, "Loop time  %ld    \n", lElapsedTime ) ;

      //lStartTime = clock () ;
   }
}

void ShutDownAllSockets(void)
{
   int i ;

   disp_msg ("Shutting down all sockets...");                               // Streamline SDH 16-Sep-2008
   for (i = 0; i < MAX_SOCKETS; i++) {
      if (Clients[i] != NULL) {
         if (Clients[i]->InUse == 1) {
            //rc = SetBlockingMode(&(Clients[i]->SocketHandle), 0);
            CloseSocket(&(Clients[i]->SocketHandle));
            //LogMessage( 10, "Closed socket index %d, returned %d", i, tcperrno);
         }
      }
   }

   // shutdowns succeeded so place the socket in nonblocking mode
   //rc = SetBlockingMode(&PrimarySocketHandle, 0) ;

   // Close Primary
   CloseSocket(&PrimarySocketHandle) ;
   //LogMessage( 4, "...Closed Primary, returning: %d", tcperrno) ;
   //SDH ExitApplication() ;
}
