#ifndef TRXDEAL_H
#define TRXDEAL_H

void DealFileTrickle (void);                                                // SDH 26-11-04 Promotions
void DealEnquiry(char *inbound);

#endif

